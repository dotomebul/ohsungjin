import React from 'react';
import { useI18n } from '@/contexts/I18nContext';
import { Card } from '@/components/ui/card';
import { ArrowLeft, FileText, AlertTriangle, Scale, Globe, Users } from 'lucide-react';
import { useLocation } from 'wouter';
import type { Language } from '@shared/i18n/translations';

interface TermsSection {
  icon: React.ReactNode;
  title: string;
  content: string;
}

interface TermsContent {
  title: string;
  lastUpdated: string;
  sections: TermsSection[];
}

function getTermsContent(language: Language): TermsContent {
  if (language === 'ko') {
    return {
      title: '이용약관',
      lastUpdated: '2026년 4월 21일',
      sections: [
        {
          icon: <FileText className="w-5 h-5 text-blue-600" />,
          title: '서비스 개요',
          content: 'Evacora는 재난 및 비상 상황에서 사용자에게 안내를 제공하는 위기 대응 앱입니다. 본 서비스는 정보 제공 목적으로만 사용되며, 공식 비상 서비스를 대체하지 않습니다.',
        },
        {
          icon: <AlertTriangle className="w-5 h-5 text-amber-600" />,
          title: '면책 조항',
          content: 'Evacora에서 제공하는 정보는 참고용이며, 실제 비상 상황에서는 반드시 공식 기관(119, 112 등)의 지시를 따르세요. 앱의 정보로 인한 손해에 대해 책임지지 않습니다.',
        },
        {
          icon: <Scale className="w-5 h-5 text-purple-600" />,
          title: '사용자 의무',
          content: '사용자는 본 서비스를 합법적인 목적으로만 사용해야 합니다. 허위 비상 알림 전송, 서비스 남용, 타인의 개인정보 침해 행위는 금지됩니다.',
        },
        {
          icon: <Globe className="w-5 h-5 text-green-600" />,
          title: '위치 서비스',
          content: '대피소 검색 및 위치 공유 기능은 GPS 데이터를 사용합니다. 위치 정보의 정확도는 기기 및 환경에 따라 달라질 수 있으며, 사용자는 언제든지 위치 공유를 중단할 수 있습니다.',
        },
        {
          icon: <Users className="w-5 h-5 text-indigo-600" />,
          title: '계정 및 데이터',
          content: '사용자 계정 삭제 시 모든 개인 데이터가 삭제됩니다. 비상 연락처 정보는 암호화되어 저장되며, 사용자 동의 없이 제3자에게 공유되지 않습니다.',
        },
      ],
    };
  }
  if (language === 'ja') {
    return {
      title: '利用規約',
      lastUpdated: '2026年4月21日',
      sections: [
        {
          icon: <FileText className="w-5 h-5 text-blue-600" />,
          title: 'サービス概要',
          content: 'Evacoraは、災害や緊急事態において利用者にガイダンスを提供する危機対応アプリです。本サービスは情報提供のみを目的としており、公式の緊急サービスに代わるものではありません。',
        },
        {
          icon: <AlertTriangle className="w-5 h-5 text-amber-600" />,
          title: '免責事項',
          content: 'Evacoraが提供する情報は参考用であり、実際の緊急事態では必ず公式機関（110/119）の指示に従ってください。アプリの情報による損害について責任を負いません。',
        },
        {
          icon: <Scale className="w-5 h-5 text-purple-600" />,
          title: '利用者の義務',
          content: '利用者は本サービスを合法的な目的でのみ使用する必要があります。虚偽の緊急通知の送信、サービスの悪用、他者の個人情報の侵害は禁止されています。',
        },
        {
          icon: <Globe className="w-5 h-5 text-green-600" />,
          title: '位置情報サービス',
          content: '避難所検索および位置共有機能はGPSデータを使用します。位置情報の精度はデバイスや環境によって異なる場合があり、利用者はいつでも位置共有を停止できます。',
        },
        {
          icon: <Users className="w-5 h-5 text-indigo-600" />,
          title: 'アカウントとデータ',
          content: 'アカウント削除時にすべての個人データが削除されます。緊急連絡先情報は暗号化して保存され、利用者の同意なく第三者に共有されることはありません。',
        },
      ],
    };
  }
  // Default: English
  return {
    title: 'Terms of Service',
    lastUpdated: 'April 21, 2026',
    sections: [
      {
        icon: <FileText className="w-5 h-5 text-blue-600" />,
        title: 'Service Overview',
        content: 'Evacora is a crisis response app that provides guidance during disasters and emergencies. This service is for informational purposes only and does not replace official emergency services.',
      },
      {
        icon: <AlertTriangle className="w-5 h-5 text-amber-600" />,
        title: 'Disclaimer',
        content: 'Information provided by Evacora is for reference only. In actual emergencies, always follow instructions from official agencies (911, 112, etc.). We are not liable for damages resulting from app information.',
      },
      {
        icon: <Scale className="w-5 h-5 text-purple-600" />,
        title: 'User Obligations',
        content: 'Users must use this service only for lawful purposes. Sending false emergency alerts, service abuse, and violating others\' privacy are prohibited.',
      },
      {
        icon: <Globe className="w-5 h-5 text-green-600" />,
        title: 'Location Services',
        content: 'Shelter search and location sharing features use GPS data. Location accuracy may vary by device and environment. Users can stop location sharing at any time.',
      },
      {
        icon: <Users className="w-5 h-5 text-indigo-600" />,
        title: 'Account & Data',
        content: 'All personal data is deleted upon account deletion. Emergency contact information is stored encrypted and is never shared with third parties without user consent.',
      },
    ],
  };
}

export default function Terms() {
  const { t, language } = useI18n();
  const [, navigate] = useLocation();

  const content = getTermsContent(language);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button onClick={() => navigate("/settings")} className="text-slate-600 hover:text-slate-900 transition-colors" aria-label="Go back">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">{t('settingsPage.terms')}</h1>
            <p className="text-sm text-slate-500">Evacora v1.0.0</p>
          </div>
        </div>

        {content.sections.map((section, idx) => (
          <Card key={idx} className="mb-4 p-6 bg-white border-slate-200">
            <div className="flex items-center gap-3 mb-4">
              {section.icon}
              <h2 className="text-lg font-bold text-slate-900">{section.title}</h2>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">{section.content}</p>
          </Card>
        ))}

        <div className="text-center py-6">
          <p className="text-xs text-slate-500">{content.lastUpdated}</p>
        </div>
      </div>
    </div>
  );
}
