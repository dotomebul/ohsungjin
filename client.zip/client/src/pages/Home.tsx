/**
 * Evacora - Unified Home Page
 * Design: Emergency Clarity - fully localized
 * Google Maps integration with real-time markers + Directions API navigation
 * Unified UI: Disaster mode as base, peacetime shows "Safe" banner + family section
 */

import { useState, useCallback, useEffect, useRef } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { Loader2, Globe, ChevronDown, Navigation, ChevronUp, Mic, Users } from "lucide-react";
import { useI18n } from "@/contexts/I18nContext";
import { Language, Region, getLanguageName } from "@shared/i18n/translations";
import { MapView } from "@/components/Map";
import { getSheltersByRegion, ShelterData } from "@shared/shelterData";
import { useFamilyTracking } from "@/hooks/useFamilyTracking";
import { useVoiceGuidance } from "@/hooks/useVoiceGuidance";
import { ShelterDetailPopup } from "@/components/ShelterDetailPopup";
import { FamilyContactPanel } from "@/components/FamilyContactPanel";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Newspaper } from "lucide-react";
import { useSEO } from "@/hooks/useSEO";

// ─── Region center coordinates ───────────────────────────────────────────────
const REGION_CENTERS: Record<Region, { lat: number; lng: number; zoom: number }> = {
  us: { lat: 39.8283, lng: -98.5795, zoom: 4 },
  eu: { lat: 50.1109, lng: 10.1508, zoom: 4 },
  kr: { lat: 36.5, lng: 127.5, zoom: 7 },
  jp: { lat: 36.2048, lng: 138.2529, zoom: 6 },
};

// ─── Simulated danger zones per region ───────────────────────────────────────
const DANGER_ZONES: Record<Region, { lat: number; lng: number; label: string; radius: number; type: string }[]> = {
  us: [
    { lat: 34.05, lng: -118.5, label: "Wildfire Zone - LA", radius: 15000, type: "wildfire" },
    { lat: 37.35, lng: -121.9, label: "Earthquake Risk - San Jose", radius: 10000, type: "earthquake" },
  ],
  eu: [
    { lat: 50.45, lng: 30.52, label: "Conflict Zone - Kyiv", radius: 20000, type: "war" },
    { lat: 48.15, lng: 37.8, label: "Conflict Zone - Donetsk", radius: 25000, type: "war" },
  ],
  kr: [
    { lat: 35.15, lng: 129.1, label: "태풍 경로 - 부산", radius: 12000, type: "typhoon" },
    { lat: 33.5, lng: 126.5, label: "태풍 경로 - 제주", radius: 15000, type: "typhoon" },
  ],
  jp: [
    { lat: 35.68, lng: 139.77, label: "地震警戒 - 東京", radius: 10000, type: "earthquake" },
    { lat: 34.69, lng: 135.5, label: "地震警戒 - 大阪", radius: 12000, type: "earthquake" },
  ],
};

// // ─── Location Accuracy Thresholds ──────────────────────────────────────────
const LOCATION_ACCURACY_THRESHOLDS = {
  EXCELLENT: 10,    // ≤ 10m
  GOOD: 50,         // ≤ 50m
  FAIR: 100,        // ≤ 100m
  POOR: 200,        // ≤ 200m
  VERY_POOR: 500,   // > 500m
};

const getAccuracyStatus = (accuracy: number | null) => {
  if (accuracy === null) return { level: 'unknown', label: '위치 정보 없음', color: 'bg-gray-400', icon: '❓' };
  if (accuracy <= LOCATION_ACCURACY_THRESHOLDS.EXCELLENT) return { level: 'excellent', label: '매우 정확', color: 'bg-green-500', icon: '✅' };
  if (accuracy <= LOCATION_ACCURACY_THRESHOLDS.GOOD) return { level: 'good', label: '정확', color: 'bg-emerald-500', icon: '✓' };
  if (accuracy <= LOCATION_ACCURACY_THRESHOLDS.FAIR) return { level: 'fair', label: '보통', color: 'bg-yellow-500', icon: '⚠️' };
  if (accuracy <= LOCATION_ACCURACY_THRESHOLDS.POOR) return { level: 'poor', label: '낮음', color: 'bg-orange-500', icon: '⚠️' };
  return { level: 'very_poor', label: '매우 낮음', color: 'bg-red-500', icon: '❌' };
};

// ─── Disaster type to guide route mapping ────────────────────────────────
const DISASTER_GUIDE_MAP: Record<string, string> = {
  wildfire: "wildfire",
  earthquake: "earthquake",
  tornado: "tornado",
  hurricane: "hurricane",
  typhoon: "typhoon",
  tsunami: "tsunami",
  flood: "flood",
  war: "war",
  nuclear: "nuclear",
  bombing: "bombing",
};

// ─── Import useState for Home component ──────────────────────────────────────
// (Already imported above)

// ─── Country Color Map ──────────────────────────────────────────────────────────
const COUNTRY_COLORS: Record<string, { bg: string; text: string; flag: string }> = {
  UK: { bg: "#3b82f6", text: "🇬🇧", flag: "UK" },
  France: { bg: "#a855f7", text: "🇫🇷", flag: "FR" },
  Germany: { bg: "#ef4444", text: "🇩🇪", flag: "DE" },
  Greece: { bg: "#f97316", text: "🇬🇷", flag: "GR" },
  Italy: { bg: "#eab308", text: "🇮🇹", flag: "IT" },
  Spain: { bg: "#22c55e", text: "🇪🇸", flag: "ES" },
  Portugal: { bg: "#ec4899", text: "🇵🇹", flag: "PT" },
  Netherlands: { bg: "#06b6d4", text: "🇳🇱", flag: "NL" },
  Belgium: { bg: "#6b7280", text: "🇧🇪", flag: "BE" },
  Austria: { bg: "#92400e", text: "🇦🇹", flag: "AT" },
};

// ─── Risk Badge Component ─────────────────────────────────────────────────────
function RiskBadge({ level, label }: { level: string; label: string }) {
  const styles: Record<string, string> = {
    high: "bg-red-100 text-red-700 border border-red-200",
    medium: "bg-amber-100 text-amber-700 border border-amber-200",
    safe: "bg-green-100 text-green-700 border border-green-200",
  };
  const icons: Record<string, string> = {
    high: "⚠️",
    medium: "⚡",
    safe: "✅",
  };
  return (
    <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${styles[level]}`}>
      {icons[level]} {label}
    </span>
  );
}

// ─── Region/Language Switcher ─────────────────────────────────────────────────
function RegionLanguageSwitcher() {
  const { language, region, setLanguage, setRegion, t } = useI18n();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const regionFlags: Record<Region, string> = { us: "🇺🇸", eu: "🇪🇺", kr: "🇰🇷", jp: "🇯🇵" };
  const regionNames: Record<Region, string> = {
    us: t('regions.unitedStates'), eu: t('regions.europe'), kr: t('regions.korea'), jp: t('regions.japan'),
  };
  const allLanguages: Language[] = ['en', 'es', 'de', 'fr', 'ko', 'ja'];

  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen(!open)} className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/80 text-slate-300 text-xs font-medium transition-all border border-slate-700/50">
        <Globe className="w-3.5 h-3.5" />
        <span>{regionFlags[region]}</span>
        <span className="hidden sm:inline">{getLanguageName(language)}</span>
        <ChevronDown className="w-3 h-3" />
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-2 w-56 rounded-xl bg-slate-800 border border-slate-700 shadow-xl z-[100] overflow-hidden">
          <div className="p-3 border-b border-slate-700">
            <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-2">{t('common.selectRegion')}</p>
            <div className="grid grid-cols-2 gap-1.5">
              {(Object.keys(regionFlags) as Region[]).map((r) => (
                <button
                  key={r}
                  onClick={() => { setRegion(r); }}
                  className={`px-2.5 py-2 rounded-lg text-xs font-medium transition-all ${
                    region === r ? 'bg-blue-600 text-white' : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {regionFlags[r]} {regionNames[r]}
                </button>
              ))}
            </div>
          </div>
          <div className="p-3">
            <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-2">{t('common.selectLanguage')}</p>
            <div className="grid grid-cols-3 gap-1.5">
              {allLanguages.map((lang) => (
                <button
                  key={lang}
                  onClick={() => { setLanguage(lang); }}
                  className={`px-2 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    language === lang ? 'bg-blue-600 text-white' : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {getLanguageName(lang)}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Find nearest shelter ──────────────────────────────────────────────────────
function findNearestShelter(lat: number, lng: number, shelters: ShelterData[]) {
  let minDist = Infinity;
  let nearest = null;
  for (const s of shelters) {
    const dlat = parseFloat(s.lat) - lat;
    const dlng = parseFloat(s.lng) - lng;
    const dist = Math.sqrt(dlat * dlat + dlng * dlng) * 111;
    if (dist < minDist) { minDist = dist; nearest = s; }
  }
  return nearest;
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function Home() {
  const [, navigate] = useLocation();
  const { t, region } = useI18n();
  
  // SEO 설정
  useSEO({
    title: "Evacora - Real-time Crisis Guidance & Shelter Routing for Emergencies",
    description: "Evacora provides real-time crisis guidance, nearest shelter routing, and one-tap family check-ins. Get instant emergency alerts and safe evacuation routes during disasters.",
    keywords: [
      "emergency app",
      "crisis management",
      "shelter finder",
      "disaster alert",
      "evacuation route",
      "family safety",
      "emergency guidance",
      "real-time alerts",
      "disaster response",
      "emergency preparedness"
    ],
    ogTitle: "Evacora - Know What to Do. Right Now.",
    ogDescription: "Real-time crisis guidance, nearest shelter routing, and one-tap family check-ins during emergencies."
  });
  
  // 재난/평시 구분 제거 - 통합 홈 화면
  const hasActiveDisaster = true; // Always show disaster mode
  const [riskLevel, setRiskLevel] = useState<string>("high");
  const [alertText, setAlertText] = useState("");
  const [guideText, setGuideText] = useState("");
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationAccuracy, setLocationAccuracy] = useState<number | null>(null);
  const [locationUpdatedAt, setLocationUpdatedAt] = useState<Date | null>(null);
  const [locationPermissionDenied, setLocationPermissionDenied] = useState(false);
  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.marker.AdvancedMarkerElement[]>([]);
  const circlesRef = useRef<google.maps.Circle[]>([]);
  const directionsRendererRef = useRef<google.maps.DirectionsRenderer | null>(null);
  const [mapReady, setMapReady] = useState(false);
  const [routeMode, setRouteMode] = useState<"WALKING" | "DRIVING" | null>(null);
  const [routeInfo, setRouteInfo] = useState<{ distance: string; duration: string; shelter: string } | null>(null);
  const [routeLoading, setRouteLoading] = useState(false);
  const [activeDisasterType, setActiveDisasterType] = useState<string>("earthquake");
  const pollingIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [safeNetworkExpanded, setSafeNetworkExpanded] = useState(false);
  const lastLocationUpdateRef = useRef<number>(0);

  // Phase 28: New state for modals and features
  const [selectedShelter, setSelectedShelter] = useState<ShelterData | null>(null);
  const [showShelterPopup, setShowShelterPopup] = useState(false);
  const [showFamilyPanel, setShowFamilyPanel] = useState(false);

  // Hooks for new features
  const familyTracking = useFamilyTracking(userLocation);
  const voiceGuidance = useVoiceGuidance({ language: region === 'kr' ? 'ko-KR' : region === 'jp' ? 'ja-JP' : 'en-US' });

  // 위치 업데이트 피드백 (중복 업데이트 방지)
  const showLocationUpdateFeedback = useCallback(() => {
    const now = Date.now();
    if (now - lastLocationUpdateRef.current > 5000) {
      toast.success('위치가 업데이트되었습니다');
      lastLocationUpdateRef.current = now;
    }
  }, []);

  // 위치 권한 거부 처리
  const handleLocationError = useCallback((error: GeolocationPositionError) => {
    if (error.code === 1) {
      setLocationPermissionDenied(true);
      toast.error('위치 권한을 허용해주세요. 설정에서 위치 접근을 활성화하세요.');
    } else if (error.code === 2) {
      toast.error('위치 정보를 사용할 수 없습니다.');
    } else if (error.code === 3) {
      toast.error('위치 정보 요청 시간 초과');
    }
  }, []);

  // Handle shelter marker click
  const handleShelterMarkerClick = useCallback((shelter: ShelterData) => {
    setSelectedShelter(shelter);
    setShowShelterPopup(true);
  }, []);

  // Handle voice guidance
  const handleVoiceGuidance = useCallback(() => {
    const guidanceText = `${t('home.actionGuide')}. ${alertText}`;
    voiceGuidance.speak(guidanceText);
  }, [t, alertText, voiceGuidance]);

  // Handle get directions
  const handleGetDirections = useCallback((shelter: ShelterData) => {
    if (!userLocation || !mapRef.current) return;

    const directionsService = new google.maps.DirectionsService();
    const renderer = directionsRendererRef.current || new google.maps.DirectionsRenderer({ map: mapRef.current });
    directionsRendererRef.current = renderer;

    directionsService.route(
      {
        origin: userLocation,
        destination: { lat: parseFloat(shelter.lat), lng: parseFloat(shelter.lng) },
        travelMode: google.maps.TravelMode.DRIVING,
      },
      (result, status) => {
        if (status === google.maps.DirectionsStatus.OK) {
          renderer.setDirections(result);
          const leg = result?.routes[0]?.legs[0];
          if (leg) {
            setRouteInfo({
              distance: leg.distance?.text || '',
              duration: leg.duration?.text || '',
              shelter: shelter.name,
            });
            setRouteMode('DRIVING');
          }
        } else {
          toast.error('Could not calculate route');
        }
      }
    );
  }, [userLocation]);

  // 실시간 위험도 업데이트 함수
  const updateRiskLevel = useCallback(() => {
    if (!userLocation) return;
    
    const dangers = DANGER_ZONES[region] || [];
    if (dangers.length === 0) {
      
      setRiskLevel("safe");
      return;
    }
    
    // 사용자 위치와 위험 지역의 거리 계산
    let minDistance = Infinity;
    let closestDanger = dangers[0];
    
    for (const danger of dangers) {
      const dlat = danger.lat - userLocation.lat;
      const dlng = danger.lng - userLocation.lng;
      const distance = Math.sqrt(dlat * dlat + dlng * dlng) * 111; // 대략적인 km 변환
      
      if (distance < minDistance) {
        minDistance = distance;
        closestDanger = danger;
      }
    }
    
    // 거리에 따라 위험도 결정
    if (minDistance < 10) {
      setRiskLevel("high");
      
      setActiveDisasterType(closestDanger.type);
      setAlertText(`${closestDanger.label} - ${Math.round(minDistance)}km ${t('family.away')}`);
    } else if (minDistance < 30) {
      setRiskLevel("medium");
      
      setActiveDisasterType(closestDanger.type);
      setAlertText(`${closestDanger.label} - ${Math.round(minDistance)}km ${t('family.away')}`);
    } else {
      setRiskLevel("safe");
      
      setAlertText(t('alerts.safeStatus'));
    }
    setGuideText(t('home.actionGuide'));
  }, [userLocation, region, t]);
  
  // Set active disaster type based on region
  useEffect(() => {
    const dangers = DANGER_ZONES[region] || [];
    if (dangers.length > 0) {
      setActiveDisasterType(dangers[0].type);
    }
    setGuideText(t('home.actionGuide'));
  }, [t, region]);
  
  // 실시간 위험도 폴링 (60초 간격)
  useEffect(() => {
    updateRiskLevel();
    
    pollingIntervalRef.current = setInterval(() => {
      updateRiskLevel();
    }, 60000); // 60초마다 업데이트
    
    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
    };
  }, [updateRiskLevel]);

  // Get user location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const newLocation = { lat: position.coords.latitude, lng: position.coords.longitude };
          setUserLocation(newLocation);
          setLocationAccuracy(Math.round(position.coords.accuracy));
          setLocationUpdatedAt(new Date());
          setLocationPermissionDenied(false);
          showLocationUpdateFeedback();
        },
        (error: GeolocationPositionError) => {
          handleLocationError(error);
          const center = REGION_CENTERS[region];
          setUserLocation({ lat: center.lat, lng: center.lng });
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    }
  }, [region, showLocationUpdateFeedback, handleLocationError]);
  
  // 사용자 위치 변경 시 위험도 업데이트
  useEffect(() => {
    updateRiskLevel();
  }, [userLocation, updateRiskLevel]);

  // Create custom marker element with country color support
  const createMarkerElement = useCallback((type: "user" | "danger" | "shelter", label: string, country?: string) => {
    const div = document.createElement("div");
    div.style.display = "flex";
    div.style.flexDirection = "column";
    div.style.alignItems = "center";
    div.style.cursor = "pointer";

    const pin = document.createElement("div");
    pin.style.width = "32px";
    pin.style.height = "32px";
    pin.style.borderRadius = "50%";
    pin.style.border = "3px solid white";
    pin.style.display = "flex";
    pin.style.alignItems = "center";
    pin.style.justifyContent = "center";
    pin.style.fontSize = "14px";
    pin.style.fontWeight = "bold";
    pin.style.color = "white";
    pin.style.boxShadow = "0 2px 8px rgba(0,0,0,0.3)";

    if (type === "user") {
      pin.style.background = "#10b981";
      pin.textContent = "●";
      pin.style.animation = "pulse 2s infinite";
    } else if (type === "danger") {
      pin.style.background = "#ef4444";
      pin.textContent = "!";
    } else if (type === "shelter") {
      // Use country color if available
      const countryColor = country && COUNTRY_COLORS[country] ? COUNTRY_COLORS[country].bg : "#3b82f6";
      pin.style.background = countryColor;
      pin.textContent = "🏠";
    }

    const tooltip = document.createElement("div");
    tooltip.style.background = "rgba(0,0,0,0.8)";
    tooltip.style.color = "white";
    tooltip.style.padding = "4px 8px";
    tooltip.style.borderRadius = "4px";
    tooltip.style.fontSize = "12px";
    tooltip.style.whiteSpace = "nowrap";
    tooltip.style.marginTop = "4px";
    tooltip.textContent = label;

    div.appendChild(pin);
    div.appendChild(tooltip);
    return div;
  }, []);

  // Initialize map with markers
  const handleMapReady = useCallback((map: google.maps.Map) => {
    mapRef.current = map;
    setMapReady(true);

    // Clear previous markers
    markersRef.current.forEach((marker) => marker.map = null);
    markersRef.current = [];
    circlesRef.current.forEach((circle) => circle.setMap(null));
    circlesRef.current = [];

    if (!userLocation) return;

    // Add user marker
    const userMarker = new google.maps.marker.AdvancedMarkerElement({
      map,
      position: userLocation,
      content: createMarkerElement("user", "You"),
    });
    markersRef.current.push(userMarker);

    // Add danger zones
    const dangers = DANGER_ZONES[region] || [];
    for (const danger of dangers) {
      const dangerMarker = new google.maps.marker.AdvancedMarkerElement({
        map,
        position: { lat: danger.lat, lng: danger.lng },
        content: createMarkerElement("danger", danger.label),
      });
      markersRef.current.push(dangerMarker);

      // Add circle for danger zone
      const circle = new google.maps.Circle({
        map,
        center: { lat: danger.lat, lng: danger.lng },
        radius: danger.radius,
        fillColor: "#ef4444",
        fillOpacity: 0.1,
        strokeColor: "#ef4444",
        strokeOpacity: 0.3,
        strokeWeight: 2,
      });
      circlesRef.current.push(circle);
    }

    // Add shelter markers - all shelters with country color coding
    const shelters = getSheltersByRegion(region);
    for (const shelter of shelters) {
      const shelterMarker = new google.maps.marker.AdvancedMarkerElement({
        map,
        position: { lat: parseFloat(shelter.lat), lng: parseFloat(shelter.lng) },
        content: createMarkerElement("shelter", `${shelter.name} (${shelter.country || 'EU'})`, shelter.country),
      });
      shelterMarker.addListener("click", () => {
        handleShelterMarkerClick(shelter);
      });
      markersRef.current.push(shelterMarker);
    }
  }, [userLocation, region, createMarkerElement, navigate]);

  // Show route
  const showRoute = useCallback((mode: "WALKING" | "DRIVING") => {
    if (!userLocation || !mapRef.current) {
      toast.error(t('common.error'));
      return;
    }

    const shelters = getSheltersByRegion(region);
    const nearest = findNearestShelter(userLocation.lat, userLocation.lng, shelters);
    if (!nearest) {
      toast.error(t('common.error'));
      return;
    }

    setRouteLoading(true);
    setRouteMode(mode);

    // Clear previous route
    if (directionsRendererRef.current) {
      directionsRendererRef.current.setMap(null);
    }

    const directionsService = new google.maps.DirectionsService();
    const directionsRenderer = new google.maps.DirectionsRenderer({
      map: mapRef.current,
      suppressMarkers: true, // Keep our custom markers
      polylineOptions: {
        strokeColor: mode === "WALKING" ? "#10b981" : "#3b82f6",
        strokeWeight: 5,
        strokeOpacity: 0.8,
      },
    });
    directionsRendererRef.current = directionsRenderer;

    const destination = { lat: parseFloat(nearest.lat), lng: parseFloat(nearest.lng) };
    const travelMode = mode === "WALKING" ? google.maps.TravelMode.WALKING : google.maps.TravelMode.DRIVING;

    directionsService.route(
      {
        origin: userLocation,
        destination,
        travelMode,
      },
      (result, status) => {
        setRouteLoading(false);
        if (status === "OK" && result) {
          directionsRenderer.setDirections(result);
          const leg = result.routes[0]?.legs[0];
          if (leg) {
            setRouteInfo({
              distance: leg.distance?.text || "",
              duration: leg.duration?.text || "",
              shelter: nearest.name,
            });
            // Zoom to fit route
            const bounds = new google.maps.LatLngBounds();
            bounds.extend(userLocation);
            bounds.extend(destination);
            mapRef.current?.fitBounds(bounds, { top: 50, bottom: 50, left: 50, right: 50 });
          }
        } else {
          toast.error(t('common.error'));
          setRouteMode(null);
        }
      }
    );
  }, [userLocation, region, t]);

  // Clear route
  const clearRoute = useCallback(() => {
    if (directionsRendererRef.current) {
      directionsRendererRef.current.setMap(null);
      directionsRendererRef.current = null;
    }
    setRouteInfo(null);
    setRouteMode(null);
    // Reset map view
    if (mapRef.current) {
      const regionCenter = REGION_CENTERS[region];
      mapRef.current.setCenter({ lat: regionCenter.lat, lng: regionCenter.lng });
      mapRef.current.setZoom(regionCenter.zoom);
    }
  }, [region]);

  const riskLabel = riskLevel === "high" ? t('alerts.highRisk') : riskLevel === "medium" ? t('alerts.mediumRisk') : t('alerts.safeStatus');
  const riskDotColor = riskLevel === "high" ? "bg-red-500" : riskLevel === "medium" ? "bg-amber-500" : "bg-green-500";
  const regionCenter = REGION_CENTERS[region];
  
  return (
    <div className="min-h-screen w-full" style={{ background: "#0f172a", fontFamily: "'Inter', sans-serif" }}>
      {/* ── Status Bar ── */}
      <div
        className="sticky top-0 z-50 flex items-center justify-between px-4 py-3"
        style={{ background: "rgba(15,23,42,0.95)", backdropFilter: "blur(12px)", borderBottom: "1px solid rgba(255,255,255,0.06)" }}
      >
        <div className="flex items-center gap-2">
          <span className="text-lg font-bold tracking-tight text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Evacora
          </span>
          <span className="text-xs text-slate-400 font-medium">{hasActiveDisaster ? t('alerts.liveIndicator') : t('alerts.safeStatus')}</span>
          <span className={`w-2 h-2 rounded-full ${riskDotColor} ${hasActiveDisaster ? 'animate-pulse' : ''}`} />
        </div>
        <div className="flex items-center gap-2">
          <RegionLanguageSwitcher />
          <button onClick={() => navigate("/settings")} className="text-slate-400 hover:text-white transition-colors p-1.5" aria-label={t('common.settings')}>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
              <circle cx="12" cy="12" r="3" />
            </svg>
          </button>
        </div>
      </div>

      {/* ── App Container ── */}
      <div className="mx-auto px-4 pb-8 pt-4" style={{ maxWidth: 430 }}>

        {/* ── Safe Status Banner (Peacetime) ── */}
        {!hasActiveDisaster && (
          <div className="rounded-3xl overflow-hidden mb-4 animate-slide-up" style={{ animationDelay: "0s", background: "linear-gradient(160deg, #10b981 0%, #059669 100%)", border: "1px solid rgba(16,185,129,0.3)" }}>
            <div className="px-5 py-4">
              <div className="flex items-center gap-3">
                <span className="text-3xl">✅</span>
                <div>
                  <p className="text-emerald-50 text-xs font-semibold uppercase tracking-wider mb-0.5">{t('alerts.safeStatus')}</p>
                  <p className="text-white text-sm font-medium">{t('home.noActiveDisasters')}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── Hero Card (Disaster) ── */}
        {hasActiveDisaster && (
          <div className="rounded-3xl overflow-hidden mb-4 animate-slide-up" style={{ animationDelay: "0s", background: "linear-gradient(160deg, #111827 0%, #1e293b 100%)", border: "1px solid rgba(255,255,255,0.08)" }}>
            <div className="relative h-44 overflow-hidden">
              <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663581625910/LnAdnnQLDfBefQTZ8BPUTs/crisispath-hero-bWAEoLH7pMcQXzHkcn4PrW.webp" alt="Evacora background" className="w-full h-full object-cover opacity-60" />
              <div className="absolute inset-0 flex flex-col justify-end p-5" style={{ background: "linear-gradient(to top, rgba(17,24,39,0.95) 0%, transparent 60%)" }}>
                <p className="text-slate-400 text-xs font-medium tracking-widest uppercase mb-1">{t('home.crisisResponseApp')}</p>
                <h1 className="text-white text-3xl font-bold leading-tight" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  {t('common.appTagline')}
                </h1>
              </div>
            </div>

            {/* H2 제목 - SEO 개선 */}
            <h2 className="sr-only">Real-time Crisis Alerts and Guidance</h2>

            {/* Alert Banner - clickable to go to disaster guide */}
            <div className="px-4 pb-4 pt-2">
              <button
                onClick={() => navigate(`/guides?type=${activeDisasterType}`)}
                className="w-full flex items-start gap-3 rounded-2xl p-4 animate-pulse-danger text-left transition-all hover:opacity-90"
                style={{ background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.3)" }}
              >
                <span className="text-red-400 text-lg mt-0.5 flex-shrink-0">🔔</span>
                <div>
                  <p className="text-red-300 text-xs font-semibold uppercase tracking-wider mb-0.5">{t('alerts.activeAlert')}</p>
                  <p className="text-white text-sm font-medium leading-snug">{alertText}</p>
                  <p className="text-red-400 text-xs mt-1">{t('actions.viewGuide')} →</p>
                </div>
              </button>
            </div>
          </div>
        )}

        {/* ── Location Accuracy Indicator ── */}
        {userLocation && (
          <div className="mb-4 animate-slide-up" style={{ animationDelay: "0.02s" }}>
            {(() => {
              const accuracyStatus = getAccuracyStatus(locationAccuracy);
              const isLowAccuracy = ['poor', 'very_poor'].includes(accuracyStatus.level);
              return (
                <div className={`rounded-2xl p-3 flex items-center gap-3 transition-all duration-300 ${
                  isLowAccuracy 
                    ? 'bg-red-50 border border-red-200 animate-pulse' 
                    : 'bg-green-50 border border-green-200'
                }`}>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg ${
                    isLowAccuracy 
                      ? 'bg-red-100 animate-bounce' 
                      : 'bg-green-100'
                  }`}>
                    {accuracyStatus.icon}
                  </div>
                  <div className="flex-1">
                    <p className={`text-xs font-semibold uppercase tracking-wider ${
                      isLowAccuracy ? 'text-red-700' : 'text-green-700'
                    }`}>
                      {t('home.locationAccuracy') || '위치 정확도'}
                    </p>
                    <p className={`text-sm font-medium ${
                      isLowAccuracy ? 'text-red-900' : 'text-green-900'
                    }`}>
                      {accuracyStatus.label} {locationAccuracy !== null ? `(±${Math.round(locationAccuracy)}m)` : ''}
                    </p>
                  </div>
                  {isLowAccuracy && (
                    <div className="text-right">
                      <p className="text-xs text-red-600 font-semibold">⚠️ 낮음</p>
                      <p className="text-xs text-red-500 mt-0.5">실내 이동</p>
                    </div>
                  )}
                </div>
              );
            })()}
          </div>
        )}

        {/* ── Google Map Card (Primary) ── */}
        <div className="rounded-3xl overflow-hidden mb-4 bg-white animate-slide-up" style={{ animationDelay: "0.05s", border: "1px solid rgba(255,255,255,0.1)" }}>
          <div className="px-5 pt-5 pb-3">
            <div className="flex items-center justify-between mb-1">
              <h2 className="text-slate-900 text-base font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                {t('home.areaMap')} - Find Nearest Shelters and Safe Routes
              </h2>
              <span className="text-xs text-slate-500 font-medium">{t('home.tapPoint')}</span>
            </div>

            {/* Legend - User, Danger, and Country-based Shelters */}
            <div className="flex flex-wrap gap-2 mb-3">
              {/* User and Danger */}
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <span className="text-xs text-slate-500 font-medium">{t('common.you')}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                <span className="text-xs text-slate-500 font-medium">{t('common.danger')}</span>
              </div>
              {/* Country-based Shelter Colors */}
              {region === 'eu' && (
                <>
                  {Object.entries(COUNTRY_COLORS).map(([country, { bg, flag }]) => (
                    <div key={country} className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ background: bg }} />
                      <span className="text-xs text-slate-500 font-medium">{flag}</span>
                    </div>
                  ))}
                </>
              )}
              {region !== 'eu' && (
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                  <span className="text-xs text-slate-500 font-medium">{t('common.shelter')}</span>
                </div>
              )}
            </div>
          </div>

          {/* Map Area */}
          <div className="relative mx-4 rounded-2xl overflow-hidden" style={{ height: 240 }}>
            {userLocation && (
              <MapView
                initialCenter={userLocation}
                initialZoom={regionCenter.zoom}
                onMapReady={handleMapReady}
              />
            )}
          </div>

          {/* Route Info */}
          {routeInfo && (
            <div className="px-4 py-3 bg-slate-50 border-t border-slate-200">
              <div className="flex items-center justify-between mb-2">
                <div className="text-sm">
                  <p className="text-slate-600 text-xs">{t('home.routeTo')} {routeInfo.shelter}</p>
                  <p className="text-slate-900 font-semibold">{routeInfo.distance} · {routeInfo.duration}</p>
                </div>
                <button
                  onClick={clearRoute}
                  className="text-xs font-medium px-2 py-1 rounded-lg bg-white/80 hover:bg-white transition-colors"
                  style={{ color: "#64748b" }}
                >
                  ✕
                </button>
              </div>
            </div>
          )}

          {/* Route Buttons */}
          <div className="px-4 py-4 grid grid-cols-2 gap-3">
            <button
              onClick={() => showRoute("WALKING")}
              disabled={routeLoading}
              className={`flex items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-semibold transition-all duration-150 active:scale-95 ${
                routeMode === "WALKING"
                  ? "bg-emerald-100 text-emerald-700 border-2 border-emerald-400"
                  : "bg-slate-50 text-slate-700 border border-slate-200 hover:bg-slate-100"
              }`}
            >
              {routeLoading && routeMode === "WALKING" ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <span>🚶</span>
              )}
              {t('home.walkRoute')}
            </button>
            <button
              onClick={() => showRoute("DRIVING")}
              disabled={routeLoading}
              className={`flex items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-semibold transition-all duration-150 active:scale-95 ${
                routeMode === "DRIVING"
                  ? "bg-blue-100 text-blue-700 border-2 border-blue-400"
                  : "bg-slate-50 text-slate-700 border border-slate-200 hover:bg-slate-100"
              }`}
            >
              {routeLoading && routeMode === "DRIVING" ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <span>🚗</span>
              )}
              {t('home.driveRoute')}
            </button>
          </div>
        </div>

        {/* ── Action Guide Card ── */}
        <div className="rounded-3xl overflow-hidden mb-4 bg-white animate-slide-up" style={{ animationDelay: "0.1s", border: "1px solid rgba(255,255,255,0.1)" }}>
          <div className="px-5 pt-5 pb-5">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-slate-900 text-base font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                {t('home.actionGuide')}
              </h2>
              {hasActiveDisaster && <RiskBadge level={riskLevel} label={riskLabel} />}
            </div>
            <div className="rounded-2xl p-4 mb-4" style={{ background: "#f8fafc", border: "1px solid #e2e8f0" }}>
              <p className="text-slate-700 text-sm leading-relaxed font-medium">{guideText}</p>
            </div>

            {/* Action Buttons Row */}
            <div className="grid grid-cols-2 gap-2 mb-3">
              {/* Voice Guidance Button */}
              <button
                onClick={handleVoiceGuidance}
                disabled={voiceGuidance.isPlaying}
                className="flex items-center justify-center gap-2 rounded-2xl py-3 text-xs font-semibold text-white transition-all duration-150 active:scale-95 hover:opacity-90 disabled:opacity-50"
                style={{ background: voiceGuidance.isPlaying ? "#9ca3af" : "#8b5cf6" }}
              >
                <Mic className="w-4 h-4" />
                {voiceGuidance.isPlaying ? 'Playing...' : 'Voice Guide'}
              </button>

              {/* Family Panel Button */}
              <button
                onClick={() => setShowFamilyPanel(true)}
                className="flex items-center justify-center gap-2 rounded-2xl py-3 text-xs font-semibold text-white transition-all duration-150 active:scale-95 hover:opacity-90"
                style={{ background: "#06b6d4" }}
              >
                <Users className="w-4 h-4" />
                Family
              </button>
            </div>

            {/* Family Check-in Button */}
            <button
              onClick={() => navigate("/family")}
              className="w-full relative flex items-center justify-center gap-2 rounded-2xl py-4 text-sm font-bold text-white transition-all duration-150 active:scale-95 hover:opacity-90"
              style={{ background: "linear-gradient(135deg, #ec4899, #db2777)" }}
            >
              <span>👨‍👩‍👧</span> {t('family.checkIn')}
            </button>
          </div>
        </div>

        {/* ── Core Features ── */}
        <div className="grid grid-cols-1 gap-3 mb-4 animate-slide-up" style={{ animationDelay: "0.15s" }}>
          <button onClick={() => navigate("/family")} className="rounded-2xl p-4 bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white transition-all active:scale-95 flex items-center justify-between">
            <div><p className="font-bold text-left">👨‍👩‍👧 {t('home.familyTracker')}</p><p className="text-xs opacity-75 text-left">{t('home.familyTrackerDesc')}</p></div>
            <span className="text-2xl">→</span>
          </button>
          <button onClick={() => navigate("/safe-route")} className="rounded-2xl p-4 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white transition-all active:scale-95 flex items-center justify-between">
            <div><p className="font-bold text-left">🛣️ {t('home.safeRoute')}</p><p className="text-xs opacity-75 text-left">{t('home.safeRouteDesc')}</p></div>
            <span className="text-2xl">→</span>
          </button>
        </div>

        {/* ── Navigation Cards ── */}
        <div className="grid grid-cols-3 gap-3 mb-4 animate-slide-up" style={{ animationDelay: "0.2s" }}>
          <button onClick={() => navigate("/map")} className="rounded-2xl p-4 bg-blue-600 hover:bg-blue-700 text-white transition-all active:scale-95">
            <div className="text-2xl mb-2">🗺️</div>
            <p className="font-semibold text-sm">{t('common.map')}</p>
            <p className="text-xs opacity-75">{t('home.emergencyMap')}</p>
          </button>
          <button onClick={() => navigate("/guides")} className="rounded-2xl p-4 bg-indigo-600 hover:bg-indigo-700 text-white transition-all active:scale-95">
            <div className="text-2xl mb-2">📚</div>
            <p className="font-semibold text-sm">{t('common.guides')}</p>
            <p className="text-xs opacity-75">{t('home.disasterGuides')}</p>
          </button>
          <button onClick={() => navigate("/contacts")} className="rounded-2xl p-4 bg-purple-600 hover:bg-purple-700 text-white transition-all active:scale-95">
            <div className="text-2xl mb-2">👥</div>
            <p className="font-semibold text-sm">{t('common.contacts')}</p>
            <p className="text-xs opacity-75">{t('home.emergencyContacts')}</p>
          </button>
        </div>

        {/* ── Safe Network Section (Peacetime) ── */}
        {/* Safe Network Section - Always shown */}
        <div className="rounded-3xl overflow-hidden mb-4 bg-white animate-slide-up" style={{ animationDelay: "0.25s", border: "1px solid rgba(255,255,255,0.1)" }}>
          <button
            onClick={() => setSafeNetworkExpanded(!safeNetworkExpanded)}
            className="w-full px-5 py-4 flex items-center justify-between hover:bg-slate-50 transition-colors"
          >
            <div className="flex items-center gap-3 text-left">
              <span className="text-2xl">👨‍👩‍👧‍👦</span>
              <div>
                <h2 className="text-slate-900 text-base font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  {t('home.safeNetwork')}
                </h2>
                <p className="text-slate-500 text-xs">{t('home.safeNetworkDesc')}</p>
              </div>
            </div>
            {safeNetworkExpanded ? (
              <ChevronUp className="w-5 h-5 text-slate-400" />
            ) : (
              <ChevronDown className="w-5 h-5 text-slate-400" />
            )}
          </button>

          {safeNetworkExpanded && (
            <div className="px-5 pb-5 border-t border-slate-200 space-y-4">
              <div className="p-4 rounded-2xl" style={{ background: "#f0fdf4", border: "1px solid #dcfce7" }}>
                <p className="text-sm text-slate-700 font-medium mb-2">✅ {t('home.allFamilySafe')}</p>
                <p className="text-xs text-slate-600">{t('home.noActiveAlertsRegion')}</p>
              </div>

              <div>
                <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">{t('home.preparedness')}</p>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div className="bg-blue-600 h-2 rounded-full" style={{ width: "75%" }} />
                    </div>
                  </div>
                  <div className="text-lg font-bold text-blue-600">75%</div>
                </div>
              </div>

              <button
                onClick={() => navigate("/family")}
                className="w-full py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-semibold transition-all active:scale-95"
              >
                {t('home.manageSafeNetwork')}
              </button>
            </div>
          )}
        </div>

        {/* ── Latest Disaster News ── */}
        <div className="rounded-3xl overflow-hidden mb-4 bg-white animate-slide-up" style={{ animationDelay: "0.25s", border: "1px solid rgba(255,255,255,0.1)" }}>
          <button
            onClick={() => navigate("/news")}
            className="w-full px-5 py-4 flex items-center justify-between hover:bg-slate-50 transition-colors"
          >
            <div className="flex items-center gap-3 text-left">
              <span className="text-2xl">📰</span>
              <div>
                <h2 className="text-slate-900 text-base font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Disaster News
                </h2>
                <p className="text-slate-500 text-xs">Real-time updates from world media</p>
              </div>
            </div>
            <ChevronDown className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        {/* ── Quick Info Cards ── */}
        <div className="grid grid-cols-2 gap-3 mb-4 animate-slide-up" style={{ animationDelay: "0.3s" }}>
          <div className="rounded-2xl p-4 bg-white" style={{ border: "1px solid rgba(255,255,255,0.1)" }}>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-8 h-8 rounded-xl flex items-center justify-center text-base" style={{ background: "#dbeafe" }}>🏫</span>
              <span className="text-slate-500 text-xs font-semibold uppercase tracking-wider">{t('home.shelter')}</span>
            </div>
            <p className="text-slate-900 text-sm font-bold leading-tight">{t('home.shelterInfo')}</p>
            <p className="text-xs font-medium mt-0.5" style={{ color: "#1d4ed8" }}>
              {getSheltersByRegion(region).length} {t('home.shelter')}
            </p>
          </div>
          <div className="rounded-2xl p-4 bg-white" style={{ border: "1px solid rgba(255,255,255,0.1)" }}>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-8 h-8 rounded-xl flex items-center justify-center text-base" style={{ background: "#fee2e2" }}>🌡️</span>
              <span className="text-slate-500 text-xs font-semibold uppercase tracking-wider">{t('home.conditions')}</span>
            </div>
            <p className="text-slate-900 text-sm font-bold leading-tight">{t('home.conditions')}</p>
          </div>
        </div>

        {/* ── Footer ── */}
        <div className="text-center pb-2">
          <p className="text-slate-600 text-xs">Evacora · v1.0</p>
          <p className="text-slate-700 text-xs mt-1">{t('home.footerNote')}</p>
        </div>
      </div>

      {/* Phase 28: Modals */}
      <ShelterDetailPopup
        shelter={selectedShelter}
        isOpen={showShelterPopup}
        onClose={() => setShowShelterPopup(false)}
        userLocation={userLocation}
        onGetDirections={handleGetDirections}
      />

      <FamilyContactPanel
        isOpen={showFamilyPanel}
        onClose={() => setShowFamilyPanel(false)}
        familyMembers={familyTracking.familyMembers}
        onAddMember={() => setShowFamilyPanel(false)}
        onRemoveMember={familyTracking.removeFamilyMember}
      />
    </div>
  );
}
