import { useState, useMemo, useEffect } from 'react';
import { useI18n } from '@/contexts/I18nContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle, Clock, Volume2, MapPin, ArrowLeft, Package } from 'lucide-react';
import { useLocation, useSearch } from 'wouter';
import { QuickSafetyShare } from '@/components/QuickSafetyShare';

interface ActionStep {
  id: number;
  title: string;
  description: string;
  icon: string;
  priority: 'immediate' | 'urgent' | 'important';
}

interface SupplyItem {
  name: string;
  icon: string;
}

interface DisasterScenario {
  id: string;
  name: string;
  type: string;
  severity: 'high' | 'medium' | 'low';
  actions: ActionStep[];
  supplies: SupplyItem[];
  estimatedDuration: string;
}

export default function ActionGuide() {
  const { t, region } = useI18n();
  const [, navigate] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const typeFromUrl = params.get('type');

  // Determine active disaster type from URL or region default
  const [activeType, setActiveType] = useState<string>(typeFromUrl || 'earthquake');
  const [isQuickShareOpen, setIsQuickShareOpen] = useState(false);

  useEffect(() => {
    if (typeFromUrl) setActiveType(typeFromUrl);
  }, [typeFromUrl]);

  // Supply lists per disaster type
  const getSupplies = (type: string): SupplyItem[] => {
    const common: SupplyItem[] = [
      { name: t('guide.waterFood') || 'Water & Food', icon: '💧' },
      { name: t('guide.firstAidKit') || 'First Aid Kit', icon: '🩹' },
      { name: t('guide.flashlight') || 'Flashlight', icon: '🔦' },
      { name: t('guide.phoneCharger') || 'Phone Charger', icon: '🔋' },
      { name: t('guide.idDocuments') || 'ID & Documents', icon: '🪪' },
      { name: t('guide.medications') || 'Medications', icon: '💊' },
    ];

    const typeSpecific: Record<string, SupplyItem[]> = {
      earthquake: [
        ...common,
        { name: t('guide.helmet') || 'Helmet', icon: '⛑️' },
        { name: t('guide.whistle') || 'Whistle', icon: '📢' },
        { name: t('guide.dustMask') || 'Dust Mask', icon: '😷' },
      ],
      wildfire: [
        ...common,
        { name: t('guide.nMask') || 'N95 Mask', icon: '😷' },
        { name: t('guide.goggles') || 'Goggles', icon: '🥽' },
        { name: t('guide.wetTowel') || 'Wet Towel', icon: '🧣' },
      ],
      typhoon: [
        ...common,
        { name: t('guide.rainGear') || 'Rain Gear', icon: '🧥' },
        { name: t('guide.radio') || 'Radio', icon: '📻' },
        { name: t('guide.rope') || 'Rope', icon: '🪢' },
      ],
      hurricane: [
        ...common,
        { name: t('guide.rainGear') || 'Rain Gear', icon: '🧥' },
        { name: t('guide.radio') || 'Radio', icon: '📻' },
        { name: t('guide.plywood') || 'Plywood', icon: '🪵' },
      ],
      tsunami: [
        ...common,
        { name: t('guide.lifeJacket') || 'Life Jacket', icon: '🦺' },
        { name: t('guide.waterproofBag') || 'Waterproof Bag', icon: '🎒' },
        { name: t('guide.whistle') || 'Whistle', icon: '📢' },
      ],
      flood: [
        ...common,
        { name: t('guide.lifeJacket') || 'Life Jacket', icon: '🦺' },
        { name: t('guide.waterproofBag') || 'Waterproof Bag', icon: '🎒' },
        { name: t('guide.rope') || 'Rope', icon: '🪢' },
      ],
      tornado: [
        ...common,
        { name: t('guide.helmet') || 'Helmet', icon: '⛑️' },
        { name: t('guide.blanket') || 'Blanket', icon: '🛏️' },
        { name: t('guide.radio') || 'Radio', icon: '📻' },
      ],
      war: [
        ...common,
        { name: t('guide.helmet') || 'Helmet', icon: '⛑️' },
        { name: t('guide.radio') || 'Radio', icon: '📻' },
        { name: t('guide.cashSmallBills') || 'Cash (small bills)', icon: '💵' },
        { name: t('guide.warmClothes') || 'Warm Clothes', icon: '🧥' },
      ],
    };

    return typeSpecific[type] || common;
  };

  const currentScenario = useMemo<DisasterScenario>(() => {
    const disasterNames: Record<string, string> = {
      earthquake: t('disasters.earthquake'),
      wildfire: t('disasters.wildfire'),
      typhoon: t('disasters.typhoon'),
      hurricane: t('disasters.hurricane'),
      tsunami: t('disasters.tsunami'),
      flood: t('disasters.flood'),
      tornado: t('disasters.tornado'),
      war: t('disasters.war'),
    };

    return {
      id: '1',
      name: disasterNames[activeType] || t('disasters.earthquake'),
      type: activeType,
      severity: 'high',
      actions: [
        {
          id: 1,
          title: t('guide.immediateActions'),
          description: t('guide.safetyTips'),
          icon: '🏃',
          priority: 'immediate',
        },
        {
          id: 2,
          title: t('family.quickShare') || 'Quick Safety Share',
          description: t('family.shareInfo') || 'Share your status with family',
          icon: '📱',
          priority: 'urgent',
        },
        {
          id: 3,
          title: t('actions.searchShelter'),
          description: t('guide.evacuationSteps'),
          icon: '🏫',
          priority: 'important',
        },
      ],
      supplies: getSupplies(activeType),
      estimatedDuration: '30-60 min',
    };
  }, [t, activeType]);

  const [completedSteps, setCompletedSteps] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem(`evacora_steps_${activeType}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  // Persist completed steps per disaster type
  useEffect(() => {
    localStorage.setItem(`evacora_steps_${activeType}`, JSON.stringify(completedSteps));
  }, [completedSteps, activeType]);

  // Load saved steps when disaster type changes
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`evacora_steps_${activeType}`);
      if (saved) setCompletedSteps(JSON.parse(saved));
      else setCompletedSteps([]);
    } catch {
      setCompletedSteps([]);
    }
  }, [activeType]);

  const toggleStep = (stepId: number) => {
    setCompletedSteps((prev) =>
      prev.includes(stepId) ? prev.filter((id) => id !== stepId) : [...prev, stepId]
    );
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'immediate': return 'bg-red-100 text-red-700 border-red-300';
      case 'urgent': return 'bg-orange-100 text-orange-700 border-orange-300';
      case 'important': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const getPriorityLabel = (priority: string) => {
    const labels: Record<string, string> = {
      immediate: t('alerts.highRisk'),
      urgent: t('alerts.mediumRisk'),
      important: t('alerts.safeStatus'),
    };
    return labels[priority] || priority;
  };

  const progressPercent = Math.round((completedSteps.length / currentScenario.actions.length) * 100);

  // Disaster type tabs
  const disasterTypes = [
    { id: 'earthquake', icon: '🌍', label: t('disasters.earthquake') },
    { id: 'wildfire', icon: '🔥', label: t('disasters.wildfire') },
    { id: 'typhoon', icon: '🌀', label: t('disasters.typhoon') },
    { id: 'tsunami', icon: '🌊', label: t('disasters.tsunami') },
    { id: 'flood', icon: '💧', label: t('disasters.flood') },
    { id: 'tornado', icon: '🌪️', label: t('disasters.tornado') },
    { id: 'war', icon: '⚔️', label: t('disasters.war') },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button onClick={() => navigate("/home")} className="text-slate-600 hover:text-slate-900 transition-colors" aria-label="Back">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-slate-900">{t('home.actionGuide')}</h1>
        </div>

        {/* Disaster Type Tabs - 2-line layout: icon on top, name below */}
        <div className="mb-4 overflow-x-auto" style={{ WebkitOverflowScrolling: 'touch' }}>
          <div className="flex gap-2.5 pb-2">
            {disasterTypes.map((dt) => (
              <button
                key={dt.id}
                onClick={() => { setActiveType(dt.id); setCompletedSteps([]); }}
                className={`flex flex-col items-center gap-1 px-3 py-2.5 rounded-2xl transition-all flex-shrink-0 min-w-[64px] ${
                  activeType === dt.id
                    ? 'bg-red-600 text-white shadow-lg shadow-red-600/30 scale-105'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                }`}
              >
                <span className="text-xl leading-none">{dt.icon}</span>
                <span className="text-[11px] font-medium text-center leading-tight max-w-[60px]">{dt.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Alert Banner */}
        <Card className="mb-6 p-6 bg-gradient-to-r from-red-500 to-red-600 text-white border-0">
          <div className="flex items-start gap-4">
            <AlertCircle className="w-8 h-8 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-2xl font-bold mb-2">{currentScenario.name}</h2>
              <p className="text-red-100">{t('alerts.emergencyMode')}</p>
            </div>
          </div>
        </Card>

        {/* Progress Bar */}
        <Card className="mb-6 p-4 bg-white border-slate-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-slate-700">{t('guide.immediateActions')}</span>
            <span className="text-sm font-bold text-slate-900">{progressPercent}%</span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-3">
            <div
              className="bg-gradient-to-r from-green-500 to-green-600 h-3 rounded-full transition-all"
              style={{ width: `${progressPercent}%` }}
            ></div>
          </div>
        </Card>

        {/* Action Steps */}
        <div className="mb-6">
          <h2 className="text-lg font-bold text-slate-900 mb-4">{t('guide.immediateActions')}</h2>
          <div className="space-y-3">
            {currentScenario.actions.map((action) => (
              <Card
                key={action.id}
                className={`p-4 border-2 cursor-pointer transition-all ${
                  completedSteps.includes(action.id)
                    ? 'bg-green-50 border-green-300'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
                onClick={() => {
                  if (action.id === 2) {
                    // Quick Safety Share button
                    setIsQuickShareOpen(true);
                  } else {
                    toggleStep(action.id);
                  }
                }}
              >
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 mt-1">
                    {completedSteps.includes(action.id) ? (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    ) : (
                      <div className="w-6 h-6 rounded-full border-2 border-slate-300"></div>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-1">
                      <h3 className={`font-bold ${completedSteps.includes(action.id) ? 'text-green-700 line-through' : 'text-slate-900'}`}>
                        {action.icon} {action.title}
                      </h3>
                      <span className={`text-xs font-semibold px-2 py-1 rounded-full border ${getPriorityColor(action.priority)}`}>
                        {getPriorityLabel(action.priority)}
                      </span>
                    </div>
                    <p className="text-sm text-slate-600">{action.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Required Supplies - Now with actual items */}
        <Card className="mb-6 p-4 bg-white border-slate-200">
          <div className="flex items-center gap-2 mb-4">
            <Package className="w-5 h-5 text-amber-600" />
            <h2 className="text-lg font-bold text-slate-900">{t('guide.whatToBring')}</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {currentScenario.supplies.map((supply, idx) => (
              <div key={idx} className="flex items-center gap-2 p-3 bg-amber-50 rounded-xl border border-amber-100">
                <span className="text-lg flex-shrink-0">{supply.icon}</span>
                <span className="text-sm text-slate-700 font-medium">{supply.name}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Estimated Duration */}
        <Card className="mb-6 p-4 bg-blue-50 border-blue-200">
          <div className="flex items-center gap-3">
            <Clock className="w-5 h-5 text-blue-600" />
            <div>
              <p className="text-sm font-semibold text-blue-900">{currentScenario.estimatedDuration}</p>
            </div>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4">
          <Button
            className="bg-blue-600 hover:bg-blue-700 text-white py-6 flex items-center justify-center gap-2"
            onClick={() => navigate(`/guides?type=${activeType}`)}
          >
            <Volume2 className="w-5 h-5" />
            {t('actions.viewGuide')}
          </Button>
          <Button
            className="bg-green-600 hover:bg-green-700 text-white py-6 flex items-center justify-center gap-2"
            onClick={() => navigate("/map")}
          >
            <MapPin className="w-5 h-5" />
            {t('actions.searchShelter')}
          </Button>
        </div>

        {/* Quick Safety Share Modal */}
        <QuickSafetyShare isOpen={isQuickShareOpen} onClose={() => setIsQuickShareOpen(false)} disasterType={activeType} />
      </div>
    </div>
  );
}
