import { useI18n } from '@/contexts/I18nContext';
import { ArrowLeft } from 'lucide-react';
import { useLocation } from 'wouter';

export default function PrivacyPolicy() {
  const { t, language } = useI18n();
  const [, navigate] = useLocation();

  const content = {
    en: {
      title: 'Privacy Policy',
      lastUpdated: 'Last Updated: April 2026',
      sections: [
        {
          heading: '1. Information We Collect',
          content: 'Evacora collects the following information to provide emergency guidance and safety services: (a) Location data - your current GPS coordinates, collected only when you enable location sharing or request shelter routing; (b) Contact information - names and phone numbers of emergency contacts you add; (c) Device information - device type, OS version, and app version for crash reporting; (d) Usage data - which features you use and how often, to improve the app.'
        },
        {
          heading: '2. How We Use Your Information',
          content: 'We use your information to: (a) Provide real-time disaster guidance and nearest shelter routing; (b) Enable family location sharing when you opt-in; (c) Send SMS safety check-ins and SOS alerts to your contacts; (d) Improve app performance and fix bugs; (e) Comply with legal obligations.'
        },
        {
          heading: '3. Data Sharing',
          content: 'We do NOT sell your data. We only share your information with: (a) Emergency contacts you explicitly add; (b) Your family members if you enable location sharing; (c) Service providers (Twilio for SMS, Google Maps for routing); (d) Law enforcement if legally required.'
        },
        {
          heading: '4. Data Security',
          content: 'Your data is encrypted in transit and at rest. We use industry-standard security measures including TLS 1.3 for all communications and secure database encryption. However, no system is 100% secure. If you believe your data has been compromised, contact us immediately at security@evacora.app.'
        },
        {
          heading: '5. Your Rights',
          content: 'You have the right to: (a) Access your personal data; (b) Request deletion of your data (except where legally required to retain); (c) Opt-out of location sharing at any time; (d) Disable push notifications and SMS alerts. To exercise these rights, email privacy@evacora.app.'
        },
        {
          heading: '6. Children\'s Privacy',
          content: 'Evacora is not intended for children under 13. We do not knowingly collect data from children under 13. If we discover we have collected such data, we will delete it immediately.'
        },
        {
          heading: '7. Changes to This Policy',
          content: 'We may update this Privacy Policy periodically. We will notify you of significant changes via the app or email. Your continued use of Evacora after changes constitutes acceptance of the updated policy.'
        },
        {
          heading: '8. Contact Us',
          content: 'If you have questions about this Privacy Policy, contact us at: privacy@evacora.app'
        }
      ]
    },
    ko: {
      title: '개인정보보호정책',
      lastUpdated: '최종 수정: 2026년 4월',
      sections: [
        {
          heading: '1. 수집하는 정보',
          content: 'Evacora는 긴급 지침 및 안전 서비스를 제공하기 위해 다음 정보를 수집합니다: (a) 위치 데이터 - 위치 공유를 활성화하거나 대피소 경로를 요청할 때만 수집; (b) 연락처 정보 - 추가한 비상 연락처의 이름과 전화번호; (c) 기기 정보 - 기기 유형, OS 버전, 앱 버전; (d) 사용 데이터 - 기능 사용 현황 및 빈도.'
        },
        {
          heading: '2. 정보 사용 방식',
          content: '우리는 다음 목적으로 정보를 사용합니다: (a) 실시간 재난 지침 및 가장 가까운 대피소 경로 제공; (b) 선택한 가족 위치 공유 활성화; (c) SMS 안전 확인 및 SOS 알림 전송; (d) 앱 성능 개선 및 버그 수정; (e) 법적 의무 준수.'
        },
        {
          heading: '3. 데이터 공유',
          content: '우리는 데이터를 판매하지 않습니다. 다음과만 공유합니다: (a) 명시적으로 추가한 비상 연락처; (b) 위치 공유를 활성화한 가족 구성원; (c) 서비스 제공자(SMS용 Twilio, 경로용 Google Maps); (d) 법적으로 요구되는 경우 법 집행 기관.'
        },
        {
          heading: '4. 데이터 보안',
          content: '모든 데이터는 전송 중 및 저장 중 암호화됩니다. TLS 1.3 및 보안 데이터베이스 암호화를 사용합니다. 데이터 침해 의심 시 security@evacora.app으로 연락주세요.'
        },
        {
          heading: '5. 사용자의 권리',
          content: '다음 권리가 있습니다: (a) 개인 데이터 접근; (b) 데이터 삭제 요청; (c) 언제든지 위치 공유 비활성화; (d) 푸시 알림 및 SMS 비활성화. privacy@evacora.app으로 요청하세요.'
        },
        {
          heading: '6. 아동 개인정보보호',
          content: 'Evacora는 13세 미만 아동을 대상으로 하지 않습니다. 13세 미만 아동의 데이터를 수집하면 즉시 삭제합니다.'
        },
        {
          heading: '7. 정책 변경',
          content: '정책을 주기적으로 업데이트할 수 있습니다. 중요한 변경 사항은 앱이나 이메일로 알립니다.'
        },
        {
          heading: '8. 문의',
          content: '질문이 있으시면 privacy@evacora.app으로 연락주세요.'
        }
      ]
    }
  };

  const currentContent = content[language as keyof typeof content] || content.en;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6 flex items-center gap-3">
          <button onClick={() => navigate("/home")} className="text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">{currentContent.title}</h1>
            <p className="text-sm text-slate-500 mt-1">{currentContent.lastUpdated}</p>
          </div>
        </div>

        <div className="space-y-6 pb-8">
          {currentContent.sections.map((section, idx) => (
            <div key={idx} className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
              <h2 className="text-lg font-bold text-slate-900 mb-3">{section.heading}</h2>
              <p className="text-slate-600 leading-relaxed text-sm">{section.content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
