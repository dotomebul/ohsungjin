import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Trash2, Edit2, Phone, Mail, Heart, ArrowLeft, Share2 } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/contexts/I18nContext";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

export default function EmergencyContacts() {
  const { t } = useI18n();
  const [, navigate] = useLocation();
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    phoneNumber: "",
    email: "",
    relationship: "",
    isPrimary: false,
  });

  const { data: contacts = [], refetch } = trpc.contacts.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // 연락처 그룹화
  const groupedContacts = {
    primary: contacts.filter(c => c.isPrimary),
    family: contacts.filter(c => !c.isPrimary && c.relationship?.toLowerCase().includes('family')),
    friends: contacts.filter(c => !c.isPrimary && c.relationship?.toLowerCase().includes('friend')),
    emergency: contacts.filter(c => !c.isPrimary && c.relationship?.toLowerCase().includes('emergency')),
    other: contacts.filter(c => !c.isPrimary && !c.relationship?.toLowerCase().includes('family') && !c.relationship?.toLowerCase().includes('friend') && !c.relationship?.toLowerCase().includes('emergency')),
  };

  const addContactMutation = trpc.contacts.add.useMutation({
    onSuccess: () => {
      toast.success(t('common.success'));
      setFormData({ name: "", phoneNumber: "", email: "", relationship: "", isPrimary: false });
      setEditingId(null);
      setIsOpen(false);
      refetch();
    },
    onError: () => {
      toast.error(t('common.error'));
    },
  });

  const deleteContactMutation = trpc.contacts.delete.useMutation({
    onSuccess: () => {
      toast.success(t('common.success'));
      refetch();
    },
  });

  const handleAddContact = async () => {
    if (!formData.name || !formData.phoneNumber) {
      toast.error(t('contact.name') + " & " + t('contact.phone'));
      return;
    }
    await addContactMutation.mutateAsync(formData);
  };

  const handleDeleteContact = (contactId: number) => {
    if (confirm(t('contact.confirmDelete'))) {
      deleteContactMutation.mutate({ contactId });
    }
  };

  const handleEditContact = (contact: any) => {
    setEditingId(contact.id);
    setFormData({
      name: contact.name,
      phoneNumber: contact.phoneNumber,
      email: contact.email,
      relationship: contact.relationship,
      isPrimary: contact.isPrimary,
    });
    setIsOpen(true);
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setFormData({ name: "", phoneNumber: "", email: "", relationship: "", isPrimary: false });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate("/home")} className="text-slate-400 hover:text-white transition-colors">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">{t('contact.title')}</h1>
              <p className="text-slate-300">{t('contact.subtitle')}</p>
            </div>
          </div>
          <Dialog open={isOpen} onOpenChange={(open) => {
            if (!open) handleCancelEdit();
            setIsOpen(open);
          }}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700 h-12 px-6 text-lg">
                <Plus className="w-5 h-5 mr-2" />
                {t('contact.addNew')}
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-800 border-slate-700">
              <DialogHeader>
                <DialogTitle className="text-white">{editingId ? 'Edit Contact' : t('contact.addNew')}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label className="text-slate-300">{t('contact.name')} *</Label>
                  <Input
                    placeholder={t('contact.name')}
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-slate-300">{t('contact.phone')} *</Label>
                  <Input
                    placeholder={t('contact.phone')}
                    value={formData.phoneNumber}
                    onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-slate-300">{t('contact.email')}</Label>
                  <Input
                    placeholder={t('contact.email')}
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-slate-300">Relationship</Label>
                  <Input
                    placeholder="e.g., Family, Friend, Emergency"
                    value={formData.relationship}
                    onChange={(e) => setFormData({ ...formData, relationship: e.target.value })}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="isPrimary"
                    checked={formData.isPrimary}
                    onChange={(e) => setFormData({ ...formData, isPrimary: e.target.checked })}
                    className="w-4 h-4 rounded accent-blue-600"
                  />
                  <Label htmlFor="isPrimary" className="text-slate-300 cursor-pointer">Mark as Primary Contact</Label>
                </div>
                <Button
                  onClick={handleAddContact}
                  disabled={addContactMutation.isPending}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white h-10"
                >
                  {addContactMutation.isPending ? t('common.loading') : editingId ? 'Update' : t('actions.addContact')}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Contacts List */}
        <div className="space-y-4">
          {!isAuthenticated && !authLoading ? (
            <Card className="bg-slate-700 border-slate-600 p-12 text-center">
              <Heart className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <p className="text-slate-300 text-lg">{t('common.loginRequired')}</p>
              <p className="text-slate-400 text-sm mt-2 mb-4">{t('contact.addFirst')}</p>
              <Button
                className="bg-blue-600 hover:bg-blue-700 text-white"
                onClick={() => { window.location.href = getLoginUrl(); }}
              >
                {t('common.login')}
              </Button>
            </Card>
          ) : contacts.length === 0 ? (
            <Card className="bg-slate-700 border-slate-600 p-12 text-center">
              <Heart className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <p className="text-slate-300 text-lg">{t('contact.noContacts')}</p>
              <p className="text-slate-400 text-sm mt-2">{t('contact.addFirst')}</p>
            </Card>
          ) : (
            Object.entries(groupedContacts).map(([group, groupContacts]) => (
              groupContacts.length > 0 && (
                <div key={group}>
                  <h3 className="text-lg font-bold text-white mb-3 capitalize">
                    {group === 'primary' ? '⭐ Primary' : group === 'family' ? '👨‍👩‍👧‍👦 Family' : group === 'friends' ? '👥 Friends' : group === 'emergency' ? '🚨 Emergency' : '📋 Other'}
                  </h3>
                  <div className="space-y-3 mb-6">
                    {groupContacts.map((contact) => (
                      <Card key={contact.id} className="bg-slate-700 border-slate-600 p-6 hover:bg-slate-600 transition">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="text-xl font-bold text-white">{contact.name}</h3>
                              {contact.isPrimary && (
                                <span className="bg-red-600 text-white text-xs px-2 py-1 rounded-full">{t('contact.primary')}</span>
                              )}
                            </div>
                            <div className="space-y-1 text-slate-300">
                              {contact.phoneNumber && (
                                <div className="flex items-center gap-2">
                                  <Phone className="w-4 h-4" />
                                  <a href={`tel:${contact.phoneNumber}`} className="hover:text-blue-400">{contact.phoneNumber}</a>
                                </div>
                              )}
                              {contact.email && (
                                <div className="flex items-center gap-2">
                                  <Mail className="w-4 h-4" />
                                  <a href={`mailto:${contact.email}`} className="hover:text-blue-400">{contact.email}</a>
                                </div>
                              )}
                              {contact.relationship && (
                                <p className="text-sm text-slate-400">{contact.relationship}</p>
                              )}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className="border-slate-500 text-slate-300 hover:bg-slate-600"
                              onClick={() => handleEditContact(contact)}
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button variant="outline" size="sm" className="border-red-500 text-red-400 hover:bg-red-600/20" onClick={() => handleDeleteContact(contact.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              )
            ))
          )}
        </div>

        {/* Quick Actions */}
        {contacts.length > 0 && (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button className="bg-green-600 hover:bg-green-700 text-white h-12 text-lg">
              ✓ {t('contact.sendSafetyAll')}
            </Button>
            <Button className="bg-red-600 hover:bg-red-700 text-white h-12 text-lg">
              🆘 {t('contact.sendSOSAll')}
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white h-12 text-lg">
              <Share2 className="w-5 h-5 mr-2" />
              Share Contacts
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
