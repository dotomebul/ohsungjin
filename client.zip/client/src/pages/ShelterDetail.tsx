/**
 * Evacora - Shelter Detail Page
 * Shows capacity, facilities, supplies, directions
 */

import { useEffect, useState, useMemo } from "react";
import { ArrowLeft, Phone, Navigation, MapPin, Users, Package, Shield, Clock, ExternalLink, Share2 } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/contexts/I18nContext";
import { useLocation, useParams } from "wouter";
import { ALL_SHELTERS } from "@shared/shelterData";

export default function ShelterDetail() {
  const { t } = useI18n();
  const [, navigate] = useLocation();
  const params = useParams<{ id: string }>();
  const shelterId = params.id;

  // Find shelter from static data (matching by numeric index or id string)
  const shelter = useMemo(() => {
    if (!shelterId) return null;
    // Try numeric index first (from DB id)
    const numId = parseInt(shelterId);
    if (!isNaN(numId) && numId > 0 && numId <= ALL_SHELTERS.length) {
      return ALL_SHELTERS[numId - 1];
    }
    // Try string id match
    return ALL_SHELTERS.find((s) => s.id === shelterId) || null;
  }, [shelterId]);

  // Simulated occupancy
  const [currentOccupancy] = useState(() =>
    shelter ? Math.floor(Math.random() * (shelter.capacity * 0.7)) : 0
  );
  const occupancyPercent = shelter ? Math.round((currentOccupancy / shelter.capacity) * 100) : 0;
  const availableSpots = shelter ? shelter.capacity - currentOccupancy : 0;

  if (!shelter) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-slate-900 mb-2">{t('shelterDetail.notFound')}</h2>
          <button
            onClick={() => navigate("/map")}
            className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            {t('shelterDetail.backToMap')}
          </button>
        </div>
      </div>
    );
  }

  const occupancyColor =
    occupancyPercent < 50 ? "text-green-600 bg-green-100" :
    occupancyPercent < 80 ? "text-amber-600 bg-amber-100" :
    "text-red-600 bg-red-100";

  const barColor =
    occupancyPercent < 50 ? "bg-green-500" :
    occupancyPercent < 80 ? "bg-amber-500" :
    "bg-red-500";

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-3xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/map")}
              className="text-slate-600 hover:text-slate-900 transition-colors"
              aria-label={t('shelterDetail.backToMap')}
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div className="flex-1 min-w-0">
              <h1 className="text-xl font-bold text-slate-900 truncate">{shelter.name}</h1>
              <p className="text-sm text-slate-500">{shelter.type}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-3">
          <a
            href={`https://www.google.com/maps/dir/?api=1&destination=${shelter.lat},${shelter.lng}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 bg-blue-600 text-white py-3.5 rounded-xl font-semibold hover:bg-blue-700 transition-colors"
          >
            <Navigation className="w-5 h-5" />
            {t('shelterDetail.getDirections')}
          </a>
          <button
            onClick={() => {
              const shareText = `🏠 I'm heading to ${shelter.name}\n📍 ${shelter.address}\n🗺️ https://www.google.com/maps?q=${shelter.lat},${shelter.lng}\n\nSent via Evacora Emergency App`;
              if (navigator.share) {
                navigator.share({ title: 'My Shelter Location', text: shareText })
                  .catch(() => {});
              } else {
                navigator.clipboard.writeText(shareText).then(() => {
                  toast.success('Location copied to clipboard!', {
                    description: 'Share this with your family members.',
                  });
                }).catch(() => {
                  toast.error('Could not share location');
                });
              }
            }}
            className="flex items-center justify-center gap-2 bg-purple-600 text-white py-3.5 rounded-xl font-semibold hover:bg-purple-700 transition-colors"
          >
            <Share2 className="w-5 h-5" />
            {t('shelterDetail.shareLocation') || 'Share Location'}
          </button>
        </div>
        {/* Call button if phone available */}
        {shelter.phone && (
          <a
            href={`tel:${shelter.phone}`}
            className="flex items-center justify-center gap-2 bg-green-600 text-white py-3.5 rounded-xl font-semibold hover:bg-green-700 transition-colors w-full"
          >
            <Phone className="w-5 h-5" />
            {t('shelterDetail.callShelter')}
          </a>
        )}

        {/* Overview Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100">
            <h2 className="text-lg font-bold text-slate-900">{t('shelterDetail.overview')}</h2>
          </div>
          <div className="p-5 space-y-4">
            {/* Address */}
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-slate-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-slate-500">{t('mapPage.address')}</p>
                <p className="font-medium text-slate-900">{shelter.address}</p>
              </div>
            </div>

            {/* Phone */}
            {shelter.phone && (
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-slate-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm text-slate-500">{t('mapPage.phone')}</p>
                  <a href={`tel:${shelter.phone}`} className="font-medium text-blue-600 hover:text-blue-700">
                    {shelter.phone}
                  </a>
                </div>
              </div>
            )}

            {/* Website */}
            {shelter.website && (
              <div className="flex items-start gap-3">
                <ExternalLink className="w-5 h-5 text-slate-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm text-slate-500">Website</p>
                  <a href={shelter.website} target="_blank" rel="noopener noreferrer" className="font-medium text-blue-600 hover:text-blue-700 truncate block">
                    {shelter.website}
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Capacity Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-900">{t('shelterDetail.capacity')}</h2>
              <span className={`px-3 py-1 rounded-full text-xs font-semibold ${occupancyColor}`}>
                {occupancyPercent}%
              </span>
            </div>
          </div>
          <div className="p-5">
            {/* Progress bar */}
            <div className="w-full bg-slate-200 rounded-full h-4 mb-4">
              <div className={`h-4 rounded-full transition-all duration-500 ${barColor}`} style={{ width: `${occupancyPercent}%` }} />
            </div>

            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-slate-50 rounded-xl p-3">
                <Users className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                <p className="text-2xl font-bold text-slate-900">{shelter.capacity.toLocaleString()}</p>
                <p className="text-xs text-slate-500">{t('shelterDetail.capacity')}</p>
              </div>
              <div className="bg-slate-50 rounded-xl p-3">
                <Users className="w-5 h-5 text-amber-600 mx-auto mb-1" />
                <p className="text-2xl font-bold text-slate-900">{currentOccupancy.toLocaleString()}</p>
                <p className="text-xs text-slate-500">{t('shelterDetail.currentOccupancy')}</p>
              </div>
              <div className="bg-slate-50 rounded-xl p-3">
                <Users className="w-5 h-5 text-green-600 mx-auto mb-1" />
                <p className="text-2xl font-bold text-green-700">{availableSpots.toLocaleString()}</p>
                <p className="text-xs text-slate-500">{t('shelterDetail.available')}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Facilities Card */}
        {shelter.amenities && shelter.amenities.length > 0 && (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100">
              <h2 className="text-lg font-bold text-slate-900">{t('shelterDetail.facilities')}</h2>
            </div>
            <div className="p-5">
              <div className="flex flex-wrap gap-2">
                {shelter.amenities.map((amenity, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-2 bg-blue-50 text-blue-700 rounded-lg text-sm font-medium border border-blue-100"
                  >
                    {amenity}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Supplies Card */}
        {shelter.supplies && shelter.supplies.length > 0 && (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Package className="w-5 h-5 text-slate-700" />
                <h2 className="text-lg font-bold text-slate-900">{t('shelterDetail.supplies')}</h2>
              </div>
            </div>
            <div className="divide-y divide-slate-100">
              {/* Table header */}
              <div className="grid grid-cols-3 px-5 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <span>{t('shelterDetail.supplyName')}</span>
                <span className="text-right">{t('shelterDetail.quantity')}</span>
                <span className="text-right">{t('shelterDetail.unit')}</span>
              </div>
              {shelter.supplies.map((supply, idx) => (
                <div key={idx} className="grid grid-cols-3 px-5 py-3.5 items-center hover:bg-slate-50 transition-colors">
                  <span className="text-sm font-medium text-slate-900">{supply.name}</span>
                  <span className="text-sm text-slate-700 text-right font-semibold">{supply.quantity.toLocaleString()}</span>
                  <span className="text-sm text-slate-500 text-right">{supply.unit}</span>
                </div>
              ))}
            </div>
            <div className="px-5 py-3 bg-slate-50 border-t border-slate-100">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <Clock className="w-3.5 h-3.5" />
                <span>{t('shelterDetail.lastUpdated')}: {new Date().toLocaleDateString()}</span>
              </div>
            </div>
          </div>
        )}

        {/* Disaster Types */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100">
            <h2 className="text-lg font-bold text-slate-900">{t('shelterDetail.disasterTypes')}</h2>
          </div>
          <div className="p-5">
            <div className="flex flex-wrap gap-2">
              {shelter.disasterTypes.map((dtype, idx) => {
                const disasterKey = dtype as keyof typeof t extends never ? string : string;
                const label = (t as any)(`disasters.${dtype}`) || dtype;
                const colors: Record<string, string> = {
                  earthquake: "bg-amber-50 text-amber-700 border-amber-200",
                  wildfire: "bg-red-50 text-red-700 border-red-200",
                  hurricane: "bg-purple-50 text-purple-700 border-purple-200",
                  tornado: "bg-gray-50 text-gray-700 border-gray-200",
                  flood: "bg-blue-50 text-blue-700 border-blue-200",
                  tsunami: "bg-cyan-50 text-cyan-700 border-cyan-200",
                  typhoon: "bg-indigo-50 text-indigo-700 border-indigo-200",
                  war: "bg-red-50 text-red-800 border-red-200",
                  bombing: "bg-orange-50 text-orange-700 border-orange-200",
                  nuclear: "bg-yellow-50 text-yellow-700 border-yellow-200",
                  chemical: "bg-green-50 text-green-700 border-green-200",
                };
                return (
                  <span
                    key={idx}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium border ${colors[dtype] || "bg-slate-50 text-slate-700 border-slate-200"}`}
                  >
                    {label}
                  </span>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
