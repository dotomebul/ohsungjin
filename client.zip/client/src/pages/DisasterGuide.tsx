import { useState, useRef, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronRight, AlertCircle, CheckCircle2, Package, ArrowLeft, ChevronDown } from "lucide-react";
import { useI18n } from "@/contexts/I18nContext";
import { useLocation, useSearch } from "wouter";
import { Region } from "@shared/i18n/translations";

export default function DisasterGuide() {
  const { t, region } = useI18n();
  const [, navigate] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const typeFromUrl = params.get("type");

  // Server API supports us, eu, global only
  const regionToApi = (r: Region): "us" | "eu" | "global" => {
    if (r === 'us') return 'us';
    if (r === 'eu') return 'eu';
    return 'global';
  };
  const [selectedRegion, setSelectedRegion] = useState<Region>(region);
  const [selectedDisaster, setSelectedDisaster] = useState<string | null>(typeFromUrl);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    overview: true,
    immediate: true,
    evacuation: true,
    safety: true,
    supplies: true,
    contacts: true,
  });
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>({});

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const toggleItem = (itemId: string) => {
    setExpandedItems(prev => ({ ...prev, [itemId]: !prev[itemId] }));
  };

  const { data: disasters = [] } = trpc.disasters.list.useQuery({
    region: regionToApi(selectedRegion),
  });

  // Auto-select disaster from URL param when disasters load
  useEffect(() => {
    if (typeFromUrl && disasters.length > 0 && !selectedDisaster) {
      const match = disasters.find(d => d.code === typeFromUrl);
      if (match) setSelectedDisaster(match.code);
    }
  }, [typeFromUrl, disasters]);

  const { data: guide } = trpc.disasters.getGuide.useQuery(
    { disasterCode: selectedDisaster || "" },
    { enabled: !!selectedDisaster }
  );

  const regionFlags: Record<Region, string> = { us: "🇺🇸", eu: "🇪🇺", kr: "🇰🇷", jp: "🇯🇵" };
  const regionNames: Record<Region, string> = {
    us: t('regions.unitedStates'),
    eu: t('regions.europe'),
    kr: t('regions.korea'),
    jp: t('regions.japan'),
  };

  const scrollRef = useRef<HTMLDivElement>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <div className="max-w-4xl mx-auto px-4 py-4">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button onClick={() => navigate("/home")} className="text-slate-400 hover:text-white transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">{t('guide.title')}</h1>
            <p className="text-sm text-slate-400">{t('guide.selectDisaster')}</p>
          </div>
        </div>

        {/* Region Selector - Compact horizontal pills */}
        <div className="flex gap-2 mb-5 overflow-x-auto pb-1 scrollbar-hide">
          {(["us", "eu", "kr", "jp"] as Region[]).map((r) => (
            <button
              key={r}
              onClick={() => { setSelectedRegion(r); setSelectedDisaster(null); }}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all flex-shrink-0 ${
                selectedRegion === r
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <span>{regionFlags[r]}</span>
              <span>{regionNames[r]}</span>
            </button>
          ))}
        </div>

        {/* Disaster Type Selector - Horizontal scroll with icon on top, name below */}
        <div className="mb-6">
          <div
            ref={scrollRef}
            className="flex gap-3 overflow-x-auto pb-3 scrollbar-hide"
            style={{ WebkitOverflowScrolling: 'touch' }}
          >
            {disasters.map((disaster) => (
              <button
                key={disaster.code}
                onClick={() => setSelectedDisaster(disaster.code)}
                className={`flex flex-col items-center gap-1.5 px-3 py-3 rounded-2xl transition-all flex-shrink-0 min-w-[72px] ${
                  selectedDisaster === disaster.code
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30 scale-105'
                    : 'bg-slate-700/60 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span className="text-2xl leading-none">{disaster.icon}</span>
                <span className="text-xs font-medium text-center leading-tight max-w-[64px]">
                  {disaster.name}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Guide Content */}
        {guide && (
          <div className="space-y-5">
            <Card className="bg-gradient-to-r from-red-600 to-red-700 text-white p-5 border-0 rounded-2xl">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-7 h-7 flex-shrink-0 mt-0.5" />
                <div>
                  <h2 className="text-xl font-bold mb-1">{guide.name}</h2>
                  <p className="text-red-100 text-sm">{t('alerts.emergencyMode')}</p>
                </div>
              </div>
            </Card>

            <Card className="bg-slate-700/80 border-slate-600 rounded-2xl overflow-hidden">
              <button
                onClick={() => toggleSection('immediate')}
                className="w-full px-5 py-4 flex items-center justify-between hover:bg-slate-600/50 transition-colors"
              >
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-red-400" />
                  {t('guide.immediateActions')}
                </h3>
                <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform ${expandedSections.immediate ? 'rotate-180' : ''}`} />
              </button>
              {expandedSections.immediate && (
                <div className="px-5 pb-5 space-y-3">
                  {guide.immediateActions?.map((action, idx) => (
                    <div key={idx} className="flex items-start gap-3 text-slate-100">
                      <span className="text-red-400 font-bold text-base flex-shrink-0">{idx + 1}.</span>
                      <span className="text-sm leading-relaxed">{action}</span>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <Card className="bg-slate-700/80 border-slate-600 rounded-2xl overflow-hidden">
              <button
                onClick={() => toggleSection('evacuation')}
                className="w-full px-5 py-4 flex items-center justify-between hover:bg-slate-600/50 transition-colors"
              >
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <ChevronRight className="w-5 h-5 text-blue-400" />
                  {t('guide.evacuationSteps')}
                </h3>
                <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform ${expandedSections.evacuation ? 'rotate-180' : ''}`} />
              </button>
              {expandedSections.evacuation && (
                <div className="px-5 pb-5 space-y-3">
                  {guide.evacuationSteps?.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-3 text-slate-100">
                      <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-xs font-bold">{idx + 1}</span>
                      <span className="text-sm leading-relaxed">{step}</span>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <Card className="bg-slate-700/80 border-slate-600 rounded-2xl overflow-hidden">
              <button
                onClick={() => toggleSection('safety')}
                className="w-full px-5 py-4 flex items-center justify-between hover:bg-slate-600/50 transition-colors"
              >
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-400" />
                  {t('guide.safetyTips')}
                </h3>
                <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform ${expandedSections.safety ? 'rotate-180' : ''}`} />
              </button>
              {expandedSections.safety && (
                <div className="px-5 pb-5 space-y-2">
                  {guide.safetyTips?.map((tip, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-slate-100">
                      <span className="text-green-400 font-bold mt-0.5">✓</span>
                      <span className="text-sm leading-relaxed">{tip}</span>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <Card className="bg-slate-700/80 border-slate-600 rounded-2xl overflow-hidden">
              <button
                onClick={() => toggleSection('supplies')}
                className="w-full px-5 py-4 flex items-center justify-between hover:bg-slate-600/50 transition-colors"
              >
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Package className="w-5 h-5 text-amber-400" />
                  {t('guide.whatToBring')}
                </h3>
                <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform ${expandedSections.supplies ? 'rotate-180' : ''}`} />
              </button>
              {expandedSections.supplies && (
                <div className="px-5 pb-5 grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {guide.whatToBring?.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-slate-100 bg-slate-600/60 p-3 rounded-xl">
                      <input type="checkbox" className="w-4 h-4 rounded accent-amber-500" />
                      <span className="text-sm">{item}</span>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <Card className="bg-gradient-to-r from-emerald-600 to-emerald-700 text-white p-5 border-0 rounded-2xl">
              <h3 className="text-lg font-bold mb-3">{t('home.emergencyContacts')}</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {guide.emergencyNumber && (
                  <div>
                    <p className="text-emerald-100 text-xs">{t('alerts.emergencyMode')}</p>
                    <p className="text-2xl font-bold">{guide.emergencyNumber}</p>
                  </div>
                )}
                {guide.helplineNumber && (
                  <div>
                    <p className="text-emerald-100 text-xs">Helpline</p>
                    <p className="text-2xl font-bold">{guide.helplineNumber}</p>
                  </div>
                )}
              </div>
            </Card>

            <div className="grid grid-cols-2 gap-3 pb-6">
              <Button className="bg-green-600 hover:bg-green-700 text-white h-12 text-base font-semibold rounded-xl">
                ✓ {t('actions.imSafe')}
              </Button>
              <Button className="bg-red-600 hover:bg-red-700 text-white h-12 text-base font-semibold rounded-xl">
                🆘 {t('actions.sendSOS')}
              </Button>
            </div>
          </div>
        )}

        {!guide && disasters.length > 0 && (
          <Card className="bg-slate-700/60 p-10 text-center border-slate-600 rounded-2xl">
            <AlertCircle className="w-10 h-10 text-slate-400 mx-auto mb-3" />
            <p className="text-slate-300 text-base">{t('guide.selectDisaster')}</p>
          </Card>
        )}

        {disasters.length === 0 && (
          <Card className="bg-slate-700/60 p-10 text-center border-slate-600 rounded-2xl">
            <div className="animate-pulse flex flex-col items-center gap-3">
              <div className="w-10 h-10 bg-slate-600 rounded-full" />
              <div className="w-32 h-4 bg-slate-600 rounded" />
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
