import { useState, useEffect } from 'react';
import { useI18n } from '@/contexts/I18nContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Language, Region, getLanguageName } from '@shared/i18n/translations';
import { useLocation } from 'wouter';
import { AlertTriangle, MapPin, Users, Shield, Wifi, WifiOff, ChevronRight } from 'lucide-react';

const AVAILABLE_REGIONS: Region[] = ['us', 'eu', 'kr', 'jp'];

const AUTO_LANGUAGE_REGIONS: Record<string, Language> = {
  us: 'en',
  kr: 'ko',
  jp: 'ja',
};

const MULTI_LANGUAGE_REGIONS: Record<string, Language[]> = {
  eu: ['en', 'es', 'de', 'fr'],
};

export default function Onboarding() {
  const { isOnboardingCompleted, completeOnboarding, setLanguage, setRegion } = useI18n();
  const [, navigate] = useLocation();
  const [step, setStep] = useState<'intro' | 'region' | 'language'>('intro');
  const [selectedRegion, setSelectedRegion] = useState<Region | null>(null);

  useEffect(() => {
    if (isOnboardingCompleted) {
      navigate('/home');
    }
  }, [isOnboardingCompleted, navigate]);

  const handleRegionSelect = (region: Region) => {
    setSelectedRegion(region);
    setRegion(region);

    if (region in AUTO_LANGUAGE_REGIONS) {
      const autoLang = AUTO_LANGUAGE_REGIONS[region];
      setLanguage(autoLang);
      completeOnboarding();
      navigate('/home');
    } else {
      setStep('language');
    }
  };

  const handleLanguageSelect = (lang: Language) => {
    setLanguage(lang);
    completeOnboarding();
    navigate('/home');
  };

  const regionLabels: Record<Region, string> = {
    us: '🇺🇸  United States',
    eu: '🇪🇺  Europe',
    kr: '🇰🇷  대한민국',
    jp: '🇯🇵  日本',
  };

  if (isOnboardingCompleted) return null;

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-4" style={{ background: '#0f172a' }}>
      <div className="max-w-md w-full">

        {/* Step 0: Intro with features */}
        {step === 'intro' && (
          <div className="animate-fade-in">
            {/* Logo & Slogan */}
            <div className="text-center mb-8">
              <h1
                className="text-5xl font-bold text-white mb-3"
                style={{ fontFamily: "'Space Grotesk', sans-serif" }}
              >
                Evacora
              </h1>
              <p className="text-2xl font-bold text-blue-400 leading-tight mb-3">
                Know what to do. Right now.
              </p>
              <p className="text-slate-300 text-sm leading-relaxed">
                Real-time crisis guidance, nearest shelter routing,<br />
                and one-tap safety check-ins.
              </p>
            </div>

            {/* Core Features */}
            <Card className="p-5 bg-slate-800/80 border-slate-700 backdrop-blur-sm mb-4">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center flex-shrink-0">
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-sm">Real-time Alerts</h3>
                    <p className="text-slate-400 text-xs mt-0.5">Instant disaster warnings with action guides tailored to your location</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-sm">Safe Shelter Routing</h3>
                    <p className="text-slate-400 text-xs mt-0.5">Find nearest shelters with capacity, supplies, and directions</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-green-500/20 flex items-center justify-center flex-shrink-0">
                    <Users className="w-5 h-5 text-green-400" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-sm">One-tap Family Check-in</h3>
                    <p className="text-slate-400 text-xs mt-0.5">Send "I'm Safe" or SOS to all contacts with your live location</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Demo Flow */}
            <Card className="p-4 bg-slate-800/60 border-slate-700/50 backdrop-blur-sm mb-4">
              <p className="text-slate-500 text-[10px] font-semibold uppercase tracking-widest mb-3">How it works</p>
              <div className="flex items-center justify-between gap-2 text-center">
                <div className="flex-1">
                  <div className="w-9 h-9 rounded-full bg-red-500/20 flex items-center justify-center mx-auto mb-1.5">
                    <span className="text-sm">🔥</span>
                  </div>
                  <p className="text-white text-[11px] font-medium leading-tight">Wildfire<br />nearby</p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-600 flex-shrink-0" />
                <div className="flex-1">
                  <div className="w-9 h-9 rounded-full bg-blue-500/20 flex items-center justify-center mx-auto mb-1.5">
                    <span className="text-sm">🏫</span>
                  </div>
                  <p className="text-white text-[11px] font-medium leading-tight">Shelter<br />6 min away</p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-600 flex-shrink-0" />
                <div className="flex-1">
                  <div className="w-9 h-9 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-1.5">
                    <span className="text-sm">✅</span>
                  </div>
                  <p className="text-white text-[11px] font-medium leading-tight">Family<br />notified</p>
                </div>
              </div>
            </Card>

            {/* Trust badges */}
            <div className="flex items-center justify-center gap-4 mb-6">
              <div className="flex items-center gap-1.5 text-slate-500">
                <Shield className="w-3.5 h-3.5" />
                <span className="text-[10px] font-medium">Free Safety Tool</span>
              </div>
              <div className="w-1 h-1 rounded-full bg-slate-700" />
              <div className="flex items-center gap-1.5 text-slate-500">
                <WifiOff className="w-3.5 h-3.5" />
                <span className="text-[10px] font-medium">Offline Ready</span>
              </div>
              <div className="w-1 h-1 rounded-full bg-slate-700" />
              <div className="flex items-center gap-1.5 text-slate-500">
                <Wifi className="w-3.5 h-3.5" />
                <span className="text-[10px] font-medium">6 Languages</span>
              </div>
            </div>

            {/* CTA */}
            <Button
              onClick={() => setStep('region')}
              className="w-full py-6 text-base font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-2xl transition-all duration-200"
            >
              Get Started
            </Button>
          </div>
        )}

        {/* Step 1: Region Selection */}
        {step === 'region' && (
          <div className="animate-fade-in">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-white mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Evacora
              </h1>
              <p className="text-blue-400 font-semibold">Know what to do. Right now.</p>
            </div>

            <Card className="p-6 bg-slate-800/80 border-slate-700 backdrop-blur-sm">
              <h2 className="text-xl font-bold text-white mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Select Your Region
              </h2>
              <p className="text-slate-400 text-sm mb-5">
                Disaster guides and shelter data will be set for your region.
              </p>
              <div className="grid grid-cols-2 gap-3">
                {AVAILABLE_REGIONS.map((r) => (
                  <button
                    key={r}
                    onClick={() => handleRegionSelect(r)}
                    className="p-5 rounded-xl text-center transition-all duration-200 hover:scale-[1.02] active:scale-95 bg-slate-700/60 text-slate-200 border-2 border-slate-600 hover:border-blue-500 hover:bg-slate-700"
                    aria-label={`Select region: ${r}`}
                  >
                    <div className="text-lg font-semibold">{regionLabels[r]}</div>
                  </button>
                ))}
              </div>
            </Card>

            <div className="text-center mt-4">
              <button onClick={() => setStep('intro')} className="text-slate-500 text-sm hover:text-slate-300 transition-colors">
                ← Back
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Language Selection (EU only) */}
        {step === 'language' && (
          <div className="animate-fade-in">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-white mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Evacora
              </h1>
              <p className="text-blue-400 font-semibold">Know what to do. Right now.</p>
            </div>

            <Card className="p-6 bg-slate-800/80 border-slate-700 backdrop-blur-sm">
              <h2 className="text-xl font-bold text-white mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Select Language
              </h2>
              <p className="text-slate-400 text-sm mb-5">
                Choose your preferred language for the app.
              </p>
              <div className="space-y-2">
                {(MULTI_LANGUAGE_REGIONS[selectedRegion || 'eu'] || ['en']).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => handleLanguageSelect(lang)}
                    className="w-full p-4 rounded-xl text-left transition-all duration-200 hover:scale-[1.01] active:scale-95 bg-slate-700/60 text-slate-200 border-2 border-slate-600 hover:border-blue-500 hover:bg-slate-700"
                    aria-label={`Select language: ${getLanguageName(lang)}`}
                  >
                    <div className="font-semibold text-lg">{getLanguageName(lang)}</div>
                  </button>
                ))}
              </div>
              <Button
                onClick={() => setStep('region')}
                variant="outline"
                className="w-full mt-5 border-slate-600 text-slate-200 hover:bg-slate-700"
              >
                Back
              </Button>
            </Card>
          </div>
        )}

        {/* Footer */}
        <div className="text-center mt-6 text-slate-600 text-[10px]">
          <p>Built for emergency guidance · Free public safety tool</p>
        </div>
      </div>
    </div>
  );
}
