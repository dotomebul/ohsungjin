/**
 * License & Copyright Page
 * Evacora - Crisis Response & Family Safety Application
 */

import { ArrowLeft } from 'lucide-react';
import { useLocation } from 'wouter';
import { useI18n } from '@/contexts/I18nContext';

export default function License() {
  const [, navigate] = useLocation();
  const { t } = useI18n();

  return (
    <div className="min-h-screen w-full bg-white">
      {/* Header */}
      <div className="sticky top-0 z-50 flex items-center gap-3 px-5 py-4 bg-white border-b border-slate-200">
        <button
          onClick={() => navigate('/settings')}
          className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-slate-700" />
        </button>
        <h1 className="text-lg font-bold text-slate-900">License & Copyright</h1>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-5 py-8 space-y-8">
        {/* Copyright Notice */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">© 2024-2026 Evacora</h2>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-900">
              <strong>Evacora</strong> is a crisis response and family safety application designed to provide real-time emergency guidance, shelter routing, and family communication during disasters.
            </p>
          </div>
        </section>

        {/* Copyright & Intellectual Property */}
        <section className="space-y-4">
          <h3 className="text-xl font-bold text-slate-900">Intellectual Property Rights</h3>
          <div className="space-y-3 text-sm text-slate-700">
            <p>
              All content, features, and functionality of the Evacora application, including but not limited to text, graphics, logos, images, audio clips, digital downloads, data compilations, and software, are the exclusive property of Evacora or its content suppliers and are protected by international copyright laws.
            </p>
            <p>
              <strong>Evacora™</strong> is a registered trademark. All rights reserved.
            </p>
            <p>
              You may not reproduce, distribute, transmit, modify, or create derivative works of any content without explicit written permission from Evacora.
            </p>
          </div>
        </section>

        {/* Data Sources & Attribution */}
        <section className="space-y-4">
          <h3 className="text-xl font-bold text-slate-900">Data Sources & Attribution</h3>
          <div className="space-y-3 text-sm text-slate-700">
            <p>
              <strong>Shelter Data:</strong> Sourced from FEMA (USA), EU Emergency Management Services, Japanese GSI (Geospatial Information Authority), and Korean Ministry of Interior and Safety.
            </p>
            <p>
              <strong>Disaster Data:</strong> Real-time data from USGS (Earthquakes), NWS (Weather), GDACS (Global Disasters), and Copernicus Emergency Management Service.
            </p>
            <p>
              <strong>Maps:</strong> Google Maps API integration with proxy authentication provided by Manus platform.
            </p>
            <p>
              <strong>News:</strong> Aggregated from major news sources via NewsAPI and other public news feeds.
            </p>
          </div>
        </section>

        {/* Terms of Use */}
        <section className="space-y-4">
          <h3 className="text-xl font-bold text-slate-900">Terms of Use</h3>
          <div className="space-y-3 text-sm text-slate-700">
            <p>
              By using Evacora, you agree to comply with all applicable laws and regulations. The application is provided "as is" without warranties of any kind.
            </p>
            <p>
              Evacora is not liable for any indirect, incidental, special, or consequential damages arising from the use of this application.
            </p>
            <p>
              Users are responsible for maintaining the confidentiality of their account information and passwords.
            </p>
          </div>
        </section>

        {/* Privacy & Data Protection */}
        <section className="space-y-4">
          <h3 className="text-xl font-bold text-slate-900">Privacy & Data Protection</h3>
          <div className="space-y-3 text-sm text-slate-700">
            <p>
              Evacora is committed to protecting user privacy. Personal data is collected only for emergency response purposes and is handled in accordance with GDPR, CCPA, and other applicable privacy regulations.
            </p>
            <p>
              Location data is encrypted and transmitted securely. Users can control location sharing settings at any time.
            </p>
            <p>
              For detailed privacy information, please refer to our <button onClick={() => navigate('/privacy')} className="text-blue-600 hover:underline">Privacy Policy</button>.
            </p>
          </div>
        </section>

        {/* Open Source & Third-Party */}
        <section className="space-y-4">
          <h3 className="text-xl font-bold text-slate-900">Open Source & Third-Party Libraries</h3>
          <div className="space-y-3 text-sm text-slate-700">
            <p>
              Evacora uses the following open-source libraries:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-2">
              <li><strong>React 19</strong> - UI Framework (MIT License)</li>
              <li><strong>Tailwind CSS 4</strong> - Utility-first CSS (MIT License)</li>
              <li><strong>tRPC 11</strong> - TypeScript RPC Framework (MIT License)</li>
              <li><strong>Drizzle ORM</strong> - Database ORM (Apache 2.0 License)</li>
              <li><strong>Lucide Icons</strong> - Icon Library (ISC License)</li>
              <li><strong>Sonner</strong> - Toast Notifications (MIT License)</li>
              <li><strong>Wouter</strong> - Routing Library (ISC License)</li>
            </ul>
          </div>
        </section>

        {/* Disclaimer */}
        <section className="space-y-4">
          <h3 className="text-xl font-bold text-slate-900">Disclaimer</h3>
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 space-y-2">
            <p className="text-sm text-yellow-900">
              <strong>Emergency Use:</strong> Evacora provides guidance based on available data. In case of immediate emergency, always contact local emergency services (911 in USA, 112 in EU, 119 in Korea, 110 in Japan).
            </p>
            <p className="text-sm text-yellow-900">
              <strong>Data Accuracy:</strong> While we strive for accuracy, real-time disaster data may have delays. Always verify critical information with official sources.
            </p>
            <p className="text-sm text-yellow-900">
              <strong>No Medical Advice:</strong> Evacora does not provide medical advice. Consult healthcare professionals for medical emergencies.
            </p>
          </div>
        </section>

        {/* Contact & Support */}
        <section className="space-y-4">
          <h3 className="text-xl font-bold text-slate-900">Contact & Support</h3>
          <div className="space-y-3 text-sm text-slate-700">
            <p>
              For copyright inquiries, licensing requests, or other legal matters, please contact:
            </p>
            <div className="bg-slate-50 p-4 rounded-lg space-y-2">
              <p><strong>Evacora Legal Team</strong></p>
              <p>Email: <a href="mailto:legal@evacora.app" className="text-blue-600 hover:underline">legal@evacora.app</a></p>
              <p>Website: <a href="https://www.evacora.app" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">www.evacora.app</a></p>
            </div>
          </div>
        </section>

        {/* Version & Last Updated */}
        <section className="space-y-4 border-t border-slate-200 pt-6">
          <div className="text-xs text-slate-500 space-y-1">
            <p><strong>Application Version:</strong> 1.0.0</p>
            <p><strong>Last Updated:</strong> April 28, 2026</p>
            <p><strong>Platform:</strong> Manus Cloud Platform</p>
          </div>
        </section>
      </div>
    </div>
  );
}
