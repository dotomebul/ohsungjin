import { useState } from "react";
import { useLocation, useSearch } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Users, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useEmailAuth } from "@/hooks/useEmailAuth";
import { useAuth } from "@/_core/hooks/useAuth";

interface JoinFamilyProps {
  token?: string;
}

export default function JoinFamily({ token }: JoinFamilyProps) {
  const [, navigate] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const code = token || params.get("code") || "";

  const { emailUser, isLoading: authLoading } = useEmailAuth();
  const { user: oauthUser, isAuthenticated } = useAuth();
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [inviterName, setInviterName] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const acceptMutation = trpc.emailAuth.acceptFamilyInviteCode.useMutation({
    onSuccess: (data) => {
      setInviterName(data.inviterName);
      setStatus("success");
      toast.success(`You are now connected with ${data.inviterName}!`);
    },
    onError: (err) => {
      setStatus("error");
      setErrorMsg(err.message || "Failed to join family");
      toast.error("Failed to join family");
    },
  });

  const handleAccept = async () => {
    if (!code) {
      setErrorMsg("Invalid invitation code");
      return;
    }

    setStatus("loading");
    acceptMutation.mutate({ code });
  };

  return (
    <div className="min-h-screen w-full bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Users className="w-12 h-12 text-blue-500" />
          </div>
          <CardTitle>Join Family Group</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {status === "idle" && (
            <>
              <p className="text-sm text-muted-foreground text-center">
                You have been invited to join a family group. Click below to accept the invitation.
              </p>
              <Button
                onClick={handleAccept}
                disabled={!code || authLoading}
                className="w-full"
              >
                {authLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Loading...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Accept Invitation
                  </>
                )}
              </Button>
            </>
          )}

          {status === "loading" && (
            <div className="text-center py-4">
              <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2 text-blue-500" />
              <p className="text-sm text-muted-foreground">Joining family...</p>
            </div>
          )}

          {status === "success" && (
            <div className="text-center py-4">
              <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-2" />
              <p className="font-semibold mb-2">Welcome to the family!</p>
              <p className="text-sm text-muted-foreground mb-4">
                You are now connected with {inviterName}
              </p>
              <Button
                onClick={() => navigate("/home")}
                className="w-full"
              >
                Go to Home
              </Button>
            </div>
          )}

          {status === "error" && (
            <div className="text-center py-4">
              <XCircle className="w-12 h-12 text-red-500 mx-auto mb-2" />
              <p className="font-semibold mb-2">Failed to join</p>
              <p className="text-sm text-red-600 mb-4">{errorMsg}</p>
              <Button
                onClick={() => setStatus("idle")}
                variant="outline"
                className="w-full"
              >
                Try Again
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
