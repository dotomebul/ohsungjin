import React, { useState, useEffect } from 'react';
import { useI18n } from '@/contexts/I18nContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, MapPin, CheckCircle, Clock, ArrowLeft } from 'lucide-react';
import { useLocation } from 'wouter';

interface ActiveAlert {
  id: string;
  type: string;
  severity: 'high' | 'medium' | 'low';
  timestamp: Date;
  region: string;
}

interface UserStatus {
  location: { lat: number; lng: number } | null;
  lastUpdate: Date | null;
  preparednessLevel: number;
  contactsAdded: number;
  lastCheckIn: Date | null;
}

export default function Dashboard() {
  const { t, region } = useI18n();
  const [, navigate] = useLocation();
  const [alerts, setAlerts] = useState<ActiveAlert[]>([]);
  const [userStatus, setUserStatus] = useState<UserStatus>({
    location: null,
    lastUpdate: null,
    preparednessLevel: 0,
    contactsAdded: 0,
    lastCheckIn: null,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setAlerts([
        {
          id: '1',
          type: 'earthquake',
          severity: 'high',
          timestamp: new Date(),
          region: region,
        },
      ]);
      setUserStatus({
        location: { lat: 37.5665, lng: 126.978 },
        lastUpdate: new Date(),
        preparednessLevel: 65,
        contactsAdded: 3,
        lastCheckIn: new Date(Date.now() - 3600000),
      });
      setLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, [region]);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-100 text-red-700 border-red-300';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'low': return 'bg-green-100 text-green-700 border-green-300';
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">{t('common.loading')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button onClick={() => navigate("/home")} className="text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-1">{t('common.dashboard')}</h1>
            <p className="text-slate-600">{t('alerts.emergencyMode')}</p>
          </div>
        </div>

        {/* Active Alerts */}
        {alerts.length > 0 && (
          <Card className="mb-6 p-6 border-red-200 bg-red-50">
            <div className="flex items-start gap-4">
              <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
              <div className="flex-1">
                <h2 className="text-lg font-bold text-red-900 mb-2">{t('alerts.activeAlert')}</h2>
                <div className="space-y-2">
                  {alerts.map((alert) => (
                    <div key={alert.id} className={`p-3 rounded-lg border ${getSeverityColor(alert.severity)}`}>
                      <p className="font-semibold">{t('disasters.earthquake')}</p>
                      <p className="text-xs opacity-75 mt-1">{alert.timestamp.toLocaleTimeString()}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Status Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <Card className="p-6 bg-white border-slate-200">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-sm font-semibold text-slate-600 uppercase tracking-wide">{t('mapPage.yourLocation')}</h3>
              <MapPin className="w-5 h-5 text-blue-600" />
            </div>
            {userStatus.location ? (
              <div>
                <p className="text-2xl font-bold text-slate-900">{userStatus.location.lat.toFixed(4)}, {userStatus.location.lng.toFixed(4)}</p>
                <p className="text-xs text-slate-500 mt-2">{userStatus.lastUpdate?.toLocaleTimeString()}</p>
              </div>
            ) : (
              <p className="text-slate-500">{t('home.noLocation')}</p>
            )}
          </Card>

          <Card className="p-6 bg-white border-slate-200">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-sm font-semibold text-slate-600 uppercase tracking-wide">{t('home.conditions')}</h3>
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <div className="flex items-end justify-between mb-2">
                <p className="text-2xl font-bold text-slate-900">{userStatus.preparednessLevel}%</p>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className={`h-2 rounded-full transition-all ${userStatus.preparednessLevel >= 80 ? 'bg-green-600' : userStatus.preparednessLevel >= 60 ? 'bg-yellow-600' : userStatus.preparednessLevel >= 40 ? 'bg-orange-600' : 'bg-red-600'}`} style={{ width: `${userStatus.preparednessLevel}%` }}></div>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-white border-slate-200">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-sm font-semibold text-slate-600 uppercase tracking-wide">{t('home.emergencyContacts')}</h3>
              <AlertCircle className="w-5 h-5 text-orange-600" />
            </div>
            <p className="text-2xl font-bold text-slate-900">{userStatus.contactsAdded}</p>
            <p className="text-xs text-slate-500 mt-2">{t('contact.title')}</p>
          </Card>

          <Card className="p-6 bg-white border-slate-200">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-sm font-semibold text-slate-600 uppercase tracking-wide">{t('family.lastSeen')}</h3>
              <Clock className="w-5 h-5 text-purple-600" />
            </div>
            {userStatus.lastCheckIn ? (
              <p className="text-2xl font-bold text-slate-900">
                {Math.round((Date.now() - userStatus.lastCheckIn.getTime()) / 60000)}
                <span className="text-sm text-slate-500 ml-1">min</span>
              </p>
            ) : (
              <p className="text-slate-500">{t('family.unknown')}</p>
            )}
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Button className="bg-green-600 hover:bg-green-700 text-white py-6 text-lg">{t('actions.imSafe')}</Button>
          <Button className="bg-red-600 hover:bg-red-700 text-white py-6 text-lg">{t('actions.sendSOS')}</Button>
        </div>
      </div>
    </div>
  );
}
