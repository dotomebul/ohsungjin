/**
 * Evacora - Map Page (4-region support, fully localized)
 */

import { useEffect, useRef, useState, useMemo } from "react";
import { MapView } from "@/components/Map";
import { trpc } from "@/lib/trpc";
import { Loader2, AlertCircle, ArrowLeft, Navigation } from "lucide-react";
import { useI18n } from "@/contexts/I18nContext";
import { useLocation } from "wouter";
import { Region } from "@shared/i18n/translations";

const DISASTER_ICON: Record<string, string> = {
  earthquake: "http://maps.google.com/mapfiles/ms/icons/red-dot.png",
  wildfire: "http://maps.google.com/mapfiles/ms/icons/orange-dot.png",
  flood: "http://maps.google.com/mapfiles/ms/icons/blue-dot.png",
  storm: "http://maps.google.com/mapfiles/ms/icons/yellow-dot.png",
  tsunami: "http://maps.google.com/mapfiles/ms/icons/purple-dot.png",
  volcano: "http://maps.google.com/mapfiles/ms/icons/red-dot.png",
  other: "http://maps.google.com/mapfiles/ms/icons/pink-dot.png",
};

interface Shelter {
  id: number;
  name: string;
  type: string | null;
  lat: string;
  lng: string;
  distance?: number;
  capacity: number | null;
  currentOccupancy?: number;
  amenities?: string | null;
  phone?: string | null;
  address: string | null;
  region?: string;
}

const REGION_DEFAULTS: Record<Region, { lat: number; lng: number; zoom: number }> = {
  us: { lat: 40.7128, lng: -74.006, zoom: 12 },
  eu: { lat: 52.52, lng: 13.405, zoom: 12 },
  kr: { lat: 37.5665, lng: 126.978, zoom: 13 },
  jp: { lat: 35.6762, lng: 139.6503, zoom: 13 },
};

export default function Map() {
  const { t, region: i18nRegion } = useI18n();
  const [, navigate] = useLocation();
  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const circlesRef = useRef<google.maps.Circle[]>([]);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [selectedShelter, setSelectedShelter] = useState<Shelter | null>(null);
  const [mapRegion, setMapRegion] = useState<Region>(i18nRegion);
  const [searchRadius, setSearchRadius] = useState(10);
  const [mapReady, setMapReady] = useState(false);
  const familyMarkersRef = useRef<google.maps.Marker[]>([]);
  const disasterMarkersRef = useRef<google.maps.Marker[]>([]);
  const disasterCirclesRef = useRef<google.maps.Circle[]>([]);

  // Load family members from localStorage
  const familyMembers = useMemo(() => {
    try {
      const saved = localStorage.getItem('evacora_family_members');
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.filter((m: any) => m.location && m.location.lat && m.location.lng);
      }
    } catch {}
    return [];
  }, []);

  // Use region default as fallback location
  const effectiveLocation = useMemo(() => {
    if (userLocation) return userLocation;
    const def = REGION_DEFAULTS[mapRegion];
    return { lat: def.lat, lng: def.lng };
  }, [userLocation, mapRegion]);

  // Real-time disaster data
  const { data: disasterEvents = [] } = trpc.disasterData.getActiveEvents.useQuery(
    {
      lat: effectiveLocation.lat,
      lng: effectiveLocation.lng,
      radiusKm: 10000,
      minSeverity: "moderate",
    },
    { refetchInterval: 60000 } // refresh every 60s
  );

  const { data: rawShelters = [], isLoading: isLoadingShelters } = trpc.shelters.searchNearby.useQuery(
    {
      latitude: effectiveLocation.lat,
      longitude: effectiveLocation.lng,
      region: mapRegion,
      radiusKm: searchRadius,
    },
    { enabled: true }
  );

  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
    const R = 6371;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLng = ((lng2 - lng1) * Math.PI) / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  };

  const shelters: Shelter[] = useMemo(() =>
    (rawShelters || []).map((s: any) => {
      const distance = calculateDistance(effectiveLocation.lat, effectiveLocation.lng, parseFloat(s.lat), parseFloat(s.lng));
      return { ...s, distance, currentOccupancy: Math.floor(Math.random() * (s.capacity || 100)) };
    }).sort((a: Shelter, b: Shelter) => (a.distance || 0) - (b.distance || 0)),
    [rawShelters, effectiveLocation]
  );

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => {}
      );
    }
  }, []);

  // Update map when region changes
  useEffect(() => {
    if (!mapRef.current || !mapReady) return;
    const map = mapRef.current;
    const def = REGION_DEFAULTS[mapRegion];

    // Clear old markers/circles
    markersRef.current.forEach((m) => m.setMap(null));
    markersRef.current = [];
    circlesRef.current.forEach((c) => c.setMap(null));
    circlesRef.current = [];

    // Center on region
    const center = userLocation || { lat: def.lat, lng: def.lng };
    map.setCenter(center);
    map.setZoom(def.zoom);

    // User marker
    const userMarker = new google.maps.Marker({
      position: center,
      map,
      title: t('mapPage.yourLocation'),
      icon: "http://maps.google.com/mapfiles/ms/icons/green-dot.png",
    });
    markersRef.current.push(userMarker);

    // Shelter markers
    shelters.forEach((shelter) => {
      const marker = new google.maps.Marker({
        position: { lat: parseFloat(shelter.lat), lng: parseFloat(shelter.lng) },
        map,
        title: shelter.name,
        icon: "http://maps.google.com/mapfiles/ms/icons/blue-dot.png",
      });
      marker.addListener("click", () => {
        setSelectedShelter(shelter);
        const infoWindow = new google.maps.InfoWindow({
          content: `<div style="padding:8px;font-family:Arial,sans-serif;max-width:200px;">
            <h3 style="margin:0 0 4px;font-size:13px;font-weight:bold;">${shelter.name}</h3>
            <p style="margin:2px 0;font-size:11px;">${t('mapPage.distance')}: ${shelter.distance?.toFixed(1) || '?'} km</p>
            <p style="margin:2px 0;font-size:11px;">${t('mapPage.capacity')}: ${shelter.capacity}</p>
            <a href="#" onclick="window.__navigateToShelter && window.__navigateToShelter('${shelter.id}')" style="font-size:11px;color:#2563eb;">View Details →</a>
          </div>`,
        });
        infoWindow.open(map, marker);
      });
      markersRef.current.push(marker);
    });

    // Family member markers (purple)
    familyMarkersRef.current.forEach((m) => m.setMap(null));
    familyMarkersRef.current = [];
    familyMembers.forEach((member: any) => {
      if (!member.location) return;
      const familyMarker = new google.maps.Marker({
        position: { lat: member.location.lat, lng: member.location.lng },
        map,
        title: `${member.name} (${member.relation})`,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 10,
          fillColor: member.color || '#8B5CF6',
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 2,
        },
        label: {
          text: member.name.charAt(0).toUpperCase(),
          color: '#ffffff',
          fontSize: '11px',
          fontWeight: 'bold',
        },
      });
      const infoWindow = new google.maps.InfoWindow({
        content: `<div style="padding:8px;font-family:Arial,sans-serif;">
          <p style="margin:0;font-size:13px;font-weight:bold;">${member.name}</p>
          <p style="margin:2px 0;font-size:11px;color:#666;">${member.relation}</p>
          <p style="margin:2px 0;font-size:11px;color:${member.status === 'safe' ? 'green' : member.status === 'emergency' ? 'red' : 'orange'};">${member.status === 'safe' ? '✅ Safe' : member.status === 'emergency' ? '🆘 Emergency' : '⏳ Checking'}</p>
        </div>`,
      });
      familyMarker.addListener('click', () => infoWindow.open(map, familyMarker));
      familyMarkersRef.current.push(familyMarker);
    });

    // Real-time disaster event markers
    disasterMarkersRef.current.forEach((m) => m.setMap(null));
    disasterMarkersRef.current = [];
    disasterCirclesRef.current.forEach((c) => c.setMap(null));
    disasterCirclesRef.current = [];

    disasterEvents.forEach((event: any) => {
      const icon = DISASTER_ICON[event.type] || DISASTER_ICON.other;
      const marker = new google.maps.Marker({
        position: { lat: event.lat, lng: event.lng },
        map,
        title: event.title,
        icon,
        zIndex: event.severity === 'extreme' ? 100 : event.severity === 'severe' ? 90 : 80,
      });
      const infoWindow = new google.maps.InfoWindow({
        content: `<div style="padding:8px;font-family:Arial,sans-serif;max-width:220px;">
          <p style="margin:0 0 4px;font-size:13px;font-weight:bold;">${event.title}</p>
          <p style="margin:2px 0;font-size:11px;color:#666;">${event.description}</p>
          <p style="margin:4px 0 0;font-size:11px;color:${event.severity === 'extreme' ? '#dc2626' : event.severity === 'severe' ? '#ea580c' : '#d97706'};font-weight:bold;">${event.severity.toUpperCase()} · ${event.source}</p>
          ${event.url ? `<a href="${event.url}" target="_blank" style="font-size:11px;color:#2563eb;">More info →</a>` : ''}
        </div>`,
      });
      marker.addListener('click', () => infoWindow.open(map, marker));
      disasterMarkersRef.current.push(marker);

      // Draw radius circle for significant events
      if (event.radius && event.radius > 0 && (event.severity === 'extreme' || event.severity === 'severe')) {
        const color = event.severity === 'extreme' ? '#dc2626' : '#ea580c';
        const circle = new google.maps.Circle({
          center: { lat: event.lat, lng: event.lng },
          radius: event.radius * 1000,
          map,
          fillColor: color,
          fillOpacity: 0.08,
          strokeColor: color,
          strokeOpacity: 0.4,
          strokeWeight: 1,
        });
        disasterCirclesRef.current.push(circle);
      }
    });

    // Danger zone circle
    const dangerCircle = new google.maps.Circle({
      center: { lat: def.lat + 0.005, lng: def.lng - 0.01 },
      radius: 800,
      map,
      fillColor: "#FF0000",
      fillOpacity: 0.15,
      strokeColor: "#FF0000",
      strokeOpacity: 0.6,
      strokeWeight: 2,
    });
    circlesRef.current.push(dangerCircle);

    const dangerMarker = new google.maps.Marker({
      position: { lat: def.lat + 0.005, lng: def.lng - 0.01 },
      map,
      title: t('mapPage.dangerZone'),
      icon: "http://maps.google.com/mapfiles/ms/icons/red-dot.png",
    });
    markersRef.current.push(dangerMarker);
  }, [mapRegion, shelters, mapReady, t]);

  const handleMapReady = (map: google.maps.Map) => {
    mapRef.current = map;
    setMapReady(true);
  };

  const regionTabs: { key: Region; flag: string }[] = [
    { key: "us", flag: "🇺🇸" },
    { key: "eu", flag: "🇪🇺" },
    { key: "kr", flag: "🇰🇷" },
    { key: "jp", flag: "🇯🇵" },
  ];

  return (
    <div className="min-h-screen w-full bg-slate-50">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3 mb-4">
            <button onClick={() => navigate("/home")} className="text-slate-600 hover:text-slate-900 transition-colors" aria-label={t('common.back')}>
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-2xl font-bold text-slate-900">{t('mapPage.title')}</h1>
          </div>

          <div className="flex flex-wrap gap-4 items-center">
            {/* 4-region tabs */}
            <div className="flex gap-1.5">
              {regionTabs.map(({ key, flag }) => (
                <button
                  key={key}
                  onClick={() => { setMapRegion(key); setSelectedShelter(null); }}
                  className={`px-3 py-2 rounded-lg font-medium text-sm transition-all ${
                    mapRegion === key
                      ? "bg-blue-600 text-white shadow-md"
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  {flag} {t(`regions.${key === 'us' ? 'unitedStates' : key === 'eu' ? 'europe' : key === 'kr' ? 'korea' : 'japan'}`)}
                </button>
              ))}
            </div>

            {/* Radius slider */}
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium text-slate-700">{t('mapPage.radius')}:</label>
              <input type="range" min="1" max="50" value={searchRadius} onChange={(e) => setSearchRadius(Number(e.target.value))} className="w-24" />
              <span className="text-sm text-slate-600">{searchRadius} km</span>
            </div>

            {isLoadingShelters && (
              <div className="flex items-center gap-2 text-slate-600">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm">{t('mapPage.loadingShelters')}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Map */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <MapView
                initialCenter={REGION_DEFAULTS[mapRegion]}
                initialZoom={REGION_DEFAULTS[mapRegion].zoom}
                onMapReady={handleMapReady}
                className="h-96"
              />
            </div>

            {/* Legend */}
            <div className="mt-4 bg-white rounded-lg shadow p-4">
              <h3 className="font-semibold text-slate-900 mb-3">{t('mapPage.legend')}</h3>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-green-500" />
                  <span className="text-sm text-slate-700">{t('mapPage.yourLocation')}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-blue-500" />
                  <span className="text-sm text-slate-700">{t('mapPage.shelterPlace')}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-red-500" />
                  <span className="text-sm text-slate-700">{t('mapPage.dangerZone')}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-purple-500" style={{background: '#8B5CF6'}} />
                  <span className="text-sm text-slate-700">{t('family.title')}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Alert */}
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-red-900 mb-1">{t('alerts.activeAlert')}</h3>
                  <p className="text-sm text-red-800">{t('mapPage.dangerZone')}</p>
                </div>
              </div>
            </div>

            {/* Shelter list */}
            <div className="bg-white rounded-lg shadow-lg">
              <div className="p-4 border-b border-slate-200">
                <h3 className="font-semibold text-slate-900">{t('mapPage.nearbyShelters')} ({shelters.length})</h3>
              </div>
              <div className="divide-y max-h-96 overflow-y-auto">
                {shelters.length === 0 ? (
                  <div className="p-4 text-center text-slate-500">
                    <p className="text-sm">{t('mapPage.noShelters')}</p>
                  </div>
                ) : (
                  shelters.map((shelter) => (
                    <button
                      key={shelter.id}
                      onClick={() => {
                        setSelectedShelter(shelter);
                        if (mapRef.current) {
                          mapRef.current.panTo({ lat: parseFloat(shelter.lat), lng: parseFloat(shelter.lng) });
                          mapRef.current.setZoom(16);
                        }
                      }}
                      className={`w-full p-4 text-left transition-colors hover:bg-blue-50 ${selectedShelter?.id === shelter.id ? "bg-blue-50 border-l-4 border-blue-600" : ""}`}
                    >
                      <div className="flex items-start justify-between mb-1">
                        <h4 className="font-semibold text-slate-900 text-sm">{shelter.name}</h4>
                        <span className="text-xs font-medium text-blue-600 bg-blue-100 px-2 py-0.5 rounded flex-shrink-0 ml-2">
                          {shelter.distance?.toFixed(1) || '?'} km
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mb-1.5">{shelter.address}</p>
                      <div className="flex items-center justify-between text-xs text-slate-600">
                        <span>{t('mapPage.capacity')}: {shelter.capacity}</span>
                        <button
                          onClick={(e) => { e.stopPropagation(); navigate(`/shelter/${shelter.id}`); }}
                          className="text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"
                        >
                          <Navigation className="w-3 h-3" /> Details
                        </button>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>

            {/* Selected shelter detail */}
            {selectedShelter && (
              <div className="mt-6 bg-white rounded-lg shadow-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-slate-900">{selectedShelter.name}</h3>
                  <button
                    onClick={() => navigate(`/shelter/${selectedShelter.id}`)}
                    className="text-xs bg-blue-600 text-white px-3 py-1.5 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Full Details →
                  </button>
                </div>
                <div className="space-y-2 text-sm">
                  <div>
                    <p className="text-slate-500 text-xs">{t('mapPage.address')}</p>
                    <p className="font-medium text-slate-900">{selectedShelter.address}</p>
                  </div>
                  {selectedShelter.phone && (
                    <div>
                      <p className="text-slate-500 text-xs">{t('mapPage.phone')}</p>
                      <a href={`tel:${selectedShelter.phone}`} className="font-medium text-blue-600 hover:text-blue-700">{selectedShelter.phone}</a>
                    </div>
                  )}
                  <div>
                    <p className="text-slate-500 text-xs">{t('mapPage.distance')}</p>
                    <p className="font-medium text-slate-900">{selectedShelter.distance?.toFixed(1) || '?'} km</p>
                  </div>
                  <div>
                    <p className="text-slate-500 text-xs">{t('mapPage.capacity')}</p>
                    <div className="w-full bg-slate-200 rounded-full h-2 mt-1">
                      <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${selectedShelter.capacity && selectedShelter.currentOccupancy ? (selectedShelter.currentOccupancy / selectedShelter.capacity) * 100 : 0}%` }} />
                    </div>
                    <p className="text-xs text-slate-500 mt-1">{selectedShelter.currentOccupancy || 0} / {selectedShelter.capacity || 0}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
