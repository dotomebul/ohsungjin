/**
 * News Page
 * Displays latest disaster news from around the world
 */

import { useState, useEffect } from 'react';
import { ArrowLeft, Loader2, AlertCircle, RefreshCw } from 'lucide-react';
import { useLocation } from 'wouter';
import { useI18n } from '@/contexts/I18nContext';
import { trpc } from '@/lib/trpc';
import { NewsCard } from '@/components/NewsCard';
import { toast } from 'sonner';

type DisasterType =
  | 'earthquake'
  | 'wildfire'
  | 'tsunami'
  | 'typhoon'
  | 'hurricane'
  | 'flood'
  | 'tornado'
  | 'volcano'
  | 'drought'
  | 'landslide'
  | 'avalanche'
  | 'all';

export default function NewsPage() {
  const [, navigate] = useLocation();
  const { t, region } = useI18n();
  const [selectedDisaster, setSelectedDisaster] = useState<DisasterType>('all');
  const [autoRefresh, setAutoRefresh] = useState(true);

  // Fetch disaster news
  const { data: newsData, isLoading, refetch } = trpc.news.getDisasterNews.useQuery(
    {
      disasterType: selectedDisaster,
      limit: 15,
      sortBy: 'publishedAt',
    },
    {
      refetchInterval: autoRefresh ? 60000 : false, // 1 minute interval
    }
  );

  // Auto-refresh effect
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      refetch();
    }, 60000); // 1 minute

    return () => clearInterval(interval);
  }, [autoRefresh, refetch]);

  const disasterOptions: { value: DisasterType; label: string; emoji: string }[] = [
    { value: 'all', label: 'All Disasters', emoji: '🌍' },
    { value: 'earthquake', label: 'Earthquakes', emoji: '🏚️' },
    { value: 'wildfire', label: 'Wildfires', emoji: '🔥' },
    { value: 'tsunami', label: 'Tsunamis', emoji: '🌊' },
    { value: 'typhoon', label: 'Typhoons', emoji: '🌪️' },
    { value: 'hurricane', label: 'Hurricanes', emoji: '🌀' },
    { value: 'flood', label: 'Floods', emoji: '💧' },
    { value: 'tornado', label: 'Tornadoes', emoji: '🌪️' },
    { value: 'volcano', label: 'Volcanoes', emoji: '🌋' },
  ];

  const handleOpenNews = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-white border-b border-slate-200">
        <div className="flex items-center gap-3 px-5 py-4">
          <button
            onClick={() => navigate('/home')}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-slate-700" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-slate-900">Disaster News</h1>
            <p className="text-xs text-slate-500">Latest updates from around the world</p>
          </div>
          <button
            onClick={() => refetch()}
            disabled={isLoading}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-5 h-5 text-slate-700 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Auto-refresh toggle */}
        <div className="px-5 py-3 border-t border-slate-200 flex items-center justify-between bg-blue-50">
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="autoRefresh"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="w-4 h-4 rounded border-slate-300 cursor-pointer"
            />
            <label htmlFor="autoRefresh" className="text-xs font-semibold text-slate-700 cursor-pointer">
              Auto-refresh every minute
            </label>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Disaster Filter */}
        <div className="space-y-3">
          <h2 className="text-sm font-bold text-slate-900">Filter by Disaster Type</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {disasterOptions.map((option) => (
              <button
                key={option.value}
                onClick={() => setSelectedDisaster(option.value)}
                className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all ${
                  selectedDisaster === option.value
                    ? 'bg-blue-500 text-white shadow-md'
                    : 'bg-white text-slate-700 border border-slate-200 hover:border-blue-300'
                }`}
              >
                <span className="mr-1">{option.emoji}</span>
                {option.label}
              </button>
            ))}
          </div>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="flex flex-col items-center justify-center py-12 gap-3">
            <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
            <p className="text-sm text-slate-600">Loading latest news...</p>
          </div>
        )}

        {/* Error State */}
        {!isLoading && newsData?.error && !newsData?.articles && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-red-900">Failed to load news</p>
              <p className="text-xs text-red-700 mt-1">Please try again later or check your connection.</p>
            </div>
          </div>
        )}

        {/* Empty State */}
        {!isLoading && !newsData?.error && (!newsData?.articles || newsData.articles.length === 0) && (
          <div className="text-center py-12">
            <p className="text-sm text-slate-600">No news articles found for this disaster type.</p>
            <p className="text-xs text-slate-500 mt-2">Try selecting a different category.</p>
          </div>
        )}

        {/* News Grid */}
        {!isLoading && newsData?.articles && newsData.articles.length > 0 && (
          <div className="grid gap-4 sm:grid-cols-2">
            {newsData.articles.map((article) => (
              <NewsCard
                key={article.id}
                {...article}
                publishedAt={new Date(article.publishedAt)}
                onOpenNews={handleOpenNews}
              />
            ))}
          </div>
        )}

        {/* Info Footer */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
          <p className="text-xs text-blue-900">
            <strong>News updates every minute</strong> • Powered by NewsAPI
          </p>
          <p className="text-xs text-blue-700 mt-1">
            Click any article to read the full story on the source website
          </p>
        </div>
      </div>
    </div>
  );
}
