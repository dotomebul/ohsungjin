import React, { useState, useMemo } from 'react';
import { useI18n } from '@/contexts/I18nContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin, Navigation, AlertTriangle, Clock, Users, Zap, ArrowLeft } from 'lucide-react';
import { useLocation } from 'wouter';

interface SafeShelter {
  id: string;
  name: string;
  type: string;
  distance: number;
  duration: number;
  capacity: number;
  available: number;
  amenities: string[];
  hazards: string[];
  route: {
    distance: number;
    duration: number;
    steps: string[];
  };
}

export default function SafeRoute() {
  const { t } = useI18n();
  const [, navigate] = useLocation();
  const [selectedShelter, setSelectedShelter] = useState<SafeShelter | null>(null);
  const [routeMode, setRouteMode] = useState<'walk' | 'drive'>('walk');

  const shelters: SafeShelter[] = useMemo(() => [
    {
      id: '1',
      name: t('home.shelterInfo'),
      type: t('mapPage.shelterPlace'),
      distance: 0.8,
      duration: 12,
      capacity: 5000,
      available: 3200,
      amenities: [t('guide.safetyTips'), t('home.conditions')],
      hazards: [],
      route: {
        distance: 0.8,
        duration: 12,
        steps: [
          t('guide.evacuationSteps') + ' 1',
          t('guide.evacuationSteps') + ' 2',
          t('guide.evacuationSteps') + ' 3',
        ],
      },
    },
    {
      id: '2',
      name: t('home.shelter') + ' B',
      type: t('mapPage.shelterPlace'),
      distance: 2.1,
      duration: 28,
      capacity: 2000,
      available: 1500,
      amenities: [t('guide.safetyTips')],
      hazards: [t('mapPage.dangerZone')],
      route: {
        distance: 2.1,
        duration: 28,
        steps: [
          t('guide.evacuationSteps') + ' 1',
          t('guide.evacuationSteps') + ' 2',
        ],
      },
    },
    {
      id: '3',
      name: t('home.shelter') + ' C',
      type: t('mapPage.shelterPlace'),
      distance: 3.5,
      duration: 45,
      capacity: 1000,
      available: 800,
      amenities: [t('guide.safetyTips'), t('home.conditions')],
      hazards: [t('mapPage.dangerZone')],
      route: {
        distance: 3.5,
        duration: 45,
        steps: [
          t('guide.evacuationSteps') + ' 1',
          t('guide.evacuationSteps') + ' 2',
          t('guide.evacuationSteps') + ' 3',
          t('guide.evacuationSteps') + ' 4',
        ],
      },
    },
  ], [t]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button onClick={() => navigate("/home")} className="text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-1">{t('home.safeRoute')}</h1>
            <p className="text-slate-600">{t('home.safeRouteDesc')}</p>
          </div>
        </div>

        {/* Route Mode Selection */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Button
            onClick={() => setRouteMode('walk')}
            className={`py-4 ${routeMode === 'walk' ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-white border-2 border-slate-200 text-slate-900 hover:border-slate-300'}`}
          >
            🚶 {t('home.walkRoute')}
          </Button>
          <Button
            onClick={() => setRouteMode('drive')}
            className={`py-4 ${routeMode === 'drive' ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-white border-2 border-slate-200 text-slate-900 hover:border-slate-300'}`}
          >
            🚗 {t('home.driveRoute')}
          </Button>
        </div>

        {/* Shelters List */}
        <div className="space-y-4">
          {shelters.map((shelter) => (
            <Card
              key={shelter.id}
              onClick={() => setSelectedShelter(shelter)}
              className={`p-4 cursor-pointer transition-all border-2 ${selectedShelter?.id === shelter.id ? 'bg-blue-50 border-blue-400 shadow-lg' : 'bg-white border-slate-200 hover:border-slate-300'}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-lg font-bold text-slate-900">{shelter.name}</h3>
                  <p className="text-sm text-slate-500">{shelter.type}</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-slate-900">{shelter.distance} km</p>
                  <p className="text-sm text-slate-500">{shelter.duration} min</p>
                </div>
              </div>

              <div className="mb-3 p-2 bg-slate-50 rounded-lg flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-slate-700">{t('mapPage.capacity')}: {shelter.available}/{shelter.capacity}</span>
              </div>

              <div className="mb-3 flex flex-wrap gap-2">
                {shelter.amenities.map((amenity, idx) => (
                  <span key={idx} className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">✓ {amenity}</span>
                ))}
              </div>

              {shelter.hazards.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {shelter.hazards.map((hazard, idx) => (
                    <span key={idx} className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" /> {hazard}
                    </span>
                  ))}
                </div>
              )}
            </Card>
          ))}
        </div>

        {/* Selected Shelter Details */}
        {selectedShelter && (
          <Card className="mt-6 p-6 bg-white border-slate-200">
            <h2 className="text-xl font-bold text-slate-900 mb-4">{t('home.safeRoute')}</h2>

            <div className="mb-6">
              <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                <Navigation className="w-5 h-5 text-blue-600" />
                {t('guide.evacuationSteps')}
              </h3>
              <div className="space-y-2">
                {selectedShelter.route.steps.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold">{idx + 1}</div>
                    <p className="text-slate-700 pt-0.5">{step}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-600 font-semibold">{t('mapPage.distance')}</p>
                <p className="text-2xl font-bold text-blue-900">{selectedShelter.route.distance} km</p>
              </div>
              <div className="p-3 bg-green-50 rounded-lg">
                <p className="text-sm text-green-600 font-semibold flex items-center gap-1">
                  <Clock className="w-4 h-4" /> ETA
                </p>
                <p className="text-2xl font-bold text-green-900">{selectedShelter.route.duration} min</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Button onClick={() => navigate("/map")} className="bg-blue-600 hover:bg-blue-700 text-white py-6 flex items-center justify-center gap-2">
                <MapPin className="w-5 h-5" />
                {t('common.map')}
              </Button>
              <Button className="bg-green-600 hover:bg-green-700 text-white py-6 flex items-center justify-center gap-2">
                <Zap className="w-5 h-5" />
                {t('common.continue')}
              </Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
