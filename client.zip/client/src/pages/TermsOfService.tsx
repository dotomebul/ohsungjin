import { useI18n } from '@/contexts/I18nContext';
import { ArrowLeft } from 'lucide-react';
import { useLocation } from 'wouter';

export default function TermsOfService() {
  const { t, language } = useI18n();
  const [, navigate] = useLocation();

  const content = {
    en: {
      title: 'Terms of Service',
      lastUpdated: 'Last Updated: April 2026',
      sections: [
        {
          heading: '1. Acceptance of Terms',
          content: 'By downloading and using Evacora, you agree to these Terms of Service. If you do not agree, please do not use the app. We reserve the right to modify these terms at any time. Your continued use constitutes acceptance.'
        },
        {
          heading: '2. Use License',
          content: 'We grant you a non-exclusive, non-transferable license to use Evacora for personal, non-commercial purposes. You may not: (a) Reverse engineer or decompile the app; (b) Remove or alter copyright notices; (c) Use the app for illegal purposes; (d) Interfere with app functionality or servers; (e) Collect data without authorization.'
        },
        {
          heading: '3. User Responsibilities',
          content: 'You are responsible for: (a) Maintaining the confidentiality of your account; (b) Providing accurate information; (c) Complying with all applicable laws; (d) Not using the app to harm others. You acknowledge that Evacora provides guidance only and is not a substitute for professional emergency services.'
        },
        {
          heading: '4. Disclaimer of Warranties',
          content: 'Evacora is provided "AS IS" without warranties. We do not guarantee: (a) Accuracy of location data or shelter information; (b) Uninterrupted app availability; (c) Absence of errors or bugs; (d) Suitability for any particular purpose. Use at your own risk.'
        },
        {
          heading: '5. Limitation of Liability',
          content: 'To the maximum extent permitted by law, Evacora and its creators are not liable for: (a) Indirect, incidental, or consequential damages; (b) Loss of data or profits; (c) Decisions made based on app guidance; (d) Third-party services (Google Maps, Twilio). Our total liability is limited to the amount you paid (if any).'
        },
        {
          heading: '6. Third-Party Services',
          content: 'Evacora uses Google Maps, Twilio, and other third-party services. Your use is subject to their terms. We are not responsible for their actions or outages.'
        },
        {
          heading: '7. Intellectual Property',
          content: 'All content, design, and code in Evacora are owned by Evacora or licensed from third parties. You may not reproduce, distribute, or transmit any content without permission.'
        },
        {
          heading: '8. Termination',
          content: 'We may terminate your access if you violate these terms. Upon termination, your right to use Evacora ceases immediately.'
        },
        {
          heading: '9. Governing Law',
          content: 'These terms are governed by the laws of the jurisdiction where Evacora is operated, without regard to conflict of law principles.'
        },
        {
          heading: '10. Contact',
          content: 'For questions about these Terms, contact us at: legal@evacora.app'
        }
      ]
    },
    ko: {
      title: '이용약관',
      lastUpdated: '최종 수정: 2026년 4월',
      sections: [
        {
          heading: '1. 약관 동의',
          content: 'Evacora를 다운로드하고 사용함으로써 이 이용약관에 동의합니다. 동의하지 않으면 앱을 사용하지 마세요. 약관은 언제든 변경될 수 있으며, 계속 사용하면 변경된 약관에 동의하는 것입니다.'
        },
        {
          heading: '2. 사용 라이선스',
          content: '개인 비상업적 목적으로 Evacora를 사용할 수 있는 비독점적 라이선스를 부여합니다. 금지 사항: (a) 역공학 또는 역컴파일; (b) 저작권 표시 제거; (c) 불법 목적 사용; (d) 앱 기능 방해; (e) 무단 데이터 수집.'
        },
        {
          heading: '3. 사용자 책임',
          content: '다음에 책임이 있습니다: (a) 계정 기밀성 유지; (b) 정확한 정보 제공; (c) 모든 법률 준수; (d) 타인 피해 금지. Evacora는 지침만 제공하며 전문 긴급 서비스를 대체하지 않습니다.'
        },
        {
          heading: '4. 보증 부인',
          content: 'Evacora는 "있는 그대로" 제공되며 다음을 보증하지 않습니다: (a) 위치 데이터 또는 대피소 정보의 정확성; (b) 앱 가용성; (c) 오류 부재; (d) 특정 목적 적합성. 자신의 책임하에 사용하세요.'
        },
        {
          heading: '5. 책임 제한',
          content: '법률이 허용하는 최대 범위 내에서 Evacora는 다음에 대해 책임이 없습니다: (a) 간접적 손해; (b) 데이터 또는 수익 손실; (c) 앱 지침 기반 결정; (d) 제3자 서비스. 책임은 지불한 금액으로 제한됩니다.'
        },
        {
          heading: '6. 제3자 서비스',
          content: 'Evacora는 Google Maps, Twilio 등을 사용합니다. 사용은 해당 서비스의 약관을 따릅니다. 우리는 제3자 서비스의 장애에 책임이 없습니다.'
        },
        {
          heading: '7. 지적 재산권',
          content: 'Evacora의 모든 콘텐츠, 디자인, 코드는 Evacora 또는 라이선서가 소유합니다. 허가 없이 복제, 배포, 전송할 수 없습니다.'
        },
        {
          heading: '8. 이용 중지',
          content: '약관 위반 시 접근을 중지할 수 있습니다. 중지 시 사용 권리는 즉시 종료됩니다.'
        },
        {
          heading: '9. 준거법',
          content: '이 약관은 Evacora 운영 지역의 법률을 따릅니다.'
        },
        {
          heading: '10. 문의',
          content: '질문이 있으시면 legal@evacora.app으로 연락주세요.'
        }
      ]
    }
  };

  const currentContent = content[language as keyof typeof content] || content.en;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6 flex items-center gap-3">
          <button onClick={() => navigate("/home")} className="text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">{currentContent.title}</h1>
            <p className="text-sm text-slate-500 mt-1">{currentContent.lastUpdated}</p>
          </div>
        </div>

        <div className="space-y-6 pb-8">
          {currentContent.sections.map((section, idx) => (
            <div key={idx} className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
              <h2 className="text-lg font-bold text-slate-900 mb-3">{section.heading}</h2>
              <p className="text-slate-600 leading-relaxed text-sm">{section.content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
