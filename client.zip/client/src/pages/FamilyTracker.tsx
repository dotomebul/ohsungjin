import React, { useState, useCallback, useRef, useEffect } from 'react';
import { useI18n } from '@/contexts/I18nContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { MapPin, CheckCircle, AlertCircle, Clock, Phone, MessageSquare, ArrowLeft, Share2, MapPinOff, Radio, Users, Plus, UserPlus, Trash2, Link2, Navigation } from 'lucide-react';
import { useLocation } from 'wouter';
import { MapView } from '@/components/Map';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import { useAuth } from '@/_core/hooks/useAuth';
import { useEmailAuth } from '@/hooks/useEmailAuth';

interface FamilyMember {
  id: string;
  name: string;
  relation: string;
  location: { lat: number; lng: number } | null;
  status: 'safe' | 'checking' | 'emergency' | 'offline';
  lastUpdate: Date;
  distance: number;
  phone: string;
  color: string;
}

const MEMBER_COLORS = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#14B8A6', '#F97316'];
const UPDATE_INTERVALS = [5, 15, 30, 60];

export default function FamilyTracker() {
  const { t, region } = useI18n();
  const [, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const [isSharingEnabled, setIsSharingEnabled] = useState(() => {
    return localStorage.getItem('evacora_location_sharing') === 'true';
  });
  const [updateInterval, setUpdateInterval] = useState(() => {
    return parseInt(localStorage.getItem('evacora_update_interval') || '30');
  });
  const [showMap, setShowMap] = useState(false);
  const [myPosition, setMyPosition] = useState<{ lat: number; lng: number } | null>(null);
  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.marker.AdvancedMarkerElement[]>([]);
  const watchIdRef = useRef<number | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Add member dialog state
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newMember, setNewMember] = useState({ name: '', relation: '', phone: '' });

  const updateLocationMut = trpc.emailAuth.updateLocation.useMutation();
  const sendLocationSmsMut = trpc.emailAuth.sendLocationSms.useMutation();
  const createInviteMut = trpc.emailAuth.createFamilyInvite.useMutation();
  const { emailUser, isEmailAuthenticated } = useEmailAuth();

  // Real-time family locations from server
  const { data: familyLocations, refetch: refetchLocations } = trpc.emailAuth.getFamilyMembers.useQuery(
    undefined,
    { enabled: isEmailAuthenticated, refetchInterval: 30000 }
  );

  const regionCenter = {
    us: { lat: 37.7749, lng: -122.4194 },
    eu: { lat: 52.52, lng: 13.405 },
    kr: { lat: 37.5665, lng: 126.978 },
    jp: { lat: 35.6762, lng: 139.6503 },
  }[region] || { lat: 37.5665, lng: 126.978 };

  // Load family members from localStorage
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>(() => {
    try {
      const saved = localStorage.getItem('evacora_family_members');
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.map((m: any) => ({ ...m, lastUpdate: new Date(m.lastUpdate) }));
      }
    } catch {}
    return [];
  });

  // Persist family members to localStorage
  useEffect(() => {
    localStorage.setItem('evacora_family_members', JSON.stringify(familyMembers));
  }, [familyMembers]);

  // Get real position
  useEffect(() => {
    if (!navigator.geolocation) { setMyPosition(regionCenter); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => setMyPosition({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => setMyPosition(regionCenter),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }, []);

  // Merge server family locations into local state
  useEffect(() => {
    if (!familyLocations) return;
    setFamilyMembers(prev => prev.map(m => {
      const serverMember = familyLocations.find(fl => fl.name === m.name);
      if (serverMember?.lat && serverMember?.lng) {
        return { ...m, location: { lat: serverMember.lat, lng: serverMember.lng }, status: 'safe', lastUpdate: serverMember.lastSeen ? new Date(serverMember.lastSeen) : m.lastUpdate };
      }
      return m;
    }));
  }, [familyLocations]);

  // Location sharing: watch + send to server
  useEffect(() => {
    if (!isSharingEnabled || (!isAuthenticated && !isEmailAuthenticated)) {
      if (watchIdRef.current !== null) { navigator.geolocation.clearWatch(watchIdRef.current); watchIdRef.current = null; }
      if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null; }
      return;
    }
    if (navigator.geolocation) {
      watchIdRef.current = navigator.geolocation.watchPosition(
        (pos) => setMyPosition({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => {}, { enableHighAccuracy: true }
      );
    }
    const sendLocation = () => {
      if (!myPosition) return;
      updateLocationMut.mutate({ lat: myPosition.lat, lng: myPosition.lng, accuracy: 10 });
    };
    sendLocation();
    intervalRef.current = setInterval(sendLocation, updateInterval * 1000);
    return () => {
      if (watchIdRef.current !== null) { navigator.geolocation.clearWatch(watchIdRef.current); watchIdRef.current = null; }
      if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null; }
    };
  }, [isSharingEnabled, isAuthenticated, updateInterval, myPosition]);

  // Persist to localStorage
  useEffect(() => { localStorage.setItem('evacora_location_sharing', String(isSharingEnabled)); }, [isSharingEnabled]);
  useEffect(() => { localStorage.setItem('evacora_update_interval', String(updateInterval)); }, [updateInterval]);

  const getStatusColor = (s: string) => {
    if (s === 'safe') return 'bg-green-100 text-green-700 border-green-300';
    if (s === 'checking') return 'bg-yellow-100 text-yellow-700 border-yellow-300';
    if (s === 'emergency') return 'bg-red-100 text-red-700 border-red-300';
    return 'bg-gray-100 text-gray-700 border-gray-300';
  };
  const getStatusIcon = (s: string) => {
    if (s === 'safe') return <CheckCircle className="w-4 h-4 text-green-600" />;
    if (s === 'checking') return <Clock className="w-4 h-4 text-yellow-600" />;
    if (s === 'emergency') return <AlertCircle className="w-4 h-4 text-red-600" />;
    return <MapPinOff className="w-4 h-4 text-gray-600" />;
  };
  const getStatusLabel = (s: string) => {
    const m: Record<string, string> = { safe: t('family.safe'), checking: t('family.moving'), emergency: t('alerts.emergencyMode'), offline: t('common.offline') };
    return m[s] || s;
  };

  const toggleSharing = useCallback(async () => {
    const next = !isSharingEnabled;
    setIsSharingEnabled(next);
    if (!next && isEmailAuthenticated) {
      try { await updateLocationMut.mutateAsync({ lat: 0, lng: 0, accuracy: 0 }); } catch {}
    }
    toast.success(next ? t('locationSharing.sharingOn') : t('locationSharing.sharingOff'));
  }, [isSharingEnabled, isAuthenticated, t]);

  const handleAddMember = () => {
    if (!newMember.name.trim()) {
      toast.error(t('contact.name'));
      return;
    }
    const id = Date.now().toString();
    const colorIndex = familyMembers.length % MEMBER_COLORS.length;
    const member: FamilyMember = {
      id,
      name: newMember.name.trim(),
      relation: newMember.relation.trim() || t('contact.family'),
      location: null,
      status: 'offline',
      lastUpdate: new Date(),
      distance: 0,
      phone: newMember.phone.trim(),
      color: MEMBER_COLORS[colorIndex],
    };
    setFamilyMembers(prev => [...prev, member]);
    
    // SMS 초대 코드 발송 (네이티브 문자 앱 연동)
    if (member.phone) {
      const inviteCode = Math.random().toString(36).substring(2, 8).toUpperCase();
      const inviteUrl = `${window.location.origin}/join-family?code=${inviteCode}`;
      const message = `${member.name}님이 Evacora 가족 안전 앱에 초대했습니다. 링크: ${inviteUrl}`;
      
      // 네이티브 문자 앱으로 이동 (tel: 대신 sms: 사용)
      const encodedMessage = encodeURIComponent(message);
      window.location.href = `sms:${member.phone}?body=${encodedMessage}`;
      
      toast.success(`${member.name}님에게 초대 코드 SMS를 발송했습니다!`);
    }
    
    setNewMember({ name: '', relation: '', phone: '' });
    setIsAddOpen(false);
  };

  const handleDeleteMember = (id: string) => {
    setFamilyMembers(prev => prev.filter(m => m.id !== id));
    toast.success(t('common.success'));
  };

  const handleSendInvite = async (member: FamilyMember) => {
    if (!isEmailAuthenticated) {
      toast.error('Please sign in to Evacora to send invites.');
      return;
    }
    try {
      const result = await createInviteMut.mutateAsync({
        nickname: member.name,
        relationship: member.relation,
        origin: window.location.origin,
      });
      await navigator.clipboard.writeText(result.inviteUrl);
      toast.success(`Invite link copied! Share with ${member.name}`);
    } catch (e: any) {
      toast.error(e.message || 'Failed to create invite');
    }
  };

  const handleSendLocationSms = async (member: FamilyMember) => {
    if (!myPosition) { toast.error('Location not available'); return; }
    if (!member.phone) { toast.error('No phone number for this member'); return; }
    if (!isEmailAuthenticated) { toast.error('Please sign in to Evacora first'); return; }
    try {
      await sendLocationSmsMut.mutateAsync({
        phoneNumber: member.phone,
        lat: myPosition.lat,
        lng: myPosition.lng,
        origin: window.location.origin,
        senderName: emailUser?.name || 'A family member',
      });
      toast.success(`Location sent to ${member.name}!`);
    } catch (e: any) {
      toast.error(e.message || 'Failed to send location');
    }
  };

  const handleSendInviteSms = (member: FamilyMember) => {
    if (!member.phone) {
      toast.error('No phone number for this member');
      return;
    }
    const inviteCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    const inviteUrl = `${window.location.origin}/join-family?code=${inviteCode}`;
    const message = `${member.name}님이 Evacora 가족 안전 앱에 초대했습니다. 링크: ${inviteUrl}`;
    const encodedMessage = encodeURIComponent(message);
    window.location.href = `sms:${member.phone}?body=${encodedMessage}`;
  };

  const handleMapReady = useCallback((map: google.maps.Map) => {
    mapRef.current = map;
    markersRef.current.forEach(m => m.map = null);
    markersRef.current = [];

    familyMembers.forEach((member) => {
      if (!member.location) return;
      const el = document.createElement('div');
      el.style.cssText = `width:36px;height:36px;border-radius:50%;background:${member.color};border:3px solid white;display:flex;align-items:center;justify-content:center;color:white;font-weight:bold;font-size:14px;box-shadow:0 2px 8px rgba(0,0,0,0.3);cursor:pointer;`;
      el.textContent = member.name.charAt(0);
      const marker = new google.maps.marker.AdvancedMarkerElement({ map, position: member.location, content: el, title: member.name });
      const iw = new google.maps.InfoWindow({
        content: `<div style="padding:8px;font-family:sans-serif;"><strong>${member.name}</strong><br/><span style="color:#666;font-size:12px;">${getStatusLabel(member.status)}</span><br/><span style="color:#999;font-size:11px;">${member.lastUpdate.toLocaleTimeString()}</span></div>`,
      });
      marker.addListener('click', () => iw.open({ anchor: marker, map }));
      markersRef.current.push(marker);
    });

    const userPos = myPosition || regionCenter;
    const uel = document.createElement('div');
    uel.style.cssText = 'width:20px;height:20px;border-radius:50%;background:#3B82F6;border:3px solid white;box-shadow:0 0 0 4px rgba(59,130,246,0.3),0 2px 8px rgba(0,0,0,0.3);';
    const um = new google.maps.marker.AdvancedMarkerElement({ map, position: userPos, content: uel, title: t('mapPage.yourLocation') });
    markersRef.current.push(um);
  }, [familyMembers, regionCenter, myPosition, t]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-2xl mx-auto px-4 py-4">
        <div className="mb-5 flex items-center gap-3">
          <button onClick={() => navigate("/home")} className="text-slate-600 hover:text-slate-900 transition-colors" aria-label={t('common.back')}>
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-slate-900">{t('family.title')}</h1>
            <p className="text-sm text-slate-600">{t('family.subtitle')}</p>
          </div>
        </div>

        {/* Location Sharing Control */}
        <Card className="mb-5 p-4 bg-white border-slate-200">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Share2 className="w-5 h-5 text-blue-600" />
              <h2 className="font-bold text-slate-900">{t('locationSharing.title')}</h2>
            </div>
            <button onClick={toggleSharing} className={`relative w-14 h-7 rounded-full transition-colors duration-200 ${isSharingEnabled ? 'bg-blue-600' : 'bg-slate-300'}`} aria-label={t('locationSharing.toggleSharing')}>
              <span className={`absolute top-0.5 left-0.5 w-6 h-6 bg-white rounded-full shadow transition-transform duration-200 ${isSharingEnabled ? 'translate-x-7' : 'translate-x-0'}`} />
            </button>
          </div>
          <p className="text-sm text-slate-500 mb-3">{t('locationSharing.subtitle')}</p>
          <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium ${isSharingEnabled ? 'bg-blue-50 text-blue-700' : 'bg-slate-100 text-slate-500'}`}>
            <Radio className={`w-4 h-4 ${isSharingEnabled ? 'animate-pulse' : ''}`} />
            <span>{isSharingEnabled ? t('locationSharing.sharingOn') : t('locationSharing.sharingOff')}</span>
            {isSharingEnabled && updateLocationMut.isPending && <span className="text-xs text-blue-400 ml-auto">Syncing...</span>}
          </div>
          {isSharingEnabled && (
            <div className="mt-3 pt-3 border-t border-slate-100">
              <p className="text-xs text-slate-500 mb-2">{t('locationSharing.updateInterval')}</p>
              <div className="flex gap-2">
                {UPDATE_INTERVALS.map((sec) => (
                  <button key={sec} onClick={() => setUpdateInterval(sec)} className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${updateInterval === sec ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                    {sec}{t('locationSharing.seconds')}
                  </button>
                ))}
              </div>
            </div>
          )}
        </Card>

        {/* Map Toggle */}
        {familyMembers.length > 0 && (
          <>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-slate-700" />
                <h2 className="font-bold text-slate-900">{t('locationSharing.friendsOnMap')}</h2>
              </div>
              <button onClick={() => setShowMap(!showMap)} className="text-sm text-blue-600 font-semibold hover:text-blue-700">
                {showMap ? t('common.home') : t('common.map')}
              </button>
            </div>

            {showMap && (
              <div className="mb-5 rounded-2xl overflow-hidden border border-slate-200 shadow-sm" style={{ height: 300 }}>
                <MapView className="w-full h-full" initialCenter={myPosition || regionCenter} initialZoom={13} onMapReady={handleMapReady} />
              </div>
            )}
            {showMap && (
              <div className="mb-5 flex flex-wrap gap-3">
                {familyMembers.filter(m => m.location).map((member) => (
                  <div key={member.id} className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full" style={{ background: member.color }} />
                    <span className="text-xs text-slate-600 font-medium">{member.name}</span>
                  </div>
                ))}
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-blue-500 ring-2 ring-blue-200" />
                  <span className="text-xs text-slate-600 font-medium">{t('mapPage.yourLocation')}</span>
                </div>
              </div>
            )}
          </>
        )}

        {/* Family Members List */}
        <div className="space-y-3">
          {familyMembers.length === 0 ? (
            <Card className="p-8 bg-white border-slate-200 text-center">
              <UserPlus className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-slate-700 mb-2">{t('family.noMembers')}</h3>
              <p className="text-sm text-slate-500 mb-4">{t('family.addMemberDesc')}</p>
            </Card>
          ) : (
            familyMembers.map((member) => (
              <Card key={member.id} className="p-4 bg-white border-slate-200 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3 flex-1">
                    <div className="w-11 h-11 rounded-full flex items-center justify-center text-white font-bold text-lg flex-shrink-0" style={{ background: member.color }}>
                      {member.name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base font-bold text-slate-900">{member.name}</h3>
                      <p className="text-xs text-slate-500">{member.relation}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs ${getStatusColor(member.status)}`}>
                      {getStatusIcon(member.status)}
                      <span className="font-semibold">{getStatusLabel(member.status)}</span>
                    </div>
                    <button onClick={() => handleDeleteMember(member.id)} className="text-slate-400 hover:text-red-500 transition-colors p-1">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                {member.location ? (
                  <div className="mb-3 p-2.5 bg-slate-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-blue-600" />
                        <span className="text-xs text-slate-600">{member.distance} km {t('family.away')}</span>
                      </div>
                      <span className="text-xs text-slate-400">{t('family.lastSeen')}: {member.lastUpdate.toLocaleTimeString()}</span>
                    </div>
                  </div>
                ) : (
                  <div className="mb-3 p-2.5 bg-gray-50 rounded-lg">
                    <p className="text-xs text-gray-500">{t('locationSharing.noFriends')}</p>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-2 mb-2">
                  <Button variant="outline" size="sm" className="flex items-center justify-center gap-1.5 border-blue-200 text-blue-600 hover:bg-blue-50" onClick={() => { if (member.phone) { window.location.href = `tel:${member.phone}`; } else { toast.info(t('home.callFeature')); } }}>
                    <Phone className="w-3.5 h-3.5" /> {t('family.call')}
                  </Button>
                  <Button variant="outline" size="sm" className="flex items-center justify-center gap-1.5 border-green-200 text-green-600 hover:bg-green-50" onClick={() => { if (member.phone) { window.location.href = `sms:${member.phone}`; } else { toast.info(t('home.callFeature')); } }}>
                    <MessageSquare className="w-3.5 h-3.5" /> {t('family.message')}
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" size="sm" className="flex items-center justify-center gap-1.5 border-purple-200 text-purple-600 hover:bg-purple-50" onClick={() => handleSendInviteSms(member)}>
                    <MessageSquare className="w-3.5 h-3.5" /> {t('family.sendInvite')}
                  </Button>
                  <Button variant="outline" size="sm" className="flex items-center justify-center gap-1.5 border-orange-200 text-orange-600 hover:bg-orange-50" onClick={() => handleSendLocationSms(member)} disabled={sendLocationSmsMut.isPending}>
                    <Navigation className="w-3.5 h-3.5" /> Send Location
                  </Button>
                </div>
              </Card>
            ))
          )}
        </div>

        {/* Add Family Member Button + Dialog */}
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="w-full mt-5 bg-blue-600 hover:bg-blue-700 text-white py-5 text-base font-semibold flex items-center justify-center gap-2">
              <Plus className="w-5 h-5" />
              {t('family.addMember')}
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-white border-slate-200 max-w-sm mx-auto">
            <DialogHeader>
              <DialogTitle className="text-slate-900 flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-blue-600" />
                {t('family.addMember')}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div>
                <Label className="text-slate-700 text-sm font-medium">{t('contact.name')} *</Label>
                <Input
                  placeholder={t('contact.name')}
                  value={newMember.name}
                  onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
                  className="mt-1 bg-slate-50 border-slate-200 text-slate-900"
                />
              </div>
              <div>
                <Label className="text-slate-700 text-sm font-medium">{t('contact.relationship')}</Label>
                <Input
                  placeholder={`${t('contact.family')}, ${t('contact.friend')}, ${t('contact.other')}`}
                  value={newMember.relation}
                  onChange={(e) => setNewMember({ ...newMember, relation: e.target.value })}
                  className="mt-1 bg-slate-50 border-slate-200 text-slate-900"
                />
              </div>
              <div>
                <Label className="text-slate-700 text-sm font-medium">{t('contact.phone')}</Label>
                <Input
                  placeholder="+82-10-1234-5678"
                  value={newMember.phone}
                  onChange={(e) => setNewMember({ ...newMember, phone: e.target.value })}
                  className="mt-1 bg-slate-50 border-slate-200 text-slate-900"
                />
              </div>
              <Button
                onClick={handleAddMember}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 font-semibold"
              >
                {t('family.addMember')}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Bulk Action Buttons */}
        {familyMembers.length > 0 && (
          <div className="grid grid-cols-2 gap-3 mt-4 pb-6">
            <Button className="bg-green-600 hover:bg-green-700 text-white py-4 font-semibold" onClick={() => toast.success(t('family.allSafe'))}>{t('family.allSafe')}</Button>
            <Button className="bg-red-600 hover:bg-red-700 text-white py-4 font-semibold" onClick={() => toast.error(t('family.emergencyAlert'))}>{t('family.emergencyAlert')}</Button>
          </div>
        )}

        {familyMembers.length === 0 && <div className="pb-6" />}
      </div>
    </div>
  );
}
