import { useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { MapView } from "@/components/Map";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, MapPin, Clock, Loader2, AlertTriangle } from "lucide-react";
import { useLocation } from "wouter";

interface LocationShareViewProps {
  token: string;
}

export default function LocationShareView({ token }: LocationShareViewProps) {
  const [, navigate] = useLocation();
  const mapRef = useRef<google.maps.Map | null>(null);
  const markerRef = useRef<google.maps.Marker | null>(null);

  const { data, isLoading, error } = trpc.emailAuth.getLocationShare.useQuery(
    { token },
    { enabled: !!token }
  );

  const handleMapReady = (map: google.maps.Map) => {
    mapRef.current = map;
    if (data?.lat && data?.lng) {
      const pos = { lat: data.lat, lng: data.lng };
      map.setCenter(pos);
      map.setZoom(15);
      markerRef.current = new google.maps.Marker({
        position: pos,
        map,
        title: `${data.senderName}'s location`,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 12,
          fillColor: "#ef4444",
          fillOpacity: 1,
          strokeColor: "#ffffff",
          strokeWeight: 3,
        },
      });
      new google.maps.InfoWindow({
        content: `<div style="font-family:sans-serif;padding:4px 8px"><strong>${data.senderName}</strong><br/><span style="color:#666;font-size:12px">Shared location</span></div>`,
      }).open(map, markerRef.current);
    }
  };

  useEffect(() => {
    if (mapRef.current && data?.lat && data?.lng) {
      const pos = { lat: data.lat, lng: data.lng };
      mapRef.current.setCenter(pos);
      mapRef.current.setZoom(15);
      if (markerRef.current) {
        markerRef.current.setPosition(pos);
      }
    }
  }, [data]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0f172a" }}>
        <Loader2 className="w-8 h-8 text-red-400 animate-spin" />
      </div>
    );
  }

  if (!data || error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4" style={{ background: "#0f172a" }}>
        <AlertTriangle className="w-12 h-12 text-amber-400 mb-4" />
        <h2 className="text-white text-xl font-bold mb-2">Link Expired or Invalid</h2>
        <p className="text-slate-400 text-sm text-center mb-6">
          This location share link has expired or is no longer valid.
        </p>
        <Button onClick={() => navigate("/")} className="bg-red-500 hover:bg-red-600 text-white">
          Go to Evacora
        </Button>
      </div>
    );
  }

  const timeAgo = (date: Date) => {
    const diff = Date.now() - new Date(date).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return "Just now";
    if (mins < 60) return `${mins}m ago`;
    return `${Math.floor(mins / 60)}h ago`;
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "#0f172a" }}>
      {/* Header */}
      <div
        className="flex items-center gap-3 px-4 py-3 sticky top-0 z-50"
        style={{ background: "rgba(15,23,42,0.95)", backdropFilter: "blur(12px)", borderBottom: "1px solid rgba(255,255,255,0.06)" }}
      >
        <div className="w-8 h-8 rounded-xl bg-red-500 flex items-center justify-center">
          <Shield className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="text-white font-bold text-base" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Evacora</h1>
          <p className="text-slate-400 text-xs">Location Share</p>
        </div>
      </div>

      {/* Info card */}
      <div className="px-4 pt-4 pb-2">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0">
              <MapPin className="w-5 h-5 text-red-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-semibold text-sm">{data.senderName} shared their location</p>
              <div className="flex items-center gap-1 text-slate-400 text-xs mt-0.5">
                <Clock className="w-3 h-3" />
                <span>Shared {timeAgo(data.createdAt)}</span>
                <span className="mx-1">·</span>
                <span>Expires {timeAgo(new Date(Date.now() - (new Date(data.expiresAt).getTime() - Date.now())))} from now</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Map */}
      <div className="flex-1 mx-4 mb-4 rounded-2xl overflow-hidden" style={{ minHeight: 400 }}>
        <MapView
          onMapReady={handleMapReady}
          className="w-full h-full min-h-[400px]"
        />
      </div>

      {/* Get Directions */}
      <div className="px-4 pb-6">
        <Button
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold"
          onClick={() => {
            const url = `https://www.google.com/maps/dir/?api=1&destination=${data.lat},${data.lng}`;
            window.open(url, "_blank");
          }}
        >
          Get Directions to {data.senderName}
        </Button>
      </div>
    </div>
  );
}
