/**
 * Peacetime Mode Test Page
 * Dedicated page to test the peacetime mode UI
 */

import { PeacetimeMode } from "@/components/PeacetimeMode";

export default function Peacetime() {
  return <PeacetimeMode />;
}
