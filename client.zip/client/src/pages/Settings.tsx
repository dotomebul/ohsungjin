import React, { useState, useCallback, useEffect } from 'react';
import { useI18n } from '@/contexts/I18nContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Language, Region, getLanguageName } from '@shared/i18n/translations';
import { ChevronRight, Bell, Globe, LogOut, ArrowLeft, Shield, BellRing, BellOff, MessageSquare, Copyright } from 'lucide-react';
import { useLocation } from 'wouter';
import { useAuth } from '@/_core/hooks/useAuth';
import { getLoginUrl } from '@/const';
import { toast } from 'sonner';
import { FeedbackForm } from '@/components/FeedbackForm';

const AVAILABLE_LANGUAGES: Language[] = ['en', 'es', 'de', 'fr', 'ko', 'ja'];
const AVAILABLE_REGIONS: Region[] = ['us', 'eu', 'kr', 'jp'];

interface NotificationSettings {
  pushEnabled: boolean;
  smsAlerts: boolean;
  earthquakeAlert: boolean;
  tsunamiAlert: boolean;
  typhoonAlert: boolean;
  wildfireAlert: boolean;
  floodAlert: boolean;
  warAlert: boolean;
}

export default function Settings() {
  const { language, region, setLanguage, setRegion, t } = useI18n();
  const [, navigate] = useLocation();
  const { logout, isAuthenticated } = useAuth();
  const [showFeedback, setShowFeedback] = useState(false);
  const [pushSupported] = useState(() => 'Notification' in window);
  const [pushPermission, setPushPermission] = useState<NotificationPermission>(
    pushSupported ? Notification.permission : 'default'
  );

  const [notifications, setNotifications] = useState<NotificationSettings>(() => {
    const saved = localStorage.getItem('evacora_notifications');
    if (saved) return JSON.parse(saved);
    return {
      pushEnabled: false,
      smsAlerts: true,
      earthquakeAlert: true,
      tsunamiAlert: true,
      typhoonAlert: true,
      wildfireAlert: true,
      floodAlert: true,
      warAlert: true,
    };
  });

  // Persist notification settings
  useEffect(() => {
    localStorage.setItem('evacora_notifications', JSON.stringify(notifications));
  }, [notifications]);

  const regionLabels: Record<Region, string> = {
    us: t('regions.unitedStates'),
    eu: t('regions.europe'),
    kr: t('regions.korea'),
    jp: t('regions.japan'),
  };

  const handleToggle = (key: keyof NotificationSettings) => {
    setNotifications((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const requestPushPermission = useCallback(async () => {
    if (!pushSupported) {
      toast.error('Push notifications not supported in this browser');
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      setPushPermission(permission);

      if (permission === 'granted') {
        setNotifications((prev) => ({ ...prev, pushEnabled: true }));
        toast.success(t('pushNotification.enabled'));

        // Show a test notification
        new Notification('Evacora', {
          body: t('pushNotification.enabled'),
          icon: '/favicon.ico',
          tag: 'evacora-test',
        });
      } else if (permission === 'denied') {
        toast.error(t('pushNotification.permissionDenied'));
        setNotifications((prev) => ({ ...prev, pushEnabled: false }));
      }
    } catch (err) {
      toast.error('Failed to request notification permission');
    }
  }, [pushSupported, t]);

  const disablePush = useCallback(() => {
    setNotifications((prev) => ({ ...prev, pushEnabled: false }));
    toast.info(t('pushNotification.disabled'));
  }, [t]);

  const ToggleSwitch = ({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) => (
    <button
      onClick={onChange}
      className={`relative w-11 h-6 rounded-full transition-colors duration-200 ${
        checked ? 'bg-blue-600' : 'bg-slate-300'
      }`}
      aria-label={label}
      role="switch"
      aria-checked={checked}
    >
      <span
        className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform duration-200 ${
          checked ? 'translate-x-5' : 'translate-x-0'
        }`}
      />
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button onClick={() => navigate("/home")} className="text-slate-600 hover:text-slate-900 transition-colors" aria-label={t('common.back')}>
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-slate-900">{t('common.settings')}</h1>
        </div>

        {/* Language Settings */}
        <Card className="mb-4 p-5 bg-white border-slate-200">
          <div className="flex items-center gap-3 mb-4">
            <Globe className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-900">{t('common.selectLanguage')}</h2>
          </div>
          <div className="space-y-2">
            {AVAILABLE_LANGUAGES.map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`w-full flex items-center justify-between p-3 rounded-lg border-2 transition-all ${
                  language === lang ? 'bg-blue-50 border-blue-300' : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <span className="font-semibold text-slate-900">{getLanguageName(lang)}</span>
                {language === lang && <ChevronRight className="w-5 h-5 text-blue-600" />}
              </button>
            ))}
          </div>
        </Card>

        {/* Region Settings */}
        <Card className="mb-4 p-5 bg-white border-slate-200">
          <div className="flex items-center gap-3 mb-4">
            <Globe className="w-5 h-5 text-green-600" />
            <h2 className="text-lg font-bold text-slate-900">{t('common.selectRegion')}</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {AVAILABLE_REGIONS.map((reg) => (
              <button
                key={reg}
                onClick={() => setRegion(reg)}
                className={`p-3 rounded-lg border-2 transition-all text-center ${
                  region === reg ? 'bg-green-50 border-green-300' : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <span className="font-semibold text-slate-900">{regionLabels[reg]}</span>
              </button>
            ))}
          </div>
        </Card>

        {/* Push Notification Settings */}
        <Card className="mb-4 p-5 bg-white border-slate-200">
          <div className="flex items-center gap-3 mb-4">
            <Bell className="w-5 h-5 text-orange-600" />
            <h2 className="text-lg font-bold text-slate-900">{t('pushNotification.title')}</h2>
          </div>

          {/* Push Enable/Disable */}
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg mb-4">
            <div className="flex items-center gap-2">
              {notifications.pushEnabled ? (
                <BellRing className="w-5 h-5 text-blue-600" />
              ) : (
                <BellOff className="w-5 h-5 text-slate-400" />
              )}
              <div>
                <p className="font-semibold text-slate-900 text-sm">
                  {notifications.pushEnabled ? t('pushNotification.enabled') : t('pushNotification.disabled')}
                </p>
                {pushPermission === 'denied' && (
                  <p className="text-xs text-red-500">{t('pushNotification.permissionDenied')}</p>
                )}
              </div>
            </div>
            {notifications.pushEnabled ? (
              <Button variant="outline" size="sm" onClick={disablePush} className="text-red-600 border-red-200 hover:bg-red-50">
                {t('pushNotification.disable')}
              </Button>
            ) : (
              <Button size="sm" onClick={requestPushPermission} className="bg-blue-600 hover:bg-blue-700 text-white" disabled={pushPermission === 'denied'}>
                {t('pushNotification.enable')}
              </Button>
            )}
          </div>

          {/* Alert Type Toggles */}
          {notifications.pushEnabled && (
            <div className="space-y-2">
              <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider mb-2">{t('pushNotification.alertTypes')}</p>
              {([
                { key: 'earthquakeAlert' as const, label: t('pushNotification.earthquakeAlert'), emoji: '🌍' },
                { key: 'tsunamiAlert' as const, label: t('pushNotification.tsunamiAlert'), emoji: '🌊' },
                { key: 'typhoonAlert' as const, label: t('pushNotification.typhoonAlert'), emoji: '🌀' },
                { key: 'wildfireAlert' as const, label: t('pushNotification.wildfireAlert'), emoji: '🔥' },
                { key: 'floodAlert' as const, label: t('pushNotification.floodAlert'), emoji: '💧' },
                { key: 'warAlert' as const, label: t('pushNotification.warAlert'), emoji: '⚠' },
              ]).map(({ key, label, emoji }) => (
                <div key={key} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <span className="text-base">{emoji}</span>
                    <span className="font-medium text-slate-900 text-sm">{label}</span>
                  </div>
                  <ToggleSwitch
                    checked={notifications[key]}
                    onChange={() => handleToggle(key)}
                    label={label}
                  />
                </div>
              ))}
            </div>
          )}

          {/* SMS Alerts */}
          <div className="mt-4 pt-4 border-t border-slate-100">
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <span className="font-medium text-slate-900 text-sm">{t('settingsPage.smsNotifications')}</span>
              <ToggleSwitch
                checked={notifications.smsAlerts}
                onChange={() => handleToggle('smsAlerts')}
                label={t('settingsPage.smsNotifications')}
              />
            </div>
          </div>
        </Card>

        {/* Privacy */}
        <Card className="mb-4 p-5 bg-white border-slate-200">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-5 h-5 text-purple-600" />
            <h2 className="text-lg font-bold text-slate-900">{t('settingsPage.about')}</h2>
          </div>
          <button
            onClick={() => navigate("/privacy")}
            className="w-full flex items-center justify-between p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors mb-2"
          >
            <span className="font-semibold text-slate-900">{t('settingsPage.privacy')}</span>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>
          <button
            onClick={() => navigate("/terms")}
            className="w-full flex items-center justify-between p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors mb-2"
          >
            <span className="font-semibold text-slate-900">{t('settingsPage.terms')}</span>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>
          <button
            onClick={() => navigate("/license")}
            className="w-full flex items-center justify-between p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors mb-2"
          >
            <div className="flex items-center gap-2">
              <Copyright className="w-4 h-4 text-slate-600" />
              <span className="font-semibold text-slate-900">License & Copyright</span>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>
          <button
            onClick={() => setShowFeedback(true)}
            className="w-full flex items-center justify-between p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors mb-2"
          >
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-slate-600" />
              <span className="font-semibold text-slate-900">Send Feedback</span>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>
          <div className="p-3 bg-slate-50 rounded-lg">
            <p className="text-xs text-slate-500">{t('settingsPage.version')}: 1.0.0</p>
            <p className="text-xs text-slate-500 mt-1">© 2024-2026 Evacora · Manus Platform</p>
          </div>
        </Card>

        {/* Logout / Login Button */}
        {isAuthenticated ? (
          <Button
            onClick={() => logout()}
            className="w-full mb-6 bg-red-600 hover:bg-red-700 text-white py-5 text-base flex items-center justify-center gap-2 font-semibold"
          >
            <LogOut className="w-5 h-5" />
            {t('common.logout')}
          </Button>
        ) : (
          <Button
            onClick={() => { window.location.href = getLoginUrl(); }}
            className="w-full mb-6 bg-blue-600 hover:bg-blue-700 text-white py-5 text-base flex items-center justify-center gap-2 font-semibold"
          >
            <LogOut className="w-5 h-5" />
            {t('common.login')}
          </Button>
        )}

        {/* Feedback Form Modal */}
        <FeedbackForm isOpen={showFeedback} onClose={() => setShowFeedback(false)} />
      </div>
    </div>
  );
}
