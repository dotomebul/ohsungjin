import React from 'react';
import { useI18n } from '@/contexts/I18nContext';
import { Card } from '@/components/ui/card';
import { ArrowLeft, Shield, MapPin, Bell, Database, Lock } from 'lucide-react';
import { useLocation } from 'wouter';

export default function Privacy() {
  const { t, language } = useI18n();
  const [, navigate] = useLocation();

  const content = getPrivacyContent(language);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button onClick={() => navigate("/settings")} className="text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">{t('settingsPage.privacy')}</h1>
            <p className="text-sm text-slate-500">Evacora v1.0.0</p>
          </div>
        </div>

        {content.sections.map((section, idx) => (
          <Card key={idx} className="mb-4 p-6 bg-white border-slate-200">
            <div className="flex items-center gap-3 mb-4">
              {section.icon}
              <h2 className="text-lg font-bold text-slate-900">{section.title}</h2>
            </div>
            <div className="text-sm text-slate-700 leading-relaxed space-y-3">
              {section.paragraphs.map((p, pIdx) => (
                <p key={pIdx}>{p}</p>
              ))}
            </div>
          </Card>
        ))}

        <div className="text-center py-4">
          <p className="text-xs text-slate-500">{content.lastUpdated}</p>
        </div>
      </div>
    </div>
  );
}

function getPrivacyContent(language: string) {
  if (language === 'ko') {
    return {
      lastUpdated: '최종 업데이트: 2025년 4월',
      sections: [
        {
          icon: <Shield className="w-5 h-5 text-blue-600" />,
          title: '개인정보 수집 및 이용',
          paragraphs: [
            'Evacora는 긴급 상황 대응 서비스를 제공하기 위해 최소한의 개인정보만 수집합니다.',
            '수집 항목: 이름, 이메일, 전화번호, 위치 정보 (선택적)',
            '수집 목적: 긴급 알림 전송, 대피소 안내, 비상 연락처 관리, 위치 기반 서비스 제공',
          ],
        },
        {
          icon: <MapPin className="w-5 h-5 text-green-600" />,
          title: '위치 정보',
          paragraphs: [
            '위치 정보는 사용자의 명시적 동의 하에만 수집됩니다.',
            '위치 정보는 근처 대피소 검색, 안전 경로 안내, 긴급 SOS 전송 시에만 사용됩니다.',
            '위치 공유는 언제든지 설정에서 비활성화할 수 있습니다.',
          ],
        },
        {
          icon: <Bell className="w-5 h-5 text-orange-600" />,
          title: 'SMS 알림',
          paragraphs: [
            'SMS 알림은 Twilio를 통해 전송됩니다.',
            '안전 확인 및 SOS 메시지는 사용자가 등록한 비상 연락처에만 전송됩니다.',
            '메시지 전송 기록은 서비스 품질 관리를 위해 보관됩니다.',
          ],
        },
        {
          icon: <Database className="w-5 h-5 text-purple-600" />,
          title: '데이터 보관 및 삭제',
          paragraphs: [
            '개인정보는 서비스 이용 기간 동안 보관되며, 탈퇴 시 즉시 삭제됩니다.',
            '법적 의무에 따라 일부 데이터는 일정 기간 보관될 수 있습니다.',
            '데이터 삭제 요청은 설정 메뉴에서 할 수 있습니다.',
          ],
        },
        {
          icon: <Lock className="w-5 h-5 text-red-600" />,
          title: '보안',
          paragraphs: [
            '모든 데이터는 암호화되어 전송 및 저장됩니다.',
            'SSL/TLS 프로토콜을 사용하여 통신을 보호합니다.',
            '정기적인 보안 점검을 통해 데이터 안전을 유지합니다.',
          ],
        },
      ],
    };
  }

  if (language === 'ja') {
    return {
      lastUpdated: '最終更新: 2025年4月',
      sections: [
        {
          icon: <Shield className="w-5 h-5 text-blue-600" />,
          title: '個人情報の収集と利用',
          paragraphs: [
            'Evacoraは緊急対応サービスを提供するために最小限の個人情報のみを収集します。',
            '収集項目: 名前、メールアドレス、電話番号、位置情報（任意）',
            '収集目的: 緊急通知の送信、避難所案内、緊急連絡先管理、位置情報サービスの提供',
          ],
        },
        {
          icon: <MapPin className="w-5 h-5 text-green-600" />,
          title: '位置情報',
          paragraphs: [
            '位置情報はユーザーの明示的な同意の下でのみ収集されます。',
            '位置情報は近くの避難所検索、安全ルート案内、緊急SOS送信にのみ使用されます。',
            '位置共有はいつでも設定で無効にできます。',
          ],
        },
        {
          icon: <Bell className="w-5 h-5 text-orange-600" />,
          title: 'SMS通知',
          paragraphs: [
            'SMS通知はTwilioを通じて送信されます。',
            '安全確認およびSOSメッセージはユーザーが登録した緊急連絡先にのみ送信されます。',
            'メッセージ送信記録はサービス品質管理のために保管されます。',
          ],
        },
        {
          icon: <Database className="w-5 h-5 text-purple-600" />,
          title: 'データの保管と削除',
          paragraphs: [
            '個人情報はサービス利用期間中保管され、退会時に即座に削除されます。',
            '法的義務に基づき、一部のデータは一定期間保管される場合があります。',
            'データ削除リクエストは設定メニューから行えます。',
          ],
        },
        {
          icon: <Lock className="w-5 h-5 text-red-600" />,
          title: 'セキュリティ',
          paragraphs: [
            'すべてのデータは暗号化されて送受信・保存されます。',
            'SSL/TLSプロトコルを使用して通信を保護します。',
            '定期的なセキュリティ監査によりデータの安全性を維持します。',
          ],
        },
      ],
    };
  }

  // Default: English (also covers es, de, fr)
  return {
    lastUpdated: 'Last updated: April 2025',
    sections: [
      {
        icon: <Shield className="w-5 h-5 text-blue-600" />,
        title: 'Data Collection & Usage',
        paragraphs: [
          'Evacora collects only the minimum personal information necessary to provide emergency response services.',
          'Collected data: Name, email, phone number, location data (optional)',
          'Purpose: Emergency notifications, shelter guidance, emergency contact management, location-based services',
        ],
      },
      {
        icon: <MapPin className="w-5 h-5 text-green-600" />,
        title: 'Location Data',
        paragraphs: [
          'Location data is collected only with your explicit consent.',
          'Location data is used solely for nearby shelter search, safe route guidance, and emergency SOS transmission.',
          'Location sharing can be disabled at any time in Settings.',
        ],
      },
      {
        icon: <Bell className="w-5 h-5 text-orange-600" />,
        title: 'SMS Notifications',
        paragraphs: [
          'SMS notifications are sent through Twilio.',
          'Safety check and SOS messages are sent only to emergency contacts you have registered.',
          'Message delivery records are retained for service quality management.',
        ],
      },
      {
        icon: <Database className="w-5 h-5 text-purple-600" />,
        title: 'Data Retention & Deletion',
        paragraphs: [
          'Personal data is retained during your use of the service and deleted immediately upon account deletion.',
          'Some data may be retained for a period as required by law.',
          'Data deletion requests can be made from the Settings menu.',
        ],
      },
      {
        icon: <Lock className="w-5 h-5 text-red-600" />,
        title: 'Security',
        paragraphs: [
          'All data is encrypted during transmission and storage.',
          'SSL/TLS protocols are used to protect communications.',
          'Regular security audits are conducted to maintain data safety.',
        ],
      },
    ],
  };
}
