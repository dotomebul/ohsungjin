import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Star } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useI18n } from "@/contexts/I18nContext";

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function FeedbackModal({ isOpen, onClose }: FeedbackModalProps) {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { region, language } = useI18n();
  const submitFeedback = trpc.feedback.submit.useMutation();

  const handleSubmit = async () => {
    if (rating === 0) {
      toast.error("평가를 선택해주세요");
      return;
    }

    setIsSubmitting(true);
    try {
      await submitFeedback.mutateAsync({
        rating,
        comment: comment.trim() || undefined,
        region: region || undefined,
        language: language || undefined,
      });

      toast.success("피드백을 보내주셔서 감사합니다!");
      setRating(0);
      setComment("");
      onClose();
    } catch (error) {
      console.error("피드백 제출 실패:", error);
      toast.error("피드백 제출에 실패했습니다");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSkip = () => {
    setRating(0);
    setComment("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>앱 피드백</DialogTitle>
          <DialogDescription>
            Evacora를 사용하신 경험에 대해 알려주세요
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* 별점 평가 */}
          <div className="flex flex-col items-center gap-4">
            <p className="text-sm font-medium">이 앱에 대해 어떻게 생각하세요?</p>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    size={32}
                    className={`${
                      star <= (hoverRating || rating)
                        ? "fill-yellow-400 text-yellow-400"
                        : "text-gray-300"
                    }`}
                  />
                </button>
              ))}
            </div>
            {rating > 0 && (
              <p className="text-sm text-gray-600">
                {rating === 1 && "별로예요"}
                {rating === 2 && "괜찮아요"}
                {rating === 3 && "좋아요"}
                {rating === 4 && "매우 좋아요"}
                {rating === 5 && "최고예요!"}
              </p>
            )}
          </div>

          {/* 의견 입력 */}
          <div className="space-y-2">
            <label className="text-sm font-medium">
              추가 의견 (선택사항)
            </label>
            <Textarea
              placeholder="앱을 개선할 점이나 좋은 점을 알려주세요..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              maxLength={1000}
              className="resize-none"
              rows={4}
            />
            <p className="text-xs text-gray-500 text-right">
              {comment.length}/1000
            </p>
          </div>

          {/* 버튼 */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={handleSkip}
              disabled={isSubmitting}
              className="flex-1"
            >
              나중에
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={isSubmitting || rating === 0}
              className="flex-1"
            >
              {isSubmitting ? "전송 중..." : "피드백 보내기"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
