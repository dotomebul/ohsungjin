import { useState, useMemo } from 'react';
import { Search, X } from 'lucide-react';
import { ShelterData } from '@shared/shelterData';
import { Button } from '@/components/ui/button';

interface ShelterSearchProps {
  shelters: ShelterData[];
  onSelect: (shelter: ShelterData) => void;
  placeholder?: string;
}

/**
 * 대피소 검색 컴포넌트
 * - 이름, 주소, 도시로 검색 가능
 * - 실시간 필터링
 * - 최대 10개 결과 표시
 */
export function ShelterSearch({ shelters, onSelect, placeholder = "Search shelters by name, address, or city..." }: ShelterSearchProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  // 검색 결과 필터링
  const filteredShelters = useMemo(() => {
    if (!searchQuery.trim()) return [];

    const query = searchQuery.toLowerCase();
    return shelters
      .filter(shelter => {
        const name = shelter.name.toLowerCase();
        const address = shelter.address.toLowerCase();
        // address에서 도시명 추출 (마지막 부분)
        const addressParts = address.split(',');
        const city = addressParts.length > 1 ? addressParts[addressParts.length - 2].trim() : '';
        
        return name.includes(query) || address.includes(query) || city.includes(query);
      })
      .slice(0, 10); // 최대 10개 결과
  }, [searchQuery, shelters]);

  const handleSelect = (shelter: ShelterData) => {
    onSelect(shelter);
    setSearchQuery('');
    setIsOpen(false);
  };

  const handleClear = () => {
    setSearchQuery('');
    setIsOpen(false);
  };

  return (
    <div className="relative w-full">
      {/* 검색 입력 필드 */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder={placeholder}
          className="w-full pl-10 pr-10 py-2 rounded-lg border border-slate-300 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          aria-label="Search shelters"
          aria-autocomplete="list"
          aria-controls="shelter-search-results"
          aria-expanded={isOpen && filteredShelters.length > 0}
        />
        {searchQuery && (
          <button
            onClick={handleClear}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-slate-100 rounded"
            aria-label="Clear search"
          >
            <X className="w-4 h-4 text-slate-400" />
          </button>
        )}
      </div>

      {/* 검색 결과 드롭다운 */}
      {isOpen && filteredShelters.length > 0 && (
        <div
          id="shelter-search-results"
          className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-lg shadow-lg z-50 max-h-96 overflow-y-auto"
          role="listbox"
        >
          {filteredShelters.map((shelter, index) => (
            <button
              key={shelter.id}
              onClick={() => handleSelect(shelter)}
              className="w-full text-left px-4 py-3 hover:bg-slate-50 border-b border-slate-100 last:border-b-0 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-slate-50"
              role="option"
              aria-selected={false}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <p className="font-semibold text-slate-900">{shelter.name}</p>
                  <p className="text-sm text-slate-600">{shelter.address}</p>
                  <div className="flex gap-2 mt-1 text-xs text-slate-500">
                    <span>📍 {shelter.address.split(',').slice(-2).join(',').trim()}</span>
                    <span>👥 {shelter.capacity}</span>
                  </div>
                </div>
                <div className="text-right text-xs text-slate-500">
                  <p>{shelter.type}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* 검색 결과 없음 */}
      {isOpen && searchQuery && filteredShelters.length === 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-lg shadow-lg z-50 p-4 text-center text-slate-600">
          No shelters found matching "{searchQuery}"
        </div>
      )}
    </div>
  );
}
