/**
 * News Card Component
 * Displays a single news article
 */

import { ExternalLink, Calendar, Newspaper } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface NewsCardProps {
  id: string;
  title: string;
  description: string;
  url: string;
  image: string;
  source: string;
  publishedAt: Date;
  onOpenNews: (url: string) => void;
}

export function NewsCard({
  id,
  title,
  description,
  url,
  image,
  source,
  publishedAt,
  onOpenNews,
}: NewsCardProps) {
  const timeAgo = formatDistanceToNow(new Date(publishedAt), { addSuffix: true });

  return (
    <div className="bg-white rounded-lg border border-slate-200 overflow-hidden hover:shadow-md transition-shadow">
      {/* Image */}
      {image && (
        <div className="w-full h-40 bg-slate-200 overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover hover:scale-105 transition-transform"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = 'none';
            }}
          />
        </div>
      )}

      {/* Content */}
      <div className="p-4 space-y-3">
        {/* Source & Time */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1">
            <Newspaper className="w-3 h-3 text-slate-500" />
            <span className="text-xs font-semibold text-slate-600">{source}</span>
          </div>
          <div className="flex items-center gap-1">
            <Calendar className="w-3 h-3 text-slate-500" />
            <span className="text-xs text-slate-500">{timeAgo}</span>
          </div>
        </div>

        {/* Title */}
        <h3 className="text-sm font-bold text-slate-900 line-clamp-2 hover:text-blue-600 transition-colors">
          {title}
        </h3>

        {/* Description */}
        <p className="text-xs text-slate-600 line-clamp-2">{description}</p>

        {/* Read More Button */}
        <button
          onClick={() => onOpenNews(url)}
          className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors text-xs font-semibold"
        >
          <ExternalLink className="w-3 h-3" />
          Read Full Article
        </button>
      </div>
    </div>
  );
}
