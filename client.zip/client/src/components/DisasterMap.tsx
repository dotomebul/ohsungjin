import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, Circle } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

interface Disaster {
  id: string;
  type: "earthquake" | "flood" | "wildfire" | "storm" | "volcano" | "tsunami";
  severity: "low" | "medium" | "high";
  latitude: number;
  longitude: number;
  description: string;
  distance?: number;
}

interface Shelter {
  id: number;
  name: string;
  lat: string;
  lng: string;
  capacity: number;
  type: string;
  distance?: number;
}

interface DisasterMapProps {
  disasters: Disaster[];
  userLocation: { lat: number; lng: number };
  shelters?: Shelter[];
  onDisasterClick?: (disaster: Disaster) => void;
  onShelterClick?: (shelter: Shelter) => void;
}

// 재난 아이콘 매핑
const disasterIcons = {
  earthquake: "🌍",
  flood: "💧",
  wildfire: "🔥",
  storm: "⛈️",
  volcano: "🌋",
  tsunami: "🌊",
};

// 심각도별 색상
const severityColors = {
  low: "#22c55e", // 초록
  medium: "#f59e0b", // 주황
  high: "#ef4444", // 빨강
};

// 심각도별 반지름 (km)
const severityRadius = {
  low: 5,
  medium: 15,
  high: 30,
};

// Leaflet 커스텀 아이콘 생성
const createCustomIcon = (emoji: string) => {
  return L.divIcon({
    html: `<div style="font-size: 24px; text-align: center;">${emoji}</div>`,
    iconSize: [32, 32],
    className: "custom-icon",
  });
};

export function DisasterMap({
  disasters,
  userLocation,
  shelters = [],
  onDisasterClick,
  onShelterClick,
}: DisasterMapProps) {
  const [map, setMap] = useState<L.Map | null>(null);

  useEffect(() => {
    if (map && userLocation) {
      map.setView([userLocation.lat, userLocation.lng], 10);
    }
  }, [map, userLocation]);

  return (
    <div className="w-full h-96 rounded-lg overflow-hidden border border-border">
      <MapContainer
        center={[userLocation.lat, userLocation.lng]}
        zoom={10}
        style={{ width: "100%", height: "100%" }}
        ref={setMap}
      >
        {/* OpenStreetMap 타일 */}
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />

        {/* 사용자 위치 */}
        <Marker
          position={[userLocation.lat, userLocation.lng]}
          icon={createCustomIcon("📍")}
        >
          <Popup>
            <div className="text-sm">
              <p className="font-bold">Your Location</p>
              <p className="text-xs text-gray-500">
                {userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}
              </p>
            </div>
          </Popup>
        </Marker>

        {/* 재난 지점 */}
        {disasters.map((disaster) => (
          <div key={disaster.id}>
            {/* 재난 위험 범위 (원) */}
            <Circle
              center={[disaster.latitude, disaster.longitude]}
              radius={
                (severityRadius[disaster.severity] || 10) * 1000
              } /* km to meters */
              pathOptions={{
                color: severityColors[disaster.severity],
                fillColor: severityColors[disaster.severity],
                fillOpacity: 0.2,
                weight: 2,
              }}
            />

            {/* 재난 마커 */}
            <Marker
              position={[disaster.latitude, disaster.longitude]}
              icon={createCustomIcon(disasterIcons[disaster.type])}
              eventHandlers={{
                click: () => onDisasterClick?.(disaster),
              }}
            >
              <Popup>
                <div className="text-sm max-w-xs">
                  <p className="font-bold">{disaster.description}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Severity: <span className="font-semibold">{disaster.severity}</span>
                  </p>
                  {disaster.distance && (
                    <p className="text-xs text-gray-500">
                      Distance: {disaster.distance.toFixed(1)} km
                    </p>
                  )}
                </div>
              </Popup>
            </Marker>
          </div>
        ))}

        {/* 대피소 마커 */}
        {shelters.map((shelter) => (
          <Marker
            key={shelter.id}
            position={[parseFloat(shelter.lat), parseFloat(shelter.lng)]}
            icon={createCustomIcon("🏫")}
            eventHandlers={{
              click: () => onShelterClick?.(shelter),
            }}
          >
            <Popup>
              <div className="text-sm max-w-xs">
                <p className="font-bold">{shelter.name}</p>
                <p className="text-xs text-gray-500 mt-1">
                  Capacity: {shelter.capacity} people
                </p>
                <p className="text-xs text-gray-500">Type: {shelter.type}</p>
                {shelter.distance && (
                  <p className="text-xs text-gray-500">
                    Distance: {shelter.distance.toFixed(1)} km
                  </p>
                )}
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* 범례 */}
      <div className="absolute bottom-4 left-4 bg-white p-3 rounded-lg shadow-md text-xs z-50">
        <p className="font-bold mb-2">Legend</p>
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span>📍</span>
            <span>Your Location</span>
          </div>
          <div className="flex items-center gap-2">
            <span>🏫</span>
            <span>Shelter</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-lg">🔥</span>
            <span>Disaster</span>
          </div>
        </div>
      </div>
    </div>
  );
}
