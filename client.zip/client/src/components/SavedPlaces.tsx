import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, MapPin, Trash2, Navigation } from "lucide-react";
import { toast } from "sonner";

interface SavedPlace {
  id: string;
  name: string;
  lat: number;
  lng: number;
  type: "shelter" | "safe_zone" | "hospital" | "police";
  savedAt: Date;
  notes?: string;
}

export function SavedPlaces() {
  const [savedPlaces, setSavedPlaces] = useState<SavedPlace[]>(() => {
    const saved = localStorage.getItem("savedPlaces");
    return saved ? JSON.parse(saved) : [];
  });

  const savePlace = (place: Omit<SavedPlace, "id" | "savedAt">) => {
    const newPlace: SavedPlace = {
      ...place,
      id: Date.now().toString(),
      savedAt: new Date(),
    };
    const updated = [...savedPlaces, newPlace];
    setSavedPlaces(updated);
    localStorage.setItem("savedPlaces", JSON.stringify(updated));
    toast.success("Place saved successfully!");
  };

  const removePlace = (id: string) => {
    const updated = savedPlaces.filter(p => p.id !== id);
    setSavedPlaces(updated);
    localStorage.setItem("savedPlaces", JSON.stringify(updated));
    toast.success("Place removed");
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "shelter":
        return "🏠";
      case "safe_zone":
        return "✅";
      case "hospital":
        return "🏥";
      case "police":
        return "🚔";
      default:
        return "📍";
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-bold text-white flex items-center gap-2">
        <Heart className="w-5 h-5 text-red-400" />
        Saved Places ({savedPlaces.length})
      </h3>

      {savedPlaces.length === 0 ? (
        <Card className="bg-slate-700/60 p-8 text-center border-slate-600">
          <Heart className="w-10 h-10 text-slate-400 mx-auto mb-3" />
          <p className="text-slate-300">No saved places yet</p>
          <p className="text-slate-400 text-sm mt-1">Save your favorite shelters and safe zones</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {savedPlaces.map((place) => (
            <Card key={place.id} className="bg-slate-700/80 p-4 border-slate-600 hover:bg-slate-700 transition">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-2xl">{getTypeIcon(place.type)}</span>
                    <h4 className="text-white font-semibold">{place.name}</h4>
                  </div>
                  <div className="flex items-center gap-1 text-slate-400 text-sm mb-2">
                    <MapPin className="w-4 h-4" />
                    <span>{place.lat.toFixed(4)}, {place.lng.toFixed(4)}</span>
                  </div>
                  {place.notes && (
                    <p className="text-slate-300 text-sm">{place.notes}</p>
                  )}
                  <p className="text-slate-500 text-xs mt-2">
                    Saved {new Date(place.savedAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-blue-500 text-blue-400 hover:bg-blue-600/20"
                  >
                    <Navigation className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-red-500 text-red-400 hover:bg-red-600/20"
                    onClick={() => removePlace(place.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
