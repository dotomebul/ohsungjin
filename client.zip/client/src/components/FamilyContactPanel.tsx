/**
 * FamilyContactPanel Component
 * 지도에서 가족 위치를 표시하고 관리하는 모달
 */

import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { MapPin, Phone, Clock, AlertCircle, CheckCircle, Navigation, MessageSquare, Plus } from 'lucide-react';
import { FamilyMember } from '@/hooks/useFamilyTracking';
import { toast } from 'sonner';

interface FamilyContactPanelProps {
  isOpen: boolean;
  onClose: () => void;
  familyMembers: FamilyMember[];
  onAddMember?: () => void;
  onRemoveMember?: (memberId: string) => void;
  onGetDirections?: (member: FamilyMember) => void;
  onSendMessage?: (member: FamilyMember) => void;
}

const STATUS_COLORS = {
  safe: { bg: 'bg-green-100', text: 'text-green-700', icon: CheckCircle },
  checking: { bg: 'bg-yellow-100', text: 'text-yellow-700', icon: Clock },
  emergency: { bg: 'bg-red-100', text: 'text-red-700', icon: AlertCircle },
  offline: { bg: 'bg-gray-100', text: 'text-gray-700', icon: AlertCircle },
};

export function FamilyContactPanel({
  isOpen,
  onClose,
  familyMembers,
  onAddMember,
  onRemoveMember,
  onGetDirections,
  onSendMessage,
}: FamilyContactPanelProps) {
  const safeCount = familyMembers.filter((m) => m.status === 'safe').length;
  const emergencyCount = familyMembers.filter((m) => m.status === 'emergency').length;
  const offlineCount = familyMembers.filter((m) => m.status === 'offline').length;

  const handleGetDirections = (member: FamilyMember) => {
    if (!member.location) {
      toast.error('Location not available');
      return;
    }

    if (onGetDirections) {
      onGetDirections(member);
    } else {
      // Default: Open Google Maps
      const url = `https://www.google.com/maps/dir/?api=1&destination=${member.location.lat},${member.location.lng}`;
      window.open(url, '_blank');
    }
  };

  const handleSendMessage = (member: FamilyMember) => {
    if (onSendMessage) {
      onSendMessage(member);
    } else {
      // Default: Open SMS
      const url = `sms:${member.phone}`;
      window.location.href = url;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-blue-500" />
            Family Contacts
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Status Summary */}
          <div className="grid grid-cols-3 gap-2">
            <Card className="p-3 bg-green-50 border-green-200">
              <p className="text-2xl font-bold text-green-600">{safeCount}</p>
              <p className="text-xs text-green-700">Safe</p>
            </Card>
            <Card className="p-3 bg-red-50 border-red-200">
              <p className="text-2xl font-bold text-red-600">{emergencyCount}</p>
              <p className="text-xs text-red-700">Emergency</p>
            </Card>
            <Card className="p-3 bg-gray-50 border-gray-200">
              <p className="text-2xl font-bold text-gray-600">{offlineCount}</p>
              <p className="text-xs text-gray-700">Offline</p>
            </Card>
          </div>

          {/* Family Members List */}
          {familyMembers.length === 0 ? (
            <Card className="p-6 text-center">
              <p className="text-slate-600 mb-3">No family members added yet</p>
              <Button onClick={onAddMember} className="w-full">
                <Plus className="w-4 h-4 mr-2" />
                Add Family Member
              </Button>
            </Card>
          ) : (
            <div className="space-y-2">
              {familyMembers.map((member) => {
                const statusConfig = STATUS_COLORS[member.status];
                const StatusIcon = statusConfig.icon;

                return (
                  <Card key={member.id} className="p-3 border-l-4" style={{ borderLeftColor: member.color }}>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-slate-900">{member.name}</h3>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium flex items-center gap-1 ${statusConfig.bg} ${statusConfig.text}`}>
                            <StatusIcon className="w-3 h-3" />
                            {member.status}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 mt-0.5">{member.relation}</p>
                      </div>
                    </div>

                    {/* Location Info */}
                    {member.location ? (
                      <div className="flex items-center gap-2 text-xs text-slate-600 mb-2">
                        <MapPin className="w-3 h-3" />
                        <span>{member.distance.toFixed(1)} km away</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
                        <AlertCircle className="w-3 h-3" />
                        <span>Location not shared</span>
                      </div>
                    )}

                    {/* Last Update */}
                    <div className="flex items-center gap-2 text-xs text-slate-600 mb-3">
                      <Clock className="w-3 h-3" />
                      <span>Updated {getTimeAgo(member.lastUpdate)}</span>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2">
                      {member.location && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleGetDirections(member)}
                          className="flex-1 text-xs"
                        >
                          <Navigation className="w-3 h-3 mr-1" />
                          Navigate
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleSendMessage(member)}
                        className="flex-1 text-xs"
                      >
                        <MessageSquare className="w-3 h-3 mr-1" />
                        Message
                      </Button>
                      {onRemoveMember && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => onRemoveMember(member.id)}
                          className="text-xs text-red-600 hover:text-red-700"
                        >
                          ✕
                        </Button>
                      )}
                    </div>
                  </Card>
                );
              })}
            </div>
          )}

          {/* Add Member Button */}
          {familyMembers.length > 0 && onAddMember && (
            <Button onClick={onAddMember} variant="outline" className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              Add Another Member
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function getTimeAgo(date: Date): string {
  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);

  if (seconds < 60) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}
