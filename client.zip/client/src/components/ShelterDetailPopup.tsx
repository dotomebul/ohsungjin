/**
 * ShelterDetailPopup Component
 * 지도에서 대피소 마커 클릭 시 표시되는 모달
 */

import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { MapPin, Phone, Globe, Users, Zap, Droplets, AlertCircle, Navigation, Share2 } from 'lucide-react';
import { ShelterData } from '@shared/shelterData';
import { toast } from 'sonner';

interface ShelterDetailPopupProps {
  shelter: ShelterData | null;
  isOpen: boolean;
  onClose: () => void;
  userLocation?: { lat: number; lng: number } | null;
  onGetDirections?: (shelter: ShelterData) => void;
  onShare?: (shelter: ShelterData) => void;
}

export function ShelterDetailPopup({
  shelter,
  isOpen,
  onClose,
  userLocation,
  onGetDirections,
  onShare,
}: ShelterDetailPopupProps) {
  if (!shelter) return null;

  const handleGetDirections = () => {
    if (onGetDirections) {
      onGetDirections(shelter);
    } else {
      // Default: Open Google Maps
      const url = `https://www.google.com/maps/dir/?api=1&destination=${shelter.lat},${shelter.lng}`;
      window.open(url, '_blank');
    }
    onClose();
  };

  const handleShare = () => {
    if (onShare) {
      onShare(shelter);
    } else {
      // Default: Copy shelter info to clipboard
      const text = `${shelter.name}\n${shelter.address}\nCapacity: ${shelter.capacity}\nPhone: ${shelter.phone || 'N/A'}`;
      navigator.clipboard.writeText(text);
      toast.success('Shelter info copied to clipboard');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-blue-500" />
            {shelter.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Address */}
          <Card className="p-3 bg-slate-50">
            <div className="flex gap-2">
              <MapPin className="w-5 h-5 text-slate-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-semibold text-slate-600 uppercase">Address</p>
                <p className="text-sm text-slate-900">{shelter.address}</p>
              </div>
            </div>
          </Card>

          {/* Capacity */}
          <Card className="p-3 bg-slate-50">
            <div className="flex gap-2">
              <Users className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-semibold text-slate-600 uppercase">Capacity</p>
                <p className="text-sm text-slate-900">{shelter.capacity.toLocaleString()} people</p>
              </div>
            </div>
          </Card>

          {/* Type */}
          <Card className="p-3 bg-slate-50">
            <div className="flex gap-2">
              <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-semibold text-slate-600 uppercase">Type</p>
                <p className="text-sm text-slate-900 capitalize">{shelter.type}</p>
              </div>
            </div>
          </Card>

          {/* Contact */}
          {shelter.phone && (
            <Card className="p-3 bg-slate-50">
              <div className="flex gap-2">
                <Phone className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-semibold text-slate-600 uppercase">Phone</p>
                  <a href={`tel:${shelter.phone}`} className="text-sm text-blue-600 hover:underline">
                    {shelter.phone}
                  </a>
                </div>
              </div>
            </Card>
          )}

          {/* Website */}
          {shelter.website && (
            <Card className="p-3 bg-slate-50">
              <div className="flex gap-2">
                <Globe className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-semibold text-slate-600 uppercase">Website</p>
                  <a href={shelter.website} target="_blank" rel="noopener noreferrer" className="text-sm text-purple-600 hover:underline truncate">
                    Visit
                  </a>
                </div>
              </div>
            </Card>
          )}

          {/* Amenities */}
          {shelter.amenities && shelter.amenities.length > 0 && (
            <Card className="p-3 bg-slate-50">
              <p className="text-xs font-semibold text-slate-600 uppercase mb-2">Amenities</p>
              <div className="flex flex-wrap gap-2">
                {shelter.amenities.map((amenity) => (
                  <span key={amenity} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
                    {amenity}
                  </span>
                ))}
              </div>
            </Card>
          )}

          {/* Supplies */}
          {shelter.supplies && shelter.supplies.length > 0 && (
            <Card className="p-3 bg-slate-50">
              <p className="text-xs font-semibold text-slate-600 uppercase mb-2">Supplies</p>
              <div className="space-y-1">
                {shelter.supplies.map((supply) => (
                  <div key={supply.name} className="flex justify-between text-sm">
                    <span className="text-slate-700">{supply.name}</span>
                    <span className="text-slate-600">
                      {supply.quantity} {supply.unit}
                    </span>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Disaster Types */}
          {shelter.disasterTypes && shelter.disasterTypes.length > 0 && (
            <Card className="p-3 bg-slate-50">
              <p className="text-xs font-semibold text-slate-600 uppercase mb-2">For Disasters</p>
              <div className="flex flex-wrap gap-2">
                {shelter.disasterTypes.map((type) => (
                  <span key={type} className="px-2 py-1 bg-red-100 text-red-700 text-xs rounded-full capitalize">
                    {type}
                  </span>
                ))}
              </div>
            </Card>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2 pt-4">
            <Button onClick={handleGetDirections} className="flex-1 bg-blue-600 hover:bg-blue-700">
              <Navigation className="w-4 h-4 mr-2" />
              Get Directions
            </Button>
            <Button onClick={handleShare} variant="outline" className="flex-1">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
