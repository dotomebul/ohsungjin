import { useState } from 'react';
import { ChevronRight, X, MapPin, AlertCircle, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface TutorialStep {
  id: number;
  title: string;
  description: string;
  icon: React.ReactNode;
  target?: string;
}

const TUTORIAL_STEPS: TutorialStep[] = [
  {
    id: 1,
    title: '🗺️ 지도로 대피소 찾기',
    description: '현재 위치 주변의 안전한 대피소를 지도에서 찾을 수 있습니다. 마커를 클릭하면 상세 정보를 볼 수 있어요.',
    icon: <MapPin className="w-8 h-8 text-blue-400" />,
    target: 'map-tab'
  },
  {
    id: 2,
    title: '📰 실시간 재난 뉴스',
    description: '세계 주요 언론사의 재난 관련 속보를 1분 간격으로 업데이트합니다. 최신 정보를 빠르게 확인하세요.',
    icon: <AlertCircle className="w-8 h-8 text-red-400" />,
    target: 'news-tab'
  },
  {
    id: 3,
    title: '👥 가족 안전 확인',
    description: '가족 연락처를 추가하고 "I\'m Safe" 또는 "SOS" 버튼으로 위치와 상태를 공유할 수 있습니다.',
    icon: <Users className="w-8 h-8 text-green-400" />,
    target: 'contacts-tab'
  },
  {
    id: 4,
    title: '⚙️ 설정 및 알림',
    description: '언어, 알림 설정, 피드백 등을 관리할 수 있습니다. 개인정보는 안전하게 보호됩니다.',
    icon: <AlertCircle className="w-8 h-8 text-yellow-400" />,
    target: 'settings-tab'
  }
];

export function OnboardingTutorial() {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  const step = TUTORIAL_STEPS[currentStep];
  const progress = ((currentStep + 1) / TUTORIAL_STEPS.length) * 100;

  const handleNext = () => {
    if (currentStep < TUTORIAL_STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // 튜토리얼 완료 - localStorage에 저장
      localStorage.setItem('tutorial_completed', 'true');
      setIsVisible(false);
    }
  };

  const handleSkip = () => {
    localStorage.setItem('tutorial_completed', 'true');
    setIsVisible(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-2xl shadow-2xl max-w-md w-full animate-in fade-in slide-in-from-bottom-4">
        {/* 헤더 */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-xl font-bold text-card-foreground">
            Evacora 가이드
          </h2>
          <button
            onClick={handleSkip}
            className="p-1 hover:bg-muted rounded-lg transition-colors"
            aria-label="튜토리얼 건너뛰기"
          >
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        {/* 진행 바 */}
        <div className="h-1 bg-muted">
          <div
            className="h-full bg-primary transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* 콘텐츠 */}
        <div className="p-6 space-y-4">
          {/* 아이콘 */}
          <div className="flex justify-center">
            {step.icon}
          </div>

          {/* 제목 */}
          <h3 className="text-lg font-semibold text-card-foreground text-center">
            {step.title}
          </h3>

          {/* 설명 */}
          <p className="text-sm text-muted-foreground text-center leading-relaxed">
            {step.description}
          </p>

          {/* 단계 표시 */}
          <div className="flex justify-center gap-1">
            {TUTORIAL_STEPS.map((_, idx) => (
              <div
                key={idx}
                className={`h-2 w-2 rounded-full transition-colors ${
                  idx <= currentStep ? 'bg-primary' : 'bg-muted'
                }`}
              />
            ))}
          </div>
        </div>

        {/* 버튼 */}
        <div className="flex gap-3 p-6 border-t border-border">
          <Button
            variant="outline"
            onClick={handleSkip}
            className="flex-1"
          >
            건너뛰기
          </Button>
          <Button
            onClick={handleNext}
            className="flex-1 flex items-center justify-center gap-2"
          >
            {currentStep === TUTORIAL_STEPS.length - 1 ? '완료' : '다음'}
            {currentStep < TUTORIAL_STEPS.length - 1 && (
              <ChevronRight className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
