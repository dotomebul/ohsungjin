/**
 * Quick Safety Share Component
 * Allows users to quickly share their safety status (Safe/Emergency/Moving) with family
 */

import { useState } from 'react';
import { AlertCircle, CheckCircle, Navigation, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { useI18n } from '@/contexts/I18nContext';

interface QuickSafetyShareProps {
  isOpen: boolean;
  onClose: () => void;
  disasterType?: string;
}

type SafetyStatus = 'safe' | 'emergency' | 'moving';

export function QuickSafetyShare({ isOpen, onClose, disasterType = 'earthquake' }: QuickSafetyShareProps) {
  const { t } = useI18n();
  const [selectedStatus, setSelectedStatus] = useState<SafetyStatus>('safe');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const statusOptions: Array<{ status: SafetyStatus; icon: React.ReactNode; label: string; color: string; description: string }> = [
    {
      status: 'safe',
      icon: <CheckCircle className="w-8 h-8" />,
      label: t('family.safe') || 'Safe',
      color: 'bg-green-100 border-green-300 text-green-700 hover:bg-green-200',
      description: t('family.safeDesc') || 'I am safe and secure',
    },
    {
      status: 'emergency',
      icon: <AlertCircle className="w-8 h-8" />,
      label: t('family.emergency') || 'Emergency',
      color: 'bg-red-100 border-red-300 text-red-700 hover:bg-red-200',
      description: t('family.emergencyDesc') || 'I need help immediately',
    },
    {
      status: 'moving',
      icon: <Navigation className="w-8 h-8" />,
      label: t('family.moving') || 'Moving',
      color: 'bg-amber-100 border-amber-300 text-amber-700 hover:bg-amber-200',
      description: t('family.movingDesc') || 'I am evacuating/moving to safety',
    },
  ];

  const handleShare = async () => {
    setIsSubmitting(true);
    try {
      // Get current location
      const location = await new Promise<{ lat: number; lng: number }>((resolve) => {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            resolve({
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
            });
          },
          () => {
            // If location fails, use default
            resolve({ lat: 0, lng: 0 });
          }
        );
      });

      // Prepare message based on status
      const statusMessages: Record<SafetyStatus, string> = {
        safe: `✅ ${t('family.safe')} - I am safe and secure during ${disasterType}. Location: ${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`,
        emergency: `🚨 ${t('family.emergency')} - I need help immediately during ${disasterType}. Location: ${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`,
        moving: `🚗 ${t('family.moving')} - I am evacuating to safety during ${disasterType}. Location: ${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`,
      };

      // Try to send via SMS if available
      try {
        // Get family members from localStorage (simplified for now)
        const familyData = localStorage.getItem('evacora_family_members');
        if (familyData) {
          const family = JSON.parse(familyData);
          const phoneNumbers = family.map((m: any) => m.phone).filter((p: any) => p);

          if (phoneNumbers.length > 0) {
            // In a real app, this would call a backend API to send SMS
            // For now, we'll just show a toast
            toast.success(
              `Safety status "${selectedStatus}" shared with ${phoneNumbers.length} family member(s)`,
              {
                description: statusMessages[selectedStatus],
              }
            );
          }
        }
      } catch (error) {
        console.error('Error sharing status:', error);
      }

      onClose();
    } catch (error) {
      console.error('Error in handleShare:', error);
      toast.error('Failed to share safety status');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="w-5 h-5" />
            {t('family.quickShare') || 'Quick Safety Share'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Status Selection */}
          <div className="space-y-3">
            <p className="text-sm font-semibold text-slate-700">
              {t('family.selectStatus') || 'Select your current status:'}
            </p>
            <div className="grid grid-cols-1 gap-2">
              {statusOptions.map((option) => (
                <button
                  key={option.status}
                  onClick={() => setSelectedStatus(option.status)}
                  className={`p-4 rounded-lg border-2 transition-all text-left ${
                    selectedStatus === option.status
                      ? option.color
                      : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1">{option.icon}</div>
                    <div>
                      <p className="font-semibold">{option.label}</p>
                      <p className="text-sm opacity-75">{option.description}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Info Message */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <p className="text-sm text-blue-700">
              {t('family.shareInfo') || 'Your location and status will be shared with your family members via SMS.'}
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1"
              disabled={isSubmitting}
            >
              {t('common.cancel') || 'Cancel'}
            </Button>
            <Button
              onClick={handleShare}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <span className="animate-spin">⏳</span>
                  {t('common.sending') || 'Sending...'}
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Send className="w-4 h-4" />
                  {t('common.share') || 'Share Status'}
                </span>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
