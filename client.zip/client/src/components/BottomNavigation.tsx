/**
 * Bottom Navigation Component
 * Mobile-friendly bottom navigation bar
 */

import { useLocation } from 'wouter';
import { Home, Map, BookOpen, Users, Settings, Newspaper } from 'lucide-react';
import { useI18n } from '@/contexts/I18nContext';

interface NavItem {
  path: string;
  label: string;
  icon: React.ReactNode;
}

export function BottomNavigation() {
  const [location, navigate] = useLocation();
  const { t } = useI18n();

  const navItems: NavItem[] = [
    { path: '/home', label: t('common.home') || 'Home', icon: <Home className="w-6 h-6" /> },
    { path: '/map', label: t('common.map') || 'Map', icon: <Map className="w-6 h-6" /> },
    { path: '/guides', label: t('common.guides') || 'Guides', icon: <BookOpen className="w-6 h-6" /> },
    { path: '/news', label: 'News', icon: <Newspaper className="w-6 h-6" /> },
    { path: '/contacts', label: t('common.contacts') || 'Contacts', icon: <Users className="w-6 h-6" /> },
    { path: '/settings', label: t('common.settings') || 'Settings', icon: <Settings className="w-6 h-6" /> },
  ];

  const isActive = (path: string) => location === path;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 shadow-lg">
      <div className="max-w-4xl mx-auto px-2 py-2">
        <div className="grid grid-cols-6 gap-1">
          {navItems.map((item) => (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center justify-center py-3 px-2 rounded-lg transition-all duration-200 ${
                isActive(item.path)
                  ? 'bg-blue-100 text-blue-600'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
              title={item.label}
            >
              {item.icon}
              <span className="text-xs font-semibold mt-1 text-center line-clamp-1">{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
