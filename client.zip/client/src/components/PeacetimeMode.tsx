/**
 * Peacetime Mode - Home screen when no active disasters
 * Focus: Family safety network, emergency contacts, safe places, preparedness
 */

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Users, Phone, MapPin, CheckCircle2, Plus, Edit2, Trash2, Heart, AlertCircle } from "lucide-react";
import { toast } from "sonner";

interface FamilyMember {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  lastCheckin?: Date;
  status: "safe" | "unknown" | "unreachable";
}

interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  priority: 1 | 2 | 3;
}

interface SafePlace {
  id: string;
  name: string;
  address: string;
  type: "home" | "work" | "school" | "shelter" | "other";
  distance?: string;
  isFavorite: boolean;
}

export function PeacetimeMode() {
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([
    { id: "1", name: "Mom", relationship: "Mother", phone: "+1-555-0101", status: "safe", lastCheckin: new Date() },
    { id: "2", name: "Dad", relationship: "Father", phone: "+1-555-0102", status: "safe", lastCheckin: new Date() },
  ]);

  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>([
    { id: "1", name: "Local Hospital", phone: "911", priority: 1 },
    { id: "2", name: "Red Cross", phone: "1-800-733-2767", priority: 2 },
  ]);

  const [safeePlaces, setSafeePlaces] = useState<SafePlace[]>([
    { id: "1", name: "Home", address: "123 Main St", type: "home", distance: "0 km", isFavorite: true },
    { id: "2", name: "Workplace", address: "456 Office Blvd", type: "work", distance: "5 km", isFavorite: false },
    { id: "3", name: "Nearest Shelter", address: "789 Safety Ave", type: "shelter", distance: "2 km", isFavorite: true },
  ]);

  const [newFamilyName, setNewFamilyName] = useState("");
  const [newFamilyPhone, setNewFamilyPhone] = useState("");

  const handleAddFamilyMember = () => {
    if (!newFamilyName.trim() || !newFamilyPhone.trim()) {
      toast.error("Please fill in all fields");
      return;
    }

    const newMember: FamilyMember = {
      id: Date.now().toString(),
      name: newFamilyName,
      relationship: "Family",
      phone: newFamilyPhone,
      status: "unknown",
    };

    setFamilyMembers([...familyMembers, newMember]);
    setNewFamilyName("");
    setNewFamilyPhone("");
    toast.success(`${newFamilyName} added to family network!`);
  };

  const handleRemoveFamilyMember = (id: string) => {
    setFamilyMembers(familyMembers.filter((m) => m.id !== id));
    toast.success("Family member removed");
  };

  const handleToggleFavoriteSafePlace = (id: string) => {
    setSafeePlaces(
      safeePlaces.map((place) =>
        place.id === id ? { ...place, isFavorite: !place.isFavorite } : place
      )
    );
  };

  const preparednessScore = Math.round(
    ((familyMembers.length / 5) * 20 +
      (emergencyContacts.length / 3) * 20 +
      (safeePlaces.filter((p) => p.isFavorite).length / 3) * 20 +
      40) // Base 40 points for having the app
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Evacora</h1>
          <p className="text-lg text-slate-600">
            Prepare every day. Act fast in emergencies.
          </p>
        </div>

        {/* Today's Safety Status */}
        <Card className="border-l-4 border-l-green-500 bg-green-50">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
                <CardTitle>Today's Safety Status</CardTitle>
              </div>
              <span className="text-sm font-semibold text-green-700">All Safe</span>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-slate-700">
              All family members are accounted for. No active alerts in your region.
            </p>
          </CardContent>
        </Card>

        {/* Preparedness Score */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-blue-600" />
              Preparedness Score
            </CardTitle>
            <CardDescription>How ready are you for emergencies?</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <div className="w-full bg-slate-200 rounded-full h-3">
                  <div
                    className="bg-blue-600 h-3 rounded-full transition-all"
                    style={{ width: `${preparednessScore}%` }}
                  />
                </div>
              </div>
              <div className="text-3xl font-bold text-blue-600">{preparednessScore}%</div>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-xs text-slate-600">
              <div>✓ Family: {familyMembers.length}/5</div>
              <div>✓ Contacts: {emergencyContacts.length}/3</div>
              <div>✓ Places: {safeePlaces.filter((p) => p.isFavorite).length}/3</div>
            </div>
          </CardContent>
        </Card>

        {/* Family Safety Network */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-600" />
                <div>
                  <CardTitle>Family Safety Network</CardTitle>
                  <CardDescription>Stay connected with loved ones</CardDescription>
                </div>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm" variant="outline">
                    <Plus className="w-4 h-4 mr-1" />
                    Add Member
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Family Member</DialogTitle>
                    <DialogDescription>Add a loved one to your safety network</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="family-name">Name</Label>
                      <Input
                        id="family-name"
                        placeholder="e.g., Mom"
                        value={newFamilyName}
                        onChange={(e) => setNewFamilyName(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="family-phone">Phone Number</Label>
                      <Input
                        id="family-phone"
                        placeholder="+1-555-0000"
                        value={newFamilyPhone}
                        onChange={(e) => setNewFamilyPhone(e.target.value)}
                      />
                    </div>
                    <Button onClick={handleAddFamilyMember} className="w-full">
                      Add to Network
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {familyMembers.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border"
                >
                  <div>
                    <p className="font-medium text-slate-900">{member.name}</p>
                    <p className="text-sm text-slate-600">{member.phone}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold px-2 py-1 rounded-full bg-green-100 text-green-700">
                      {member.status === "safe" ? "✓ Safe" : "? Unknown"}
                    </span>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleRemoveFamilyMember(member.id)}
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Emergency Contacts */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Phone className="w-5 h-5 text-red-600" />
              <div>
                <CardTitle>Emergency Contacts</CardTitle>
                <CardDescription>Priority-ordered contact list</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {emergencyContacts.sort((a, b) => a.priority - b.priority).map((contact) => (
                <div
                  key={contact.id}
                  className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border"
                >
                  <div>
                    <p className="font-medium text-slate-900">{contact.name}</p>
                    <p className="text-sm text-slate-600">{contact.phone}</p>
                  </div>
                  <span className="text-xs font-bold px-2 py-1 rounded-full bg-red-100 text-red-700">
                    Priority {contact.priority}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Safe Places */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-blue-600" />
              <div>
                <CardTitle>Safe Places</CardTitle>
                <CardDescription>Nearby shelters and safe locations</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {safeePlaces.map((place) => (
                <div
                  key={place.id}
                  className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border hover:bg-slate-100 transition-colors"
                >
                  <div>
                    <p className="font-medium text-slate-900">{place.name}</p>
                    <p className="text-sm text-slate-600">{place.address}</p>
                    {place.distance && (
                      <p className="text-xs text-slate-500 mt-1">📍 {place.distance} away</p>
                    )}
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleToggleFavoriteSafePlace(place.id)}
                  >
                    <Heart
                      className={`w-5 h-5 ${
                        place.isFavorite ? "fill-red-500 text-red-500" : "text-slate-400"
                      }`}
                    />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Monthly Safety Drill */}
        <Card className="border-l-4 border-l-amber-500 bg-amber-50">
          <CardHeader>
            <CardTitle className="text-amber-900">Monthly Safety Drill</CardTitle>
            <CardDescription className="text-amber-800">
              Last completed: 2 weeks ago
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="w-full bg-amber-600 hover:bg-amber-700">
              Start Monthly Check-in
            </Button>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-sm text-slate-600 py-4">
          <p>Evacuora helps you prepare and respond to emergencies with your family.</p>
          <p className="mt-2">🔔 Alerts disabled • 📍 Location sharing off</p>
        </div>
      </div>
    </div>
  );
}
