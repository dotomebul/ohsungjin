import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface Shelter {
  id: number;
  name: string;
  country: string;
  city: string;
  type: string;
  lat: number;
  lng: number;
  capacity: number;
  currentOccupancy: number;
  depth?: number;
  phoneNumber?: string;
  amenities?: Record<string, boolean>;
}

interface ShelterMapProps {
  shelters: Shelter[];
  userLat?: number;
  userLng?: number;
  selectedCountries?: string[];
}

// Custom marker icons by shelter type
const getShelterIcon = (type: string) => {
  const colors: Record<string, string> = {
    metro: '#3B82F6',      // Blue
    bunker: '#8B5CF6',     // Purple
    basement: '#F59E0B',   // Amber
    cave: '#10B981',       // Green
    other: '#6B7280',      // Gray
  };

  return L.divIcon({
    html: `
      <div style="
        background-color: ${colors[type] || '#6B7280'};
        color: white;
        border-radius: 50%;
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 14px;
        border: 2px solid white;
        box-shadow: 0 2px 4px rgba(0,0,0,0.3);
      ">
        ${type === 'metro' ? '🚇' : type === 'bunker' ? '🏚️' : type === 'basement' ? '🏢' : type === 'cave' ? '🏔️' : '📍'}
      </div>
    `,
    iconSize: [32, 32],
    iconAnchor: [16, 16],
    popupAnchor: [0, -16],
  });
};

// Occupancy percentage color
const getOccupancyColor = (occupancy: number, capacity: number) => {
  const percentage = (occupancy / capacity) * 100;
  if (percentage < 30) return '#10B981'; // Green
  if (percentage < 60) return '#F59E0B'; // Amber
  if (percentage < 90) return '#EF4444'; // Red
  return '#7F1D1D'; // Dark Red
};

export default function ShelterMap({ shelters, userLat, userLng, selectedCountries = [] }: ShelterMapProps) {
  const [filteredShelters, setFilteredShelters] = useState<Shelter[]>(shelters);
  const [center, setCenter] = useState<[number, number]>([52.1295, 21.0122]); // Warsaw center

  useEffect(() => {
    // Filter shelters by selected countries
    if (selectedCountries.length > 0) {
      setFilteredShelters(shelters.filter(s => selectedCountries.includes(s.country)));
    } else {
      setFilteredShelters(shelters);
    }

    // Set map center to user location if available
    if (userLat && userLng) {
      setCenter([userLat, userLng]);
    }
  }, [shelters, selectedCountries, userLat, userLng]);

  return (
    <div className="w-full h-96 rounded-lg overflow-hidden border border-gray-300">
      <MapContainer center={center} zoom={6} style={{ width: '100%', height: '100%' }}>
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />

        {/* User location marker */}
        {userLat && userLng && (
          <Marker position={[userLat, userLng]} icon={L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
          })}>
            <Popup>
              <div className="text-sm">
                <p className="font-bold">📍 Your Location</p>
                <p className="text-xs text-gray-600">Lat: {userLat.toFixed(4)}, Lng: {userLng.toFixed(4)}</p>
              </div>
            </Popup>
          </Marker>
        )}

        {/* Shelter markers */}
        {filteredShelters.map((shelter) => (
          <Marker
            key={shelter.id}
            position={[shelter.lat, shelter.lng]}
            icon={getShelterIcon(shelter.type)}
          >
            <Popup>
              <div className="text-sm w-64">
                <p className="font-bold text-lg">{shelter.name}</p>
                <p className="text-xs text-gray-600">{shelter.city}, {shelter.country.toUpperCase()}</p>
                
                <div className="mt-2 space-y-1">
                  <p className="text-xs"><strong>Type:</strong> {shelter.type}</p>
                  <p className="text-xs"><strong>Capacity:</strong> {shelter.capacity.toLocaleString()} people</p>
                  <p className="text-xs"><strong>Current:</strong> {shelter.currentOccupancy.toLocaleString()} people</p>
                  
                  {/* Occupancy bar */}
                  <div className="mt-1">
                    <div className="text-xs font-semibold mb-1">Occupancy</div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="h-2 rounded-full transition-all"
                        style={{
                          width: `${Math.min((shelter.currentOccupancy / shelter.capacity) * 100, 100)}%`,
                          backgroundColor: getOccupancyColor(shelter.currentOccupancy, shelter.capacity),
                        }}
                      />
                    </div>
                    <p className="text-xs text-gray-600 mt-1">
                      {((shelter.currentOccupancy / shelter.capacity) * 100).toFixed(1)}% full
                    </p>
                  </div>

                  {shelter.depth && (
                    <p className="text-xs"><strong>Depth:</strong> {shelter.depth}m</p>
                  )}

                  {/* Amenities */}
                  {shelter.amenities && (
                    <div className="mt-2">
                      <p className="text-xs font-semibold mb-1">Amenities:</p>
                      <div className="text-xs space-y-1">
                        {shelter.amenities.hasToilets && <p>✓ Toilets</p>}
                        {shelter.amenities.hasWater && <p>✓ Water</p>}
                        {shelter.amenities.hasEmergencyRoom && <p>✓ Medical Room</p>}
                        {shelter.amenities.hasBedding && <p>✓ Bedding</p>}
                        {shelter.amenities.hasFood && <p>✓ Food</p>}
                        {shelter.amenities.hasGenerator && <p>✓ Generator</p>}
                        {shelter.amenities.hasCommunication && <p>✓ Communication</p>}
                      </div>
                    </div>
                  )}

                  {shelter.phoneNumber && (
                    <p className="text-xs mt-2"><strong>Phone:</strong> {shelter.phoneNumber}</p>
                  )}
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* Legend */}
      <div className="absolute bottom-4 left-4 bg-white p-3 rounded-lg shadow-lg text-xs z-10">
        <p className="font-bold mb-2">Shelter Types</p>
        <div className="space-y-1">
          <p>🚇 Metro</p>
          <p>🏚️ Bunker</p>
          <p>🏢 Basement</p>
          <p>🏔️ Cave</p>
        </div>
      </div>
    </div>
  );
}
