import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Users, Clock, Navigation2, Share2, Copy, Check } from "lucide-react";
import { toast } from "sonner";

/**
 * 만남 지점 공유 컴포넌트
 * - 가족 만남 지점 설정
 * - 실시간 거리 계산
 * - 공유 링크 생성
 * - 예상 도착 시간 표시
 */

interface MeetingPoint {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  createdBy: string;
  createdAt: Date;
  description?: string;
}

interface FamilyMember {
  id: number;
  nickname: string;
  latitude: number;
  longitude: number;
  distance: number; // km
  eta: number; // 분
  speed: number; // km/h
}

interface MeetingPointSharingProps {
  currentLocation: { latitude: number; longitude: number };
  familyMembers: FamilyMember[];
  onSetMeetingPoint: (point: MeetingPoint) => void;
  onShareMeetingPoint: (point: MeetingPoint) => void;
}

export function MeetingPointSharing({
  currentLocation,
  familyMembers,
  onSetMeetingPoint,
  onShareMeetingPoint,
}: MeetingPointSharingProps) {
  const [meetingPoints, setMeetingPoints] = useState<MeetingPoint[]>([]);
  const [selectedPoint, setSelectedPoint] = useState<MeetingPoint | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [pointName, setPointName] = useState("");
  const [pointDescription, setPointDescription] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // 만남 지점 생성
  const createMeetingPoint = useCallback(() => {
    if (!pointName.trim()) {
      toast.error("만남 지점 이름을 입력하세요");
      return;
    }

    const newPoint: MeetingPoint = {
      id: `point_${Date.now()}`,
      name: pointName,
      latitude: currentLocation.latitude,
      longitude: currentLocation.longitude,
      createdBy: "Me",
      createdAt: new Date(),
      description: pointDescription,
    };

    setMeetingPoints((prev) => [...prev, newPoint]);
    onSetMeetingPoint(newPoint);
    setSelectedPoint(newPoint);
    setPointName("");
    setPointDescription("");
    setShowForm(false);
    toast.success("만남 지점이 설정되었습니다");
  }, [currentLocation, pointName, pointDescription, onSetMeetingPoint]);

  // 거리 계산 (Haversine)
  const calculateDistance = (
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
  ): number => {
    const R = 6371; // 지구 반경 (km)
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // 예상 도착 시간 계산
  const calculateETA = (distance: number, speed: number): number => {
    if (speed === 0) return 0;
    return Math.ceil((distance / speed) * 60); // 분 단위
  };

  // 공유 링크 복사
  const copyShareLink = useCallback(
    (point: MeetingPoint) => {
      const shareUrl = `${window.location.origin}?meetingPoint=${point.id}&lat=${point.latitude}&lon=${point.longitude}`;
      navigator.clipboard.writeText(shareUrl);
      setCopiedId(point.id);
      toast.success("공유 링크가 복사되었습니다");
      setTimeout(() => setCopiedId(null), 2000);
    },
    []
  );

  // 만남 지점 공유
  const shareMeetingPoint = useCallback(
    (point: MeetingPoint) => {
      onShareMeetingPoint(point);
      toast.success("만남 지점이 가족에게 공유되었습니다");
    },
    [onShareMeetingPoint]
  );

  return (
    <div className="space-y-4">
      {/* 만남 지점 설정 */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <MapPin className="w-5 h-5 text-blue-400" />
            만남 지점 설정
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {!showForm ? (
            <Button
              onClick={() => setShowForm(true)}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              <MapPin className="w-4 h-4 mr-2" />
              현재 위치를 만남 지점으로 설정
            </Button>
          ) : (
            <div className="space-y-3">
              <input
                type="text"
                placeholder="만남 지점 이름 (예: 지하철역, 공원)"
                value={pointName}
                onChange={(e) => setPointName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-600 rounded text-white placeholder-slate-400"
              />
              <textarea
                placeholder="설명 (선택사항)"
                value={pointDescription}
                onChange={(e) => setPointDescription(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-600 rounded text-white placeholder-slate-400 h-20 resize-none"
              />
              <div className="flex gap-2">
                <Button
                  onClick={createMeetingPoint}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                >
                  <Check className="w-4 h-4 mr-2" />
                  설정
                </Button>
                <Button
                  onClick={() => setShowForm(false)}
                  variant="outline"
                  className="flex-1"
                >
                  취소
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 활성 만남 지점 */}
      {selectedPoint && (
        <Card className="bg-slate-900 border-blue-600 border-2">
          <CardHeader>
            <CardTitle className="text-blue-400 flex items-center gap-2">
              <Navigation2 className="w-5 h-5" />
              활성 만남 지점
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-white font-semibold">{selectedPoint.name}</p>
              {selectedPoint.description && (
                <p className="text-slate-400 text-sm">{selectedPoint.description}</p>
              )}
              <p className="text-slate-500 text-xs mt-1">
                {selectedPoint.latitude.toFixed(4)}, {selectedPoint.longitude.toFixed(4)}
              </p>
            </div>

            <Button
              onClick={() => shareMeetingPoint(selectedPoint)}
              className="w-full bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Share2 className="w-4 h-4 mr-2" />
              가족에게 공유
            </Button>

            <Button
              onClick={() => copyShareLink(selectedPoint)}
              variant="outline"
              className="w-full"
            >
              {copiedId === selectedPoint.id ? (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  복사됨
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  링크 복사
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* 가족 구성원별 거리 및 ETA */}
      {selectedPoint && familyMembers.length > 0 && (
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-green-400" />
              가족 도착 예상 시간
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {familyMembers.map((member) => {
              const distance = calculateDistance(
                member.latitude,
                member.longitude,
                selectedPoint.latitude,
                selectedPoint.longitude
              );
              const eta = calculateETA(distance, member.speed);

              return (
                <div
                  key={member.id}
                  className="flex items-center justify-between p-3 bg-slate-800 rounded border border-slate-700"
                >
                  <div>
                    <p className="text-white font-medium">{member.nickname}</p>
                    <p className="text-slate-400 text-sm">
                      {distance.toFixed(1)}km • {member.speed.toFixed(0)} km/h
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-blue-400">
                      <Clock className="w-4 h-4" />
                      <span className="font-semibold">{eta}분</span>
                    </div>
                    <p className="text-slate-500 text-xs">
                      {new Date(Date.now() + eta * 60000).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* 이전 만남 지점 목록 */}
      {meetingPoints.length > 1 && (
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white text-sm">이전 만남 지점</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {meetingPoints
              .filter((p) => p.id !== selectedPoint?.id)
              .map((point) => (
                <button
                  key={point.id}
                  onClick={() => setSelectedPoint(point)}
                  className="w-full text-left p-2 bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 hover:border-slate-600 transition"
                >
                  <p className="text-white text-sm font-medium">{point.name}</p>
                  <p className="text-slate-500 text-xs">
                    {point.createdAt.toLocaleTimeString()}
                  </p>
                </button>
              ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
