import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Language, Region, getTranslations, Translations } from '@shared/i18n/translations';

interface I18nContextType {
  language: Language;
  region: Region;
  translations: Translations;
  isOnboardingCompleted: boolean;
  setLanguage: (lang: Language) => void;
  setRegion: (region: Region) => void;
  completeOnboarding: () => void;
  t: (key: string) => string;
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('evacora_language');
    return (saved as Language) || 'en';
  });

  const [region, setRegionState] = useState<Region>(() => {
    const saved = localStorage.getItem('evacora_region');
    return (saved as Region) || 'us';
  });

  const [isOnboardingCompleted, setIsOnboardingCompleted] = useState<boolean>(() => {
    return localStorage.getItem('evacora_onboarding_completed') === 'true';
  });

  const translations = getTranslations(language);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('evacora_language', lang);
  }, []);

  const setRegion = useCallback((reg: Region) => {
    setRegionState(reg);
    localStorage.setItem('evacora_region', reg);
  }, []);

  const completeOnboarding = useCallback(() => {
    setIsOnboardingCompleted(true);
    localStorage.setItem('evacora_onboarding_completed', 'true');
  }, []);

  const t = useCallback((key: string): string => {
    const keys = key.split('.');
    let value: any = translations;

    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        return key;
      }
    }

    return typeof value === 'string' ? value : key;
  }, [translations]);

  return (
    <I18nContext.Provider
      value={{
        language,
        region,
        translations,
        isOnboardingCompleted,
        setLanguage,
        setRegion,
        completeOnboarding,
        t,
      }}
    >
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n(): I18nContextType {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within I18nProvider');
  }
  return context;
}
