/**
 * 마커 클러스터링 유틸리티
 * 지도에 많은 마커가 있을 때 성능 최적화를 위해 근처 마커들을 클러스터로 그룹화
 */

export interface Marker {
  id: string;
  lat: number;
  lng: number;
  title: string;
  [key: string]: any;
}

export interface Cluster {
  id: string;
  lat: number;
  lng: number;
  markers: Marker[];
  count: number;
}

/**
 * 두 좌표 사이의 거리를 계산 (km)
 * Haversine 공식 사용
 */
function getDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371; // 지구 반지름 (km)
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * 마커들을 클러스터로 그룹화
 * @param markers 마커 배열
 * @param clusterRadius 클러스터 반지름 (km)
 * @returns 클러스터 배열
 */
export function clusterMarkers(markers: Marker[], clusterRadius: number = 2): Cluster[] {
  if (markers.length === 0) return [];

  const clusters: Cluster[] = [];
  const processed = new Set<string>();

  for (const marker of markers) {
    if (processed.has(marker.id)) continue;

    // 새 클러스터 생성
    const cluster: Cluster = {
      id: `cluster-${marker.id}`,
      lat: marker.lat,
      lng: marker.lng,
      markers: [marker],
      count: 1
    };

    processed.add(marker.id);

    // 근처 마커 찾기
    for (const otherMarker of markers) {
      if (processed.has(otherMarker.id)) continue;

      const distance = getDistance(
        marker.lat,
        marker.lng,
        otherMarker.lat,
        otherMarker.lng
      );

      if (distance <= clusterRadius) {
        cluster.markers.push(otherMarker);
        cluster.count++;
        processed.add(otherMarker.id);

        // 클러스터 중심 업데이트 (평균값)
        const totalLat = cluster.markers.reduce((sum, m) => sum + m.lat, 0);
        const totalLng = cluster.markers.reduce((sum, m) => sum + m.lng, 0);
        cluster.lat = totalLat / cluster.markers.length;
        cluster.lng = totalLng / cluster.markers.length;
      }
    }

    clusters.push(cluster);
  }

  return clusters;
}

/**
 * 줌 레벨에 따라 클러스터 반지름 동적 조정
 * @param zoomLevel 줌 레벨 (0-20)
 * @returns 클러스터 반지름 (km)
 */
export function getClusterRadiusByZoom(zoomLevel: number): number {
  // 줌 레벨이 낮을수록 (멀리 볼수록) 클러스터 반지름이 커야 함
  if (zoomLevel < 5) return 50;
  if (zoomLevel < 8) return 20;
  if (zoomLevel < 11) return 10;
  if (zoomLevel < 14) return 5;
  if (zoomLevel < 17) return 2;
  return 0.5; // 줌 레벨이 높으면 클러스터링 거의 안 함
}

/**
 * 클러스터 색상 결정
 * @param count 클러스터의 마커 개수
 * @returns 색상 코드
 */
export function getClusterColor(count: number): string {
  if (count === 1) return '#3b82f6'; // 파란색 (단일 마커)
  if (count < 5) return '#10b981'; // 초록색 (적음)
  if (count < 10) return '#f59e0b'; // 주황색 (중간)
  if (count < 20) return '#ef4444'; // 빨강 (많음)
  return '#7c3aed'; // 보라색 (매우 많음)
}

/**
 * 클러스터 크기 결정
 * @param count 클러스터의 마커 개수
 * @returns 마커 크기 (픽셀)
 */
export function getClusterSize(count: number): number {
  if (count === 1) return 26;
  if (count < 5) return 32;
  if (count < 10) return 40;
  if (count < 20) return 48;
  return 56;
}
