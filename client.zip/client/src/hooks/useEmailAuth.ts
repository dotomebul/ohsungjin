import { trpc } from "@/lib/trpc";

/**
 * Hook for managing Evacora email-based authentication state.
 * Returns the current email user (independent of Manus OAuth).
 */
export function useEmailAuth() {
  const { data: emailUser, isLoading, refetch } = trpc.emailAuth.me.useQuery(undefined, {
    retry: false,
    staleTime: 60_000,
  });

  return {
    emailUser: emailUser ?? null,
    isEmailAuthenticated: !!emailUser,
    isLoading,
    refetch,
  };
}
