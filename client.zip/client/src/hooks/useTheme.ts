import { useEffect, useState } from 'react';

export type Theme = 'light' | 'dark' | 'system';

interface UseThemeReturn {
  theme: Theme;
  systemTheme: 'light' | 'dark';
  effectiveTheme: 'light' | 'dark';
  setTheme: (theme: Theme) => void;
}

/**
 * 테마 관리 훅
 * - light: 라이트 테마
 * - dark: 다크 테마
 * - system: 시스템 설정 따르기
 * 
 * localStorage에 사용자 선택 저장
 */
export function useTheme(): UseThemeReturn {
  const [theme, setThemeState] = useState<Theme>('dark');
  const [systemTheme, setSystemTheme] = useState<'light' | 'dark'>('dark');

  // 초기화: localStorage에서 테마 로드
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme-preference') as Theme | null;
    if (savedTheme) {
      setThemeState(savedTheme);
    }

    // 시스템 테마 감지
    const mediaQuery = window.matchMedia('(prefers-color-scheme: light)');
    const updateSystemTheme = (e: MediaQueryListEvent | MediaQueryList) => {
      setSystemTheme(e.matches ? 'light' : 'dark');
    };

    updateSystemTheme(mediaQuery);
    mediaQuery.addEventListener('change', updateSystemTheme);

    return () => mediaQuery.removeEventListener('change', updateSystemTheme);
  }, []);

  // 테마 변경
  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);
    localStorage.setItem('theme-preference', newTheme);
    applyTheme(newTheme, systemTheme);
  };

  // 실제 테마 적용
  useEffect(() => {
    applyTheme(theme, systemTheme);
  }, [theme, systemTheme]);

  const effectiveTheme = theme === 'system' ? systemTheme : theme;

  return {
    theme,
    systemTheme,
    effectiveTheme,
    setTheme,
  };
}

/**
 * DOM에 테마 적용
 */
function applyTheme(theme: Theme, systemTheme: 'light' | 'dark') {
  const effectiveTheme = theme === 'system' ? systemTheme : theme;
  const html = document.documentElement;

  if (effectiveTheme === 'light') {
    html.classList.remove('dark');
    html.classList.add('light');
  } else {
    html.classList.remove('light');
    html.classList.add('dark');
  }

  // CSS 변수도 업데이트
  if (effectiveTheme === 'light') {
    html.style.colorScheme = 'light';
  } else {
    html.style.colorScheme = 'dark';
  }
}
