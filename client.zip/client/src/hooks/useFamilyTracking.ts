/**
 * useFamilyTracking Hook
 * 가족 위치 추적 및 실시간 위치 공유 기능 제공
 */

import { useState, useEffect, useRef, useCallback } from 'react';

export interface FamilyMember {
  id: string;
  name: string;
  relation: string;
  location: { lat: number; lng: number } | null;
  status: 'safe' | 'checking' | 'emergency' | 'offline';
  lastUpdate: Date;
  distance: number;
  phone: string;
  color: string;
}

const MEMBER_COLORS = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#14B8A6', '#F97316'];

export function useFamilyTracking(userLocation?: { lat: number; lng: number } | null) {
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>(() => {
    try {
      const saved = localStorage.getItem('evacora_family_members');
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.map((m: any) => ({ ...m, lastUpdate: new Date(m.lastUpdate) }));
      }
    } catch {}
    return [];
  });

  const [isSharingEnabled, setIsSharingEnabled] = useState(() => {
    return localStorage.getItem('evacora_location_sharing') === 'true';
  });

  const [updateInterval, setUpdateInterval] = useState(() => {
    return parseInt(localStorage.getItem('evacora_update_interval') || '30');
  });

  const watchIdRef = useRef<number | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Save family members to localStorage
  const saveFamilyMembers = useCallback((members: FamilyMember[]) => {
    localStorage.setItem('evacora_family_members', JSON.stringify(members));
    setFamilyMembers(members);
  }, []);

  // Add family member
  const addFamilyMember = useCallback((name: string, relation: string, phone: string) => {
    const newMember: FamilyMember = {
      id: `member-${Date.now()}`,
      name,
      relation,
      phone,
      location: null,
      status: 'offline',
      lastUpdate: new Date(),
      distance: 0,
      color: MEMBER_COLORS[familyMembers.length % MEMBER_COLORS.length],
    };
    saveFamilyMembers([...familyMembers, newMember]);
    return newMember;
  }, [familyMembers, saveFamilyMembers]);

  // Remove family member
  const removeFamilyMember = useCallback((memberId: string) => {
    saveFamilyMembers(familyMembers.filter((m) => m.id !== memberId));
  }, [familyMembers, saveFamilyMembers]);

  // Update family member location
  const updateMemberLocation = useCallback((memberId: string, location: { lat: number; lng: number }, status: 'safe' | 'checking' | 'emergency' | 'offline' = 'safe') => {
    setFamilyMembers((prev) =>
      prev.map((m) =>
        m.id === memberId
          ? {
              ...m,
              location,
              status,
              lastUpdate: new Date(),
              distance: userLocation ? calculateDistance(userLocation.lat, userLocation.lng, location.lat, location.lng) : 0,
            }
          : m
      )
    );
  }, [userLocation]);

  // Calculate distance between two points (Haversine formula)
  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
    const R = 6371; // Earth's radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLng = ((lng2 - lng1) * Math.PI) / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // Start location sharing
  const startLocationSharing = useCallback(() => {
    setIsSharingEnabled(true);
    localStorage.setItem('evacora_location_sharing', 'true');

    if (navigator.geolocation) {
      watchIdRef.current = navigator.geolocation.watchPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          // Update own location (would be sent to server in real implementation)
          localStorage.setItem('evacora_my_location', JSON.stringify({ lat: latitude, lng: longitude }));
        },
        (error) => {
          console.error('Geolocation error:', error);
        },
        { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
      );
    }
  }, []);

  // Stop location sharing
  const stopLocationSharing = useCallback(() => {
    setIsSharingEnabled(false);
    localStorage.setItem('evacora_location_sharing', 'false');

    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
  }, []);

  // Set update interval
  const setUpdateIntervalValue = useCallback((interval: number) => {
    setUpdateInterval(interval);
    localStorage.setItem('evacora_update_interval', String(interval));
  }, []);

  // Get nearest family member
  const getNearestMember = useCallback((): FamilyMember | null => {
    if (familyMembers.length === 0) return null;
    return familyMembers.reduce((nearest, member) => {
      if (!member.location) return nearest;
      if (!nearest.location) return member;
      return member.distance < nearest.distance ? member : nearest;
    });
  }, [familyMembers]);

  // Get safe members
  const getSafeMembers = useCallback((): FamilyMember[] => {
    return familyMembers.filter((m) => m.status === 'safe');
  }, [familyMembers]);

  // Get emergency members
  const getEmergencyMembers = useCallback((): FamilyMember[] => {
    return familyMembers.filter((m) => m.status === 'emergency');
  }, [familyMembers]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
      if (intervalRef.current !== null) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  return {
    familyMembers,
    isSharingEnabled,
    updateInterval,
    addFamilyMember,
    removeFamilyMember,
    updateMemberLocation,
    startLocationSharing,
    stopLocationSharing,
    setUpdateIntervalValue,
    getNearestMember,
    getSafeMembers,
    getEmergencyMembers,
    saveFamilyMembers,
  };
}
