import { useEffect, useState } from "react";

export function useFeedbackOnExit(onTrigger: () => void) {
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    // beforeunload 이벤트: 페이지 나가기, 탭 닫기, 새로고침 등
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      // 이미 피드백을 보냈거나 짧은 시간 내에 나가는 경우 무시
      const sessionStart = sessionStorage.getItem("sessionStart");
      if (!sessionStart) {
        sessionStorage.setItem("sessionStart", Date.now().toString());
      }

      const sessionDuration = Date.now() - parseInt(sessionStart || Date.now().toString());
      
      // 5초 이상 사용한 경우에만 피드백 요청
      if (sessionDuration > 5000 && !isExiting) {
        setIsExiting(true);
        onTrigger();
        
        // 기본 beforeunload 동작 방지 (선택사항)
        // e.preventDefault();
        // e.returnValue = "";
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [onTrigger, isExiting]);

  return { isExiting };
}
