import { useState, useEffect, useCallback } from "react";

/**
 * 오프라인 모드 훅
 * - 네트워크 연결 상태 감지
 * - 마지막 위치 정보 캐싱
 * - 오프라인 맵 데이터 저장
 * - 로컬 메시지 저장 및 동기화
 */

interface CachedLocation {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
  address?: string;
}

interface CachedFamilyMember {
  id: number;
  nickname: string;
  lastLocation: CachedLocation;
  lastSeen: number;
}

interface OfflineModeState {
  isOnline: boolean;
  isOfflineMode: boolean;
  lastSyncTime: number | null;
  cachedLocations: CachedLocation[];
  cachedFamilyMembers: CachedFamilyMember[];
  pendingMessages: Array<{
    id: string;
    recipientId: number;
    message: string;
    timestamp: number;
  }>;
}

const STORAGE_KEYS = {
  OFFLINE_MODE: "evacora_offline_mode",
  CACHED_LOCATIONS: "evacora_cached_locations",
  CACHED_FAMILY: "evacora_cached_family",
  PENDING_MESSAGES: "evacora_pending_messages",
  LAST_SYNC: "evacora_last_sync",
  OFFLINE_MAP: "evacora_offline_map",
};

export function useOfflineMode() {
  const [state, setState] = useState<OfflineModeState>({
    isOnline: navigator.onLine,
    isOfflineMode: false,
    lastSyncTime: null,
    cachedLocations: [],
    cachedFamilyMembers: [],
    pendingMessages: [],
  });

  // 네트워크 상태 감지
  useEffect(() => {
    const handleOnline = () => {
      setState((prev) => ({
        ...prev,
        isOnline: true,
        isOfflineMode: false,
      }));
      // 동기화 트리거
      syncPendingData();
    };

    const handleOffline = () => {
      setState((prev) => ({
        ...prev,
        isOnline: false,
        isOfflineMode: true,
      }));
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // 현재 위치 캐싱
  const cacheCurrentLocation = useCallback(
    (location: CachedLocation) => {
      setState((prev) => {
        const updated = {
          ...prev,
          cachedLocations: [location, ...prev.cachedLocations].slice(0, 100), // 최대 100개 유지
        };
        localStorage.setItem(
          STORAGE_KEYS.CACHED_LOCATIONS,
          JSON.stringify(updated.cachedLocations)
        );
        return updated;
      });
    },
    []
  );

  // 가족 위치 정보 캐싱
  const cacheFamilyMembers = useCallback(
    (members: CachedFamilyMember[]) => {
      setState((prev) => ({
        ...prev,
        cachedFamilyMembers: members,
      }));
      localStorage.setItem(
        STORAGE_KEYS.CACHED_FAMILY,
        JSON.stringify(members)
      );
    },
    []
  );

  // 메시지 저장 (오프라인 상태)
  const savePendingMessage = useCallback(
    (recipientId: number, message: string) => {
      const newMessage = {
        id: `msg_${Date.now()}`,
        recipientId,
        message,
        timestamp: Date.now(),
      };

      setState((prev) => {
        const updated = {
          ...prev,
          pendingMessages: [...prev.pendingMessages, newMessage],
        };
        localStorage.setItem(
          STORAGE_KEYS.PENDING_MESSAGES,
          JSON.stringify(updated.pendingMessages)
        );
        return updated;
      });

      return newMessage.id;
    },
    []
  );

  // 마지막 알려진 위치 조회
  const getLastKnownLocation = useCallback((): CachedLocation | null => {
    if (state.cachedLocations.length === 0) {
      const cached = localStorage.getItem(STORAGE_KEYS.CACHED_LOCATIONS);
      if (cached) {
        const locations = JSON.parse(cached) as CachedLocation[];
        return locations[0] || null;
      }
      return null;
    }
    return state.cachedLocations[0] || null;
  }, [state.cachedLocations]);

  // 오프라인 맵 데이터 다운로드
  const downloadOfflineMap = useCallback(
    async (bounds: {
      north: number;
      south: number;
      east: number;
      west: number;
    }) => {
      try {
        // 실제 구현에서는 여기서 맵 타일 다운로드
        const mapData = {
          bounds,
          downloadedAt: Date.now(),
          tileCount: 0,
        };
        localStorage.setItem(STORAGE_KEYS.OFFLINE_MAP, JSON.stringify(mapData));
        return true;
      } catch (error) {
        console.error("Failed to download offline map:", error);
        return false;
      }
    },
    []
  );

  // 대기 중인 데이터 동기화
  const syncPendingData = useCallback(async () => {
    if (!state.isOnline) return;

    try {
      // 대기 중인 메시지 전송
      if (state.pendingMessages.length > 0) {
        // API 호출로 메시지 전송
        // await sendPendingMessages(state.pendingMessages);
        setState((prev) => ({
          ...prev,
          pendingMessages: [],
          lastSyncTime: Date.now(),
        }));
        localStorage.removeItem(STORAGE_KEYS.PENDING_MESSAGES);
      }

      // 최신 위치 정보 동기화
      // await syncLocationData();

      setState((prev) => ({
        ...prev,
        lastSyncTime: Date.now(),
      }));
      localStorage.setItem(
        STORAGE_KEYS.LAST_SYNC,
        JSON.stringify(Date.now())
      );
    } catch (error) {
      console.error("Failed to sync pending data:", error);
    }
  }, [state.isOnline, state.pendingMessages]);

  // 오프라인 모드 수동 활성화/비활성화
  const toggleOfflineMode = useCallback(() => {
    setState((prev) => {
      const newState = {
        ...prev,
        isOfflineMode: !prev.isOfflineMode,
      };
      localStorage.setItem(
        STORAGE_KEYS.OFFLINE_MODE,
        JSON.stringify(newState.isOfflineMode)
      );
      return newState;
    });
  }, []);

  // 캐시 초기화
  const clearCache = useCallback(() => {
    setState((prev) => ({
      ...prev,
      cachedLocations: [],
      cachedFamilyMembers: [],
      pendingMessages: [],
    }));
    Object.values(STORAGE_KEYS).forEach((key) => {
      localStorage.removeItem(key);
    });
  }, []);

  // 로컬 스토리지에서 데이터 복원
  useEffect(() => {
    const offlineMode = localStorage.getItem(STORAGE_KEYS.OFFLINE_MODE);
    const cachedLocations = localStorage.getItem(STORAGE_KEYS.CACHED_LOCATIONS);
    const cachedFamily = localStorage.getItem(STORAGE_KEYS.CACHED_FAMILY);
    const pendingMessages = localStorage.getItem(STORAGE_KEYS.PENDING_MESSAGES);
    const lastSync = localStorage.getItem(STORAGE_KEYS.LAST_SYNC);

    setState((prev) => ({
      ...prev,
      isOfflineMode: offlineMode ? JSON.parse(offlineMode) : false,
      cachedLocations: cachedLocations ? JSON.parse(cachedLocations) : [],
      cachedFamilyMembers: cachedFamily ? JSON.parse(cachedFamily) : [],
      pendingMessages: pendingMessages ? JSON.parse(pendingMessages) : [],
      lastSyncTime: lastSync ? JSON.parse(lastSync) : null,
    }));
  }, []);

  return {
    // 상태
    isOnline: state.isOnline,
    isOfflineMode: state.isOfflineMode,
    lastSyncTime: state.lastSyncTime,
    pendingMessageCount: state.pendingMessages.length,

    // 캐싱 함수
    cacheCurrentLocation,
    cacheFamilyMembers,
    savePendingMessage,

    // 조회 함수
    getLastKnownLocation,
    getCachedFamilyMembers: () => state.cachedFamilyMembers,
    getPendingMessages: () => state.pendingMessages,

    // 맵 함수
    downloadOfflineMap,

    // 동기화 함수
    syncPendingData,

    // 제어 함수
    toggleOfflineMode,
    clearCache,
  };
}
