/**
 * useVoiceGuidance Hook
 * 음성 안내 기능 제공 (Web Speech API 활용)
 */

import { useState, useCallback, useRef } from 'react';

export interface VoiceGuidanceOptions {
  language?: string;
  rate?: number;
  pitch?: number;
  volume?: number;
}

export function useVoiceGuidance(options: VoiceGuidanceOptions = {}) {
  const [isSupported] = useState(() => {
    return 'speechSynthesis' in window;
  });

  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  const speak = useCallback(
    (text: string, customOptions?: VoiceGuidanceOptions) => {
      if (!isSupported) {
        console.warn('Speech Synthesis not supported');
        return;
      }

      // Cancel any ongoing speech
      window.speechSynthesis.cancel();

      const mergedOptions = { ...options, ...customOptions };
      const utterance = new SpeechSynthesisUtterance(text);

      if (mergedOptions.language) {
        utterance.lang = mergedOptions.language;
      }
      if (mergedOptions.rate) {
        utterance.rate = mergedOptions.rate;
      }
      if (mergedOptions.pitch) {
        utterance.pitch = mergedOptions.pitch;
      }
      if (mergedOptions.volume) {
        utterance.volume = mergedOptions.volume;
      }

      utterance.onstart = () => {
        setIsPlaying(true);
        setIsPaused(false);
      };

      utterance.onend = () => {
        setIsPlaying(false);
        setIsPaused(false);
      };

      utterance.onerror = (event) => {
        console.error('Speech synthesis error:', event.error);
        setIsPlaying(false);
        setIsPaused(false);
      };

      utteranceRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    },
    [isSupported, options]
  );

  const pause = useCallback(() => {
    if (isSupported && isPlaying) {
      window.speechSynthesis.pause();
      setIsPaused(true);
    }
  }, [isSupported, isPlaying]);

  const resume = useCallback(() => {
    if (isSupported && isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    }
  }, [isSupported, isPaused]);

  const stop = useCallback(() => {
    if (isSupported) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
      setIsPaused(false);
    }
  }, [isSupported]);

  const getAvailableVoices = useCallback(() => {
    if (!isSupported) return [];
    return window.speechSynthesis.getVoices();
  }, [isSupported]);

  return {
    isSupported,
    isPlaying,
    isPaused,
    speak,
    pause,
    resume,
    stop,
    getAvailableVoices,
  };
}
