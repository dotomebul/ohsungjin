import { useState, useCallback } from "react";

/**
 * 향상된 음성 안내 훅
 * - 도로 혼잡 경고
 * - 대피 경로 안내
 * - 긴급 상황 알림
 * - 다국어 지원
 */

type Language = "ko" | "en" | "pl" | "de" | "fr" | "es";

interface VoiceGuidanceConfig {
  language: Language;
  volume: number; // 0-1
  speed: number; // 0.5-2.0
  pitch: number; // 0.5-2.0
}

const VOICE_MESSAGES: Record<Language, Record<string, string>> = {
  ko: {
    congestion_warning: "주의! 도로가 혼잡합니다. 대체 경로로 우회하세요.",
    congestion_severe: "심각한 교통 혼잡! 즉시 우회 경로로 변경하세요.",
    evacuation_start: "대피를 시작합니다. 안전한 경로로 안내하겠습니다.",
    evacuation_direction_north: "북쪽으로 이동하세요.",
    evacuation_direction_south: "남쪽으로 이동하세요.",
    evacuation_direction_east: "동쪽으로 이동하세요.",
    evacuation_direction_west: "서쪽으로 이동하세요.",
    shelter_approaching: "대피소에 거의 다 왔습니다. 500미터 남았습니다.",
    shelter_arrived: "대피소에 도착했습니다. 안전하게 대피했습니다.",
    family_nearby: "가족이 근처에 있습니다. 만남 지점으로 이동하세요.",
    battery_warning: "배터리가 부족합니다. 배터리 절약 모드를 활성화합니다.",
    network_warning: "네트워크 연결이 끊겼습니다. 오프라인 모드로 전환합니다.",
    emergency_alert: "긴급 상황 발생! 즉시 대피하세요.",
  },
  en: {
    congestion_warning: "Warning! Road is congested. Please take an alternate route.",
    congestion_severe: "Severe traffic congestion! Immediately switch to alternate route.",
    evacuation_start: "Starting evacuation. I will guide you through a safe route.",
    evacuation_direction_north: "Move north.",
    evacuation_direction_south: "Move south.",
    evacuation_direction_east: "Move east.",
    evacuation_direction_west: "Move west.",
    shelter_approaching: "You are almost at the shelter. 500 meters remaining.",
    shelter_arrived: "You have arrived at the shelter. You are safe.",
    family_nearby: "Your family is nearby. Move to the meeting point.",
    battery_warning: "Battery is low. Activating battery saver mode.",
    network_warning: "Network connection lost. Switching to offline mode.",
    emergency_alert: "Emergency situation! Evacuate immediately!",
  },
  pl: {
    congestion_warning: "Uwaga! Droga jest zatłoczona. Proszę wybrać trasę alternatywną.",
    congestion_severe: "Poważne korki! Natychmiast zmień trasę.",
    evacuation_start: "Rozpoczynamy ewakuację. Poprowadzę Cię bezpieczną trasą.",
    evacuation_direction_north: "Poruszaj się na północ.",
    evacuation_direction_south: "Poruszaj się na południe.",
    evacuation_direction_east: "Poruszaj się na wschód.",
    evacuation_direction_west: "Poruszaj się na zachód.",
    shelter_approaching: "Prawie dotarłeś do schronienia. Pozostało 500 metrów.",
    shelter_arrived: "Dotarłeś do schronienia. Jesteś bezpieczny.",
    family_nearby: "Twoja rodzina jest blisko. Przejdź do punktu spotkania.",
    battery_warning: "Bateria jest niska. Aktywuję tryb oszczędzania baterii.",
    network_warning: "Połączenie sieciowe zostało utracone. Przełączam na tryb offline.",
    emergency_alert: "Sytuacja nadzwyczajna! Natychmiast ewakuuj się!",
  },
  de: {
    congestion_warning: "Warnung! Die Straße ist überlastet. Bitte nehmen Sie eine alternative Route.",
    congestion_severe: "Schwere Verkehrsstaus! Wechseln Sie sofort zur Alternativroute.",
    evacuation_start: "Evakuierung wird eingeleitet. Ich leite Sie durch eine sichere Route.",
    evacuation_direction_north: "Bewegen Sie sich nach Norden.",
    evacuation_direction_south: "Bewegen Sie sich nach Süden.",
    evacuation_direction_east: "Bewegen Sie sich nach Osten.",
    evacuation_direction_west: "Bewegen Sie sich nach Westen.",
    shelter_approaching: "Sie sind fast im Schutzraum angekommen. 500 Meter verbleibend.",
    shelter_arrived: "Sie sind im Schutzraum angekommen. Sie sind sicher.",
    family_nearby: "Ihre Familie ist in der Nähe. Begeben Sie sich zum Treffpunkt.",
    battery_warning: "Akku ist schwach. Aktiviere Batteriesparmodus.",
    network_warning: "Netzwerkverbindung unterbrochen. Wechsel zum Offline-Modus.",
    emergency_alert: "Notfallsituation! Evakuieren Sie sich sofort!",
  },
  fr: {
    congestion_warning: "Attention ! La route est congestionnée. Veuillez prendre un itinéraire alternatif.",
    congestion_severe: "Embouteillage grave ! Changez immédiatement d'itinéraire.",
    evacuation_start: "Début de l'évacuation. Je vais vous guider par une route sûre.",
    evacuation_direction_north: "Allez vers le nord.",
    evacuation_direction_south: "Allez vers le sud.",
    evacuation_direction_east: "Allez vers l'est.",
    evacuation_direction_west: "Allez vers l'ouest.",
    shelter_approaching: "Vous êtes presque arrivé à l'abri. 500 mètres restants.",
    shelter_arrived: "Vous êtes arrivé à l'abri. Vous êtes en sécurité.",
    family_nearby: "Votre famille est à proximité. Allez au point de rencontre.",
    battery_warning: "La batterie est faible. Activation du mode économie d'énergie.",
    network_warning: "Connexion réseau perdue. Passage au mode hors ligne.",
    emergency_alert: "Situation d'urgence ! Évacuez-vous immédiatement !",
  },
  es: {
    congestion_warning: "¡Advertencia! La carretera está congestionada. Por favor, tome una ruta alternativa.",
    congestion_severe: "¡Congestión grave! Cambie inmediatamente a la ruta alternativa.",
    evacuation_start: "Iniciando evacuación. Te guiaré por una ruta segura.",
    evacuation_direction_north: "Muévete hacia el norte.",
    evacuation_direction_south: "Muévete hacia el sur.",
    evacuation_direction_east: "Muévete hacia el este.",
    evacuation_direction_west: "Muévete hacia el oeste.",
    shelter_approaching: "Casi llegas al refugio. Faltan 500 metros.",
    shelter_arrived: "Llegaste al refugio. Estás seguro.",
    family_nearby: "Tu familia está cerca. Ve al punto de encuentro.",
    battery_warning: "La batería es baja. Activando modo de ahorro de batería.",
    network_warning: "Conexión de red perdida. Cambiando a modo sin conexión.",
    emergency_alert: "¡Situación de emergencia! ¡Evacúate inmediatamente!",
  },
};

export function useVoiceGuidanceEnhanced(config: VoiceGuidanceConfig) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [lastMessage, setLastMessage] = useState<string>("");

  const speak = useCallback(
    (messageKey: string) => {
      if (!("speechSynthesis" in window)) {
        console.warn("Speech Synthesis not supported");
        return;
      }

      const message = VOICE_MESSAGES[config.language]?.[messageKey] || "";
      if (!message) return;

      // 이전 음성 중단
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = config.language === "ko" ? "ko-KR" : config.language;
      utterance.volume = config.volume;
      utterance.rate = config.speed;
      utterance.pitch = config.pitch;

      utterance.onstart = () => setIsPlaying(true);
      utterance.onend = () => setIsPlaying(false);
      utterance.onerror = () => setIsPlaying(false);

      setLastMessage(message);
      window.speechSynthesis.speak(utterance);
    },
    [config]
  );

  // 도로 혼잡 경고
  const announceTrafficCongestion = useCallback(
    (severity: "warning" | "severe") => {
      const key = severity === "severe" ? "congestion_severe" : "congestion_warning";
      speak(key);
    },
    [speak]
  );

  // 대피 시작 안내
  const announceEvacuationStart = useCallback(() => {
    speak("evacuation_start");
  }, [speak]);

  // 방향 안내
  const announceDirection = useCallback(
    (direction: "north" | "south" | "east" | "west") => {
      const key = `evacuation_direction_${direction}`;
      speak(key as keyof typeof VOICE_MESSAGES["ko"]);
    },
    [speak]
  );

  // 대피소 접근 안내
  const announceShelterApproaching = useCallback(() => {
    speak("shelter_approaching");
  }, [speak]);

  // 대피소 도착 안내
  const announceShelterArrived = useCallback(() => {
    speak("shelter_arrived");
  }, [speak]);

  // 가족 근처 안내
  const announceFamilyNearby = useCallback(() => {
    speak("family_nearby");
  }, [speak]);

  // 배터리 경고
  const announceBatteryWarning = useCallback(() => {
    speak("battery_warning");
  }, [speak]);

  // 네트워크 경고
  const announceNetworkWarning = useCallback(() => {
    speak("network_warning");
  }, [speak]);

  // 긴급 알림
  const announceEmergency = useCallback(() => {
    speak("emergency_alert");
  }, [speak]);

  return {
    isPlaying,
    lastMessage,
    speak,
    announceTrafficCongestion,
    announceEvacuationStart,
    announceDirection,
    announceShelterApproaching,
    announceShelterArrived,
    announceFamilyNearby,
    announceBatteryWarning,
    announceNetworkWarning,
    announceEmergency,
  };
}
