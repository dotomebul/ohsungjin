import { useState, useEffect, useCallback } from "react";

/**
 * 실시간 혼잡도 정보 훅
 * - 도로 혼잡도 실시간 모니터링
 * - 대체 경로 제안
 * - 예상 시간 업데이트
 * - 혼잡도 알림
 */

export type CongestionLevel = "clear" | "moderate" | "heavy" | "severe";

export interface TrafficSegment {
  id: string;
  name: string;
  startLat: number;
  startLon: number;
  endLat: number;
  endLon: number;
  congestionLevel: CongestionLevel;
  speed: number; // km/h
  freeFlowSpeed: number; // km/h
  distance: number; // km
  eta: number; // 분
}

export interface Route {
  id: string;
  name: string;
  segments: TrafficSegment[];
  totalDistance: number; // km
  totalEta: number; // 분
  totalDelay: number; // 분
  isRecommended: boolean;
}

interface TrafficInfoState {
  currentRoute: Route | null;
  alternativeRoutes: Route[];
  congestionAlerts: Array<{
    id: string;
    severity: "warning" | "critical";
    message: string;
    timestamp: number;
  }>;
  lastUpdateTime: number | null;
}

// 혼잡도 레벨별 색상 및 아이콘
export const CONGESTION_COLORS: Record<CongestionLevel, string> = {
  clear: "bg-green-500",
  moderate: "bg-yellow-500",
  heavy: "bg-orange-500",
  severe: "bg-red-500",
};

export const CONGESTION_LABELS: Record<CongestionLevel, string> = {
  clear: "원활",
  moderate: "보통",
  heavy: "혼잡",
  severe: "심각",
};

// 샘플 트래픽 데이터 (실제로는 API에서 가져옴)
const SAMPLE_ROUTES: Route[] = [
  {
    id: "route_1",
    name: "주요 도로 (권장)",
    segments: [
      {
        id: "seg_1",
        name: "Warsaw Business District → Marszałkowska St",
        startLat: 52.2297,
        startLon: 21.0122,
        endLat: 52.2250,
        endLon: 21.0200,
        congestionLevel: "heavy",
        speed: 25,
        freeFlowSpeed: 50,
        distance: 1.2,
        eta: 3,
      },
      {
        id: "seg_2",
        name: "Marszałkowska St → Aleje Jerozolimskie",
        startLat: 52.2250,
        startLon: 21.0200,
        endLat: 52.2150,
        endLon: 21.0150,
        congestionLevel: "moderate",
        speed: 40,
        freeFlowSpeed: 60,
        distance: 1.8,
        eta: 3,
      },
      {
        id: "seg_3",
        name: "Aleje Jerozolimskie → Shelter",
        startLat: 52.2150,
        startLon: 21.0150,
        endLat: 52.2100,
        endLon: 21.0100,
        congestionLevel: "clear",
        speed: 55,
        freeFlowSpeed: 60,
        distance: 1.0,
        eta: 1,
      },
    ],
    totalDistance: 4.0,
    totalEta: 7,
    totalDelay: 2,
    isRecommended: true,
  },
  {
    id: "route_2",
    name: "우회 경로 1",
    segments: [
      {
        id: "seg_4",
        name: "Warsaw Business District → Nowy Świat St",
        startLat: 52.2297,
        startLon: 21.0122,
        endLat: 52.2200,
        endLon: 21.0050,
        congestionLevel: "moderate",
        speed: 40,
        freeFlowSpeed: 60,
        distance: 1.5,
        eta: 2,
      },
      {
        id: "seg_5",
        name: "Nowy Świat St → Shelter",
        startLat: 52.2200,
        startLon: 21.0050,
        endLat: 52.2100,
        endLon: 21.0100,
        congestionLevel: "clear",
        speed: 55,
        freeFlowSpeed: 60,
        distance: 1.8,
        eta: 2,
      },
    ],
    totalDistance: 3.3,
    totalEta: 4,
    totalDelay: 0,
    isRecommended: false,
  },
  {
    id: "route_3",
    name: "우회 경로 2",
    segments: [
      {
        id: "seg_6",
        name: "Warsaw Business District → Pulaski St",
        startLat: 52.2297,
        startLon: 21.0122,
        endLat: 52.2180,
        endLon: 21.0000,
        congestionLevel: "clear",
        speed: 55,
        freeFlowSpeed: 60,
        distance: 1.8,
        eta: 2,
      },
      {
        id: "seg_7",
        name: "Pulaski St → Shelter",
        startLat: 52.2180,
        startLon: 21.0000,
        endLat: 52.2100,
        endLon: 21.0100,
        congestionLevel: "moderate",
        speed: 40,
        freeFlowSpeed: 60,
        distance: 1.5,
        eta: 2,
      },
    ],
    totalDistance: 3.3,
    totalEta: 4,
    totalDelay: 0,
    isRecommended: false,
  },
];

export function useRealTimeTrafficInfo() {
  const [state, setState] = useState<TrafficInfoState>({
    currentRoute: SAMPLE_ROUTES[0],
    alternativeRoutes: SAMPLE_ROUTES.slice(1),
    congestionAlerts: [],
    lastUpdateTime: Date.now(),
  });

  // 혼잡도 업데이트 (시뮬레이션)
  useEffect(() => {
    const interval = setInterval(() => {
      // 실제로는 API에서 실시간 데이터 가져옴
      setState((prev) => {
        const updatedRoute = { ...prev.currentRoute! };
        updatedRoute.segments = updatedRoute.segments.map((seg) => {
          // 랜덤하게 혼잡도 변경 (시뮬레이션)
          const levels: CongestionLevel[] = ["clear", "moderate", "heavy", "severe"];
          const randomLevel = levels[Math.floor(Math.random() * levels.length)];
          const speedMultiplier =
            randomLevel === "clear"
              ? 1
              : randomLevel === "moderate"
                ? 0.7
                : randomLevel === "heavy"
                  ? 0.5
                  : 0.3;

          return {
            ...seg,
            congestionLevel: randomLevel,
            speed: Math.round(seg.freeFlowSpeed * speedMultiplier),
            eta: Math.ceil((seg.distance / (seg.freeFlowSpeed * speedMultiplier)) * 60),
          };
        });

        // 총 ETA 재계산
        updatedRoute.totalEta = updatedRoute.segments.reduce((sum, seg) => sum + seg.eta, 0);
        updatedRoute.totalDelay = Math.max(0, updatedRoute.totalEta - 7);

        // 심각한 혼잡도 알림
        const newAlerts: TrafficInfoState["congestionAlerts"] = [];
        updatedRoute.segments.forEach((seg) => {
          if (seg.congestionLevel === "severe") {
            newAlerts.push({
              id: `alert_${seg.id}`,
              severity: "critical",
              message: `${seg.name}에서 심각한 교통 혼잡이 발생했습니다.`,
              timestamp: Date.now(),
            });
          } else if (seg.congestionLevel === "heavy") {
            newAlerts.push({
              id: `alert_${seg.id}`,
              severity: "warning",
              message: `${seg.name}에서 혼잡이 발생했습니다.`,
              timestamp: Date.now(),
            });
          }
        });

        return {
          ...prev,
          currentRoute: updatedRoute,
          congestionAlerts: newAlerts,
          lastUpdateTime: Date.now(),
        };
      });
    }, 30000); // 30초마다 업데이트

    return () => clearInterval(interval);
  }, []);

  // 경로 변경
  const switchRoute = useCallback((routeId: string) => {
    setState((prev) => {
      const newRoute = [prev.currentRoute, ...prev.alternativeRoutes].find(
        (r) => r?.id === routeId
      );
      if (!newRoute) return prev;

      const remaining = [prev.currentRoute, ...prev.alternativeRoutes]
        .filter((r) => r?.id !== routeId)
        .filter((r): r is Route => r !== null);

      return {
        ...prev,
        currentRoute: newRoute,
        alternativeRoutes: remaining.filter((r) => r.id !== newRoute.id),
      };
    });
  }, []);

  // 최적 경로 추천
  const getOptimalRoute = useCallback((): Route | null => {
    if (!state.currentRoute) return null;

    const allRoutes = [state.currentRoute, ...state.alternativeRoutes];
    return allRoutes.reduce((best, route) =>
      route.totalEta < best.totalEta ? route : best
    );
  }, [state.currentRoute, state.alternativeRoutes]);

  // 혼잡도 알림 확인
  const acknowledgeAlert = useCallback((alertId: string) => {
    setState((prev) => ({
      ...prev,
      congestionAlerts: prev.congestionAlerts.filter((a) => a.id !== alertId),
    }));
  }, []);

  // 모든 알림 확인
  const acknowledgeAllAlerts = useCallback(() => {
    setState((prev) => ({
      ...prev,
      congestionAlerts: [],
    }));
  }, []);

  return {
    // 상태
    currentRoute: state.currentRoute,
    alternativeRoutes: state.alternativeRoutes,
    congestionAlerts: state.congestionAlerts,
    lastUpdateTime: state.lastUpdateTime,

    // 함수
    switchRoute,
    getOptimalRoute,
    acknowledgeAlert,
    acknowledgeAllAlerts,
  };
}
