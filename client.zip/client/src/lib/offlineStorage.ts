/**
 * Evacora 오프라인 저장소 관리
 * IndexedDB를 사용하여 맵, 가이드, 대피소 데이터 캐싱
 */

export interface OfflineData {
  guides: Record<string, any>;
  shelters: Record<string, any>;
  mapTiles: Record<string, Blob>;
  lastSync: number;
}

const DB_NAME = 'EvacoroDB';
const DB_VERSION = 1;

const STORES = {
  GUIDES: 'guides',
  SHELTERS: 'shelters',
  MAP_TILES: 'mapTiles',
  PENDING_ALERTS: 'pendingAlerts',
  METADATA: 'metadata',
};

let db: IDBDatabase | null = null;

export async function initOfflineStorage(): Promise<void> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      db = request.result;
      console.log('[OfflineStorage] Initialized');
      resolve();
    };

    request.onupgradeneeded = (event) => {
      const database = (event.target as IDBOpenDBRequest).result;

      // 가이드 저장소
      if (!database.objectStoreNames.contains(STORES.GUIDES)) {
        database.createObjectStore(STORES.GUIDES, { keyPath: 'code' });
      }

      // 대피소 저장소
      if (!database.objectStoreNames.contains(STORES.SHELTERS)) {
        const shelterStore = database.createObjectStore(STORES.SHELTERS, { keyPath: 'id' });
        shelterStore.createIndex('region', 'region', { unique: false });
        shelterStore.createIndex('distance', 'distance', { unique: false });
      }

      // 맵 타일 저장소
      if (!database.objectStoreNames.contains(STORES.MAP_TILES)) {
        database.createObjectStore(STORES.MAP_TILES, { keyPath: 'url' });
      }

      // 대기 중인 알림
      if (!database.objectStoreNames.contains(STORES.PENDING_ALERTS)) {
        database.createObjectStore(STORES.PENDING_ALERTS, { keyPath: 'id', autoIncrement: true });
      }

      // 메타데이터
      if (!database.objectStoreNames.contains(STORES.METADATA)) {
        database.createObjectStore(STORES.METADATA, { keyPath: 'key' });
      }
    };
  });
}

export async function saveGuide(guide: any): Promise<void> {
  if (!db) await initOfflineStorage();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction([STORES.GUIDES], 'readwrite');
    const store = transaction.objectStore(STORES.GUIDES);
    const request = store.put(guide);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

export async function getGuide(code: string): Promise<any> {
  if (!db) await initOfflineStorage();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction([STORES.GUIDES], 'readonly');
    const store = transaction.objectStore(STORES.GUIDES);
    const request = store.get(code);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
  });
}

export async function saveShelter(shelter: any): Promise<void> {
  if (!db) await initOfflineStorage();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction([STORES.SHELTERS], 'readwrite');
    const store = transaction.objectStore(STORES.SHELTERS);
    const request = store.put(shelter);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

export async function getSheltersByRegion(region: string): Promise<any[]> {
  if (!db) await initOfflineStorage();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction([STORES.SHELTERS], 'readonly');
    const store = transaction.objectStore(STORES.SHELTERS);
    const index = store.index('region');
    const request = index.getAll(region);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
  });
}

export async function savePendingAlert(alert: any): Promise<number> {
  if (!db) await initOfflineStorage();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction([STORES.PENDING_ALERTS], 'readwrite');
    const store = transaction.objectStore(STORES.PENDING_ALERTS);
    const request = store.add(alert);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result as number);
  });
}

export async function getPendingAlerts(): Promise<any[]> {
  if (!db) await initOfflineStorage();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction([STORES.PENDING_ALERTS], 'readonly');
    const store = transaction.objectStore(STORES.PENDING_ALERTS);
    const request = store.getAll();
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
  });
}

export async function deletePendingAlert(id: number): Promise<void> {
  if (!db) await initOfflineStorage();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction([STORES.PENDING_ALERTS], 'readwrite');
    const store = transaction.objectStore(STORES.PENDING_ALERTS);
    const request = store.delete(id);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

export async function setMetadata(key: string, value: any): Promise<void> {
  if (!db) await initOfflineStorage();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction([STORES.METADATA], 'readwrite');
    const store = transaction.objectStore(STORES.METADATA);
    const request = store.put({ key, value, timestamp: Date.now() });
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

export async function getMetadata(key: string): Promise<any> {
  if (!db) await initOfflineStorage();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction([STORES.METADATA], 'readonly');
    const store = transaction.objectStore(STORES.METADATA);
    const request = store.get(key);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result?.value);
  });
}

export async function clearAllData(): Promise<void> {
  if (!db) await initOfflineStorage();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction(
      [STORES.GUIDES, STORES.SHELTERS, STORES.MAP_TILES, STORES.PENDING_ALERTS, STORES.METADATA],
      'readwrite'
    );
    
    Object.values(STORES).forEach((storeName) => {
      try {
        const store = transaction.objectStore(storeName);
        store.clear();
      } catch (error) {
        console.error(`[OfflineStorage] Error clearing ${storeName}:`, error);
      }
    });

    transaction.onerror = () => reject(transaction.error);
    transaction.oncomplete = () => resolve();
  });
}

export async function getStorageSize(): Promise<{ used: number; quota: number }> {
  if (!navigator.storage?.estimate) {
    return { used: 0, quota: 0 };
  }

  const estimate = await navigator.storage.estimate();
  return {
    used: estimate.usage || 0,
    quota: estimate.quota || 0,
  };
}
