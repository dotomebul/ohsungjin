import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Home from "@/pages/Home";
import DisasterGuide from "@/pages/DisasterGuide";
import EmergencyContacts from "@/pages/EmergencyContacts";
import Map from "@/pages/Map";
import Onboarding from "@/pages/Onboarding";
import Dashboard from "@/pages/Dashboard";
import Settings from "@/pages/Settings";
import FamilyTracker from "@/pages/FamilyTracker";
import ActionGuide from "@/pages/ActionGuide";
import SafeRoute from "@/pages/SafeRoute";
import Privacy from "@/pages/Privacy";
import Terms from "@/pages/Terms";
import PrivacyPolicy from "@/pages/PrivacyPolicy";
import TermsOfService from "@/pages/TermsOfService";
import ShelterDetail from "@/pages/ShelterDetail";
import EmailAuth from "@/pages/EmailAuth";
import JoinFamily from "@/pages/JoinFamily";
import LocationShareView from "@/pages/LocationShareView";
import License from "@/pages/License";
import NewsPage from "@/pages/NewsPage";

import { Route, Switch, Redirect, useParams } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { I18nProvider, useI18n } from "./contexts/I18nContext";
import { FeedbackModal } from "./components/FeedbackModal";
import { useFeedbackOnExit } from "./hooks/useFeedbackOnExit";
import { BottomNavigation } from "./components/BottomNavigation";
import { OnboardingTutorial } from "./components/OnboardingTutorial";
import { useState, useEffect } from "react";


function OnboardingGuard({ children }: { children: React.ReactNode }) {
  const { isOnboardingCompleted } = useI18n();

  if (!isOnboardingCompleted) {
    return <Onboarding />;
  }

  return <>{children}</>;
}

function JoinFamilyWrapper() {
  const { token } = useParams<{ token: string }>();
  return <JoinFamily token={token} />;
}

function LocationShareViewWrapper() {
  const { token } = useParams<{ token: string }>();
  return <LocationShareView token={token} />;
}


function RouterWithFeedback() {
  const [showFeedback, setShowFeedback] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  
  useEffect(() => {
    // 튜토리얼이 완료되지 않았고, 온보딩도 완료된 경우에만 표시
    const tutorialCompleted = localStorage.getItem('tutorial_completed');
    if (!tutorialCompleted) {
      // 약간의 지연 후 튜토리얼 표시 (페이지 로드 완료 후)
      const timer = setTimeout(() => setShowTutorial(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);
  
  useFeedbackOnExit(() => setShowFeedback(true));

  return (
    <>
      <Router />
      <BottomNavigation />
      <FeedbackModal
        isOpen={showFeedback}
        onClose={() => setShowFeedback(false)}
      />
      {showTutorial && (
        <OnboardingTutorial />
      )}
    </>
  );
}

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Onboarding} />
      <Route path={"/home"}>
        <OnboardingGuard><Home /></OnboardingGuard>
      </Route>
      <Route path={"/guides"}>
        <OnboardingGuard><DisasterGuide /></OnboardingGuard>
      </Route>
      <Route path={"/contacts"}>
        <OnboardingGuard><EmergencyContacts /></OnboardingGuard>
      </Route>
      <Route path={"/map"}>
        <OnboardingGuard><Map /></OnboardingGuard>
      </Route>
      <Route path={"/dashboard"}>
        <OnboardingGuard><Dashboard /></OnboardingGuard>
      </Route>
      <Route path={"/settings"}>
        <OnboardingGuard><Settings /></OnboardingGuard>
      </Route>
      <Route path={"/family"}>
        <OnboardingGuard><FamilyTracker /></OnboardingGuard>
      </Route>
      <Route path={"/family-tracker"}>
        <OnboardingGuard><FamilyTracker /></OnboardingGuard>
      </Route>
      <Route path={"/action-guide"}>
        <OnboardingGuard><ActionGuide /></OnboardingGuard>
      </Route>
      <Route path={"/safe-route"}>
        <OnboardingGuard><SafeRoute /></OnboardingGuard>
      </Route>
      <Route path={"/privacy"}>
        <OnboardingGuard><Privacy /></OnboardingGuard>
      </Route>
      <Route path={"/terms"}>
        <OnboardingGuard><Terms /></OnboardingGuard>
      </Route>
      <Route path={"/privacy-policy"}>
        <OnboardingGuard><PrivacyPolicy /></OnboardingGuard>
      </Route>
      <Route path={"/terms-of-service"}>
        <OnboardingGuard><TermsOfService /></OnboardingGuard>
      </Route>
      <Route path={"/shelter/:id"}>
        <OnboardingGuard><ShelterDetail /></OnboardingGuard>
      </Route>
      <Route path={"/email-auth"}>
        <EmailAuth />
      </Route>
      <Route path={"/join-family/:token"}>
        <JoinFamilyWrapper />
      </Route>
      <Route path={"/location-share/:token"}>
        <LocationShareViewWrapper />
      </Route>
      <Route path={"/license"}>
        <OnboardingGuard><License /></OnboardingGuard>
      </Route>
      <Route path={"/news"}>
        <OnboardingGuard><NewsPage /></OnboardingGuard>
      </Route>
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <I18nProvider>
          <TooltipProvider>
            <RouterWithFeedback />
          </TooltipProvider>
        </I18nProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
